const {
  getProductsRepository,
  getBarcode,
  getCountTotalProducts,
} = require("../repositories/product.repository");
const { create_product, update_product } = require("./flink-api.service");
const { getSectionID } = require("./section.service");

// **Produto
// PROCOD – Código do produto;
// PRODES – Descrição do produto;
// SECCOD – Código da seção. Grupo de produto;
// PROPRCDATALT – Indica que o preço do produto foi alterado.
// PROPRCVDAVAR – Preço de venda 1;
// PROPRCVDA2 – Preço de venda 2;
// PROPRCVDA3 – Preço de venda 3;
// PROPRCOFEVAR – Preço de oferta 1;
// PROPRCOFE2 – Preço de oferta 2;
// PROPRCOFE3 – Preço de oferta 3;
// PROFLGALT – Permite saber se o produto sofreu alguma alteração; PRODATCADALT – Indica que o produto teve alteração de cadastro; PROFORLIN – Indica que o produto está em linha.
// ** PRTODUTOAUX
// PROCODAUX – Código auxiliar do produto. Pode ser o EAN;

const getProducts = async () => {
  // const a = await getSectionsByProduct('00000000029472')
  // console.log(a)
  // return
  // const sections = await getAllSections()
  // for (const section of sections) {
  //   const capitalCaseFormat = section.SECDES.split(' ').map(w => w[0].toUpperCase() + w.substr(1).toLowerCase()).join(' ')

  //   const res_api = await create_section({
  //     name: capitalCaseFormat
  //   })
  //   console.log(res_api)
  // }
  // // console.log(sections)
  // return
  // create categories and sessions

  const QtdProducts = await getCountTotalProducts();
  console.log("Total de produtos na database:", QtdProducts);

  const products = await getProductsRepository();
  console.log("produtos na memoria: ", products.length);
  let contador = 0;
  for (const product of products) {
    contador++;
    const percent = (contador / QtdProducts) * 100;
    console.log(
      `contador em ${contador} de ${QtdProducts} - ${percent.toFixed(2)}%`
    );
    console.log(`cadastrando produto: ${product.PROCOD}`);
    // console.log(product.PROPRCOFEVAR)

    const sectionID = await getSectionID(product.PROCOD);
    const product_info = {
      description: product.PRODES,
      barcode: await getBarcode(product.PROCOD),
      product_id_in_company_database: String(product.PROCOD).trim(),
      price: product.PROPRC1,
      is_offer: product.PROPRCOFEVAR != 0 ? true : false,
      max_amount: Math.round(product.PROQTDMAXVDA),
      unit_of_measurement: String(product.PROUNDREF).trim(),
      is_alcohol_drink: false,
      secao_id: sectionID,
      department_item_id: 1,
      section_item_id: 1,
      company_id: 1,

      // product.PRODATCADALT data de alteracao
    };

    // inserir produto
    // console.log(product_info)
    await create_product(product_info);
  }
  return products;
};

const updateProducts = async () => {
  const QtdProducts = await getCountTotalProducts();
  console.log("Total de produtos na database:", QtdProducts);

  const products = await getProductsRepository();
  console.log("produtos na memoria: ", products.length);
  let contador = 0;
  for (const product of products) {
    contador++;
    const percent = (contador / QtdProducts) * 100;
    console.log(
      `contador em ${contador} de ${QtdProducts} - ${percent.toFixed(2)}%`
    );
    console.log(`Atualizando produto: ${product.PROCOD}`);
    // console.log(product.PROPRCOFEVAR)

    console.log(`Data da ultima atualizacao ${product.PRODATCADALT}`)
    const product_info = {
      // description: product.PRODES,
      // barcode: await getBarcode(product.PROCOD),
      // product_id_in_company_database: String(product.PROCOD).trim(),
      price: product.PROPRC1,
      is_offer: product.PROPRCOFEVAR != 0 ? true : false,
      // max_amount: Math.round(product.PROQTDMAXVDA),

      // product.PRODATCADALT data de alteracao
    };

    // inserir produto
    // console.log(product_info)
    await update_product(product_info, 120);
  }
};

module.exports = { getProducts, updateProducts };
