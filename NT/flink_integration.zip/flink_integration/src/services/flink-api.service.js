const axios = require("axios");
const fs = require("fs");
const FormData = require("form-data");
const util = require("util");
const { pipeline } = require("stream");
const pump = util.promisify(pipeline);
const config = require('../config/config')
// await pump(data.file, fs.createWriteStream(data.filename))


console.log(config.apiUrl)
const BASE_URL = config.apiUrl;
let CACHE_TOKEN = null;

const token_login = async () => {
  if (CACHE_TOKEN) {
    return CACHE_TOKEN;
  }

  const options = {
    method: "POST",
    url: `${BASE_URL}/auth/customer/login`,
    headers: { "Content-Type": "application/json" },
    data: { phone: config.auth.login, password: config.auth.password },
  };
  const response = await axios.request(options);
  if (response.data.user.access_level == `customer`) {
    return null;
  }

  console.log("Token capturado com sucesso!");
  CACHE_TOKEN = response.data.token;
  return response.data.token;
};

const create_product = async (product_info) => {
  try {
    const token = await token_login();
    if (!token) throw new Error("sem permissao");

    const headers = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        company_name: config.companyDatabase,
      },
    };
    // const product_info = {
    //     description: 'coca-cola',
    //     barcode: '444',
    //     price: 2.5,
    //     original_price: 2.2,
    //     department_item_id: 1,
    //     section_item_id: 1,
    //     company_id: 1
    //   }
    const response = await axios.post(
      `${BASE_URL}/product`,
      product_info,
      headers
    );
    // console.log("Produto cadastrado com sucesso!");
    // console.log(response.data);
    return response.data;
  } catch (error) {
    console.log(
      `Erro ao enviar o produto ${product_info.description} - ${product_info.barcode} para API`
    );
    // console.log(error);
    console.log(error.response.data);
  }
};

const upload_image = async (barcode, productID) => {
  console.log("upload here");
  console.log(barcode, productID);

  var newFile = fs.createReadStream(`./src/fetch_images/${barcode}.jpg`);

  // for await (const chunk of newFile) {
  //   console.log(">>> ");
  // }

  const access_token = await token_login();
  if (!access_token) throw new Error("sem permissao");

  // personally I'd function out the inner body here and just call
  // to the function and pass in the newFile

  const form_data = new FormData();
  form_data.append("file", newFile);
  const request_config = {
    method: "PUT",
    url: `${BASE_URL}/product/image/${productID}`,
    headers: {
      Authorization: "Bearer " + access_token,
      "Content-Type": `multipart/form-data; boundary=${form_data._boundary}`,
    },
    data: form_data,
  };
  return await axios(request_config);
};

const get_products = async () => {
  try {
    const token = await token_login();
    if (!token) throw new Error("sem permissao");

    const headers = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };


    let page = 1;
    let totalPages = 2;
    let products = [];
    while (page <= totalPages) {
      const response = await axios.get(
        `${BASE_URL}/product?page=${page}&limit=1`,
        headers
      );
      totalPages = Number(response.data.meta.totalPages);
      page++;
      // console.log(response.data.items);
      // console.log(response.data.meta);
      console.log(`Carregando ${page} de ${totalPages} total na API`);
      products.push(response.data.items[0])
    }

    return products;
  } catch (error) {
    console.log(error);
    // console.log(error);
  }
};

const create_section = async (section_info) => {
  try {
    const token = await token_login();
    if (!token) throw new Error("sem permissao");

    const headers = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        company_name: config.companyDatabase,
      },
    };

    const response = await axios.post(
      `${BASE_URL}/section`,
      section_info,
      headers
    );

    return response.data;
  } catch (error) {
    console.log(error)
  }
}

const update_product = async (product_update_info, productID) => {
  try {
    const token = await token_login();
    if (!token) throw new Error("sem permissao");

    const headers = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        company_name: config.companyDatabase,
      },
    };

    const response = await axios.patch(
      `${BASE_URL}/product/${productID}`,
      product_update_info,
      headers
    );

    return response.data;
  } catch (error) {
    console.log(error)
  }
}

module.exports = { create_product, create_section, upload_image, get_products, update_product };
