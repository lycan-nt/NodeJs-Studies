const { create_section } = require("./flink-api.service");
const { getSectionsByProduct } = require("../repositories/product.repository");

const getSectionID = async (PROCOD) => {
  // get local section
  const sectionCapitalCaseFormat = await getSectionsByProduct(PROCOD);

  if (sectionCapitalCaseFormat) {
    // create or get section from flink api
    const res_section_api = await create_section({
      name: sectionCapitalCaseFormat,
    });

    return res_section_api.section.id;
  } else {
    return 1;
  }
};

module.exports = {
  getSectionID,
};
