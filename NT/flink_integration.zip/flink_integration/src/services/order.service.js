const connectionFactory = require('../config/firebird');

const getOrders = async () => {
    // return await connectionFactory.search("SELECT FIRST 10 * FROM produto ORDER BY PROCOD DESC")
    
},
