const { getProducts } = require("./services/product.service");

(async () => {
  try {
    console.log('Integrador em primeira carga inicializado.')

    const initTime = Date.now();
    const products = await getProducts()
    const endTime = Date.now() - initTime;
    const durationTime = Math.floor((endTime % (1000 * 60)) / 1000).toFixed(2).replace('.',':');
    // const durationTime = ((endTime/60000).toFixed(2)).replace('.',':');
    console.log(`O processamento levou ${endTime} ms / ${durationTime} segundos para ser concluido!`)

    // console.log(products)
  } catch (error) {
    console.log(error);
  }
})();
