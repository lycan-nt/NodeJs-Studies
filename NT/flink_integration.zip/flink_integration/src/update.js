const { updateProducts } = require("./services/product.service");

(async () => {
  try {
    console.log('Integrador de precos inicializado.')

    const initTime = Date.now();
    
    await updateProducts()
    
    const endTime = Date.now() - initTime;
    const durationTime = Math.floor((endTime % (1000 * 60)) / 1000).toFixed(2).replace('.',':');
    // const durationTime = ((endTime/60000).toFixed(2)).replace('.',':');
    console.log(`Tempo de execucao: ${endTime} ms / ${durationTime} segundos`)

    // console.log(products)
  } catch (error) {
    console.log(error);
  }
})();
