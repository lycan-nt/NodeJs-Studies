const firebird = require("../config/firebird");

const getProductsRepository = async (qtd = null) => {
  const qtdRows = qtd ? `FIRST ${qtd}` : ""; // 'FIRST 1'
  return await firebird.query(
    `SELECT ${qtdRows} * FROM produto` // WHERE PROPRCOFEVAR != 0 ORDER BY PROCOD ASC
  );
};

const getCountTotalProducts = async () => {
  const res = await firebird.query("SELECT COUNT(*) as QTD FROM produto");
  return res[0].QTD;
};

const getBarcode = async (procod) => {
  const res = await firebird.query(
    `SELECT PROCODAUX FROM produtoaux WHERE PROCOD = ${procod}`
  );

  if (res.length > 0) {
    let barcode = ``;
    let strBarcode = String(res[0].PROCODAUX).trim();
    strBarcode = strBarcode.replace(/^0+/, "");

    if (strBarcode.length == 13) {
      barcode = strBarcode;
    }else{
      barcode = ''
    }
    // console.log("resultado final: ", barcode);

    return barcode;
  } else {
    return '';
  }
};

// estoque do produto
const getStock = async (procod) => {
  const res = await firebird.query(
    `SELECT ESTATU FROM ESTOQUE WHERE PROCOD = ${procod}`
  );
  return res[0].ESTATU;
};

const getAllSections = async () => {
  const res = await firebird.query(
    `SELECT * FROM SECAO`
  );
  return res
}

const getSectionsByProduct = async (procod) => {
  const sectionCode = await firebird.query(
    `SELECT SECCOD FROM PRODUTO WHERE PROCOD = ${procod}`
  );

  // check if product has section
  if(!sectionCode || sectionCode.length == 0 || !sectionCode[0].SECCOD.trim()){
    return
  }
  
  const section = await firebird.query(
    `SELECT * FROM SECAO WHERE SECCOD = ${sectionCode[0].SECCOD}`
  );

  if(!section || section.length == 0 || !section[0].SECDES.trim()){
    return
  }

  return section[0].SECDES.split(' ').map(w => w[0].toUpperCase() + w.substr(1).toLowerCase()).join(' ');
}

module.exports = {
  getProductsRepository,
  getCountTotalProducts,
  getBarcode,
  getStock,
  getAllSections,
  getSectionsByProduct
};
