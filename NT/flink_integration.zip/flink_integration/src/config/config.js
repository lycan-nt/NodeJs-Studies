module.exports = {
  provider: "firebird",
  // apiUrl: "http://api.flink.life/v1",
  apiUrl: "http://localhost:3000/v1",
  auth: {
    login: "77988171909",
    password: "123456nT",
  },
  companyDatabase: "cliente2",
};
