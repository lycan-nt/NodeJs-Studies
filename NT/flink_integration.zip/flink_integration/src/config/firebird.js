const Firebird = require("node-firebird");
// const fb = require("firebird");

const options = {
  host: "127.0.0.1",
  port: 3050,
  database:
    "/Users/geovanent/projetos/node/flink/flink_integration/src/config/syspdv_srv.fdb",
  user: "SYSDBA",
  password: "masterkey",
//   lowercase_keys: false,
//   role: "",
//   pageSize: 4096,
};

// const firebird = {
//   query: (sql) => {
//     try {
//       conn = fb.createConnection();

//       conn.connect(
//         options.database,
//         options.user,
//         options.password,
//         options.role,
//         function (err) {
//           conn.query('SELECT FIRST 10 * FROM produto ORDER BY PROCOD DESC', function (err, qres) {
//             // var row = qres.fetchSync(1,true), fields = [],fr = [];

//             qres.fetch("all", true, function (obj) {
//                 var fields = [],fr = [];
//                 if(first){
//                  for(var f in obj){
//                   fields.push(f);
//                   fr.push(obj[f]);
//                  };
//                  console.log('"fields":'+JSON.stringify(fields)+',\n "data":['+JSON.stringify(fr));
//                  first = false;
//                 }
//                 else
//                 {
//                   for(var f in obj){fr.push(obj[f]);};
//                   console.log(','+JSON.stringify(fr));
//                 }
//             });
//             // console.log(qres)
//           });
//           conn.on("error", function () {
//             console.log("deu algum erro");
//           });
//         }
//       );
//     } catch (e) {
//       console.log("deu ruim", e);
//     }
//   },
// };



const firebird = {
  query: (sql) => {
    return new Promise((resolve, reject) => {
      Firebird.attach(options, function (err, db) {
          
        if (err) { 
            console.log(err) 
            reject(err); 
        }

        db.query(sql, function (err, result) {
          if (err) {
            console.log(sql);
            reject(err);
            return;
          }

          db.detach();
          resolve(result);
        });
      });
    });
  },
};


module.exports = firebird;