docker-compose rm -f -s -v api
#docker-compose build --no-cache
docker-compose build
docker-compose up -d api
