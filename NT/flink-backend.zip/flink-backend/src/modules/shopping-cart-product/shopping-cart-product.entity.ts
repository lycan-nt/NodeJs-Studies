/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm'
import { Product } from '../product/product.entity'
import { ShoppingCart } from '../shopping-cart/shopping-cart.entity'

@Entity()
@Unique(['id'])
export class ShoppingCartProduct extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @ManyToOne(() => Product, Product => Product.shopping_carts, { nullable: false, eager: true })
  @JoinColumn({ name: 'product_id' })
  product_id: Product

  @ManyToOne(() => ShoppingCart, shoppingCart => shoppingCart.products, { nullable: false, eager: true })
  @JoinColumn({ name: 'shopping_cart_id' })
  shopping_cart_id: ShoppingCart

  @Column({ nullable: false, type: 'decimal', precision: 12, scale: 2, default: 1.0 })
  multiplier_price: number

  @Column({ nullable: true, type: 'int', default: 1 })
  quantity: number

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
