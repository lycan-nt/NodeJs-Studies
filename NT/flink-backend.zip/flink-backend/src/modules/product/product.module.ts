import { ProductService } from './product.service'
import { Module } from '@nestjs/common'
import { ProductController } from './product.controller'
import { TypeOrmModule } from '@nestjs/typeorm'
import { ProductRepository } from './product.repository'
import { PassportModule } from '@nestjs/passport'
import { ProductImageService } from './product-image.service'

@Module({
  imports: [
    TypeOrmModule.forFeature([ProductRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' })
  ],
  controllers: [ProductController],
  providers: [ProductService, ProductImageService],
})
export class ProductModule {}
