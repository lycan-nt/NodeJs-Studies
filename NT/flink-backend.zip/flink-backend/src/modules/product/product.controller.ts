import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Req,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
  ValidationPipe,
} from '@nestjs/common'
import { AuthGuard } from '@nestjs/passport'
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger'
import { AccessLevel } from '../auth/role.decorator'
import { AccessLevelGuard } from '../auth/roles.guard'
import { User, UserAccessLevel } from '../users/user.entity'
import { ProductDto } from './dto/product.dto'
import { FindProductQueryDto } from './dto/find-product-query.dto'
import { ReturnProductDto } from './dto/return-product.dto'
import { ProductService } from './product.service'
import { FileInterceptor } from '@nestjs/platform-express'
import { multerOptions } from 'src/configs/multer.config'
import { ProductImageService } from './product-image.service'
import { extname } from 'path'

@ApiTags('product')
@ApiBearerAuth('JWT')
@Controller('product')
export class ProductController {
  constructor(
    private readonly productService: ProductService,
    private readonly productImageService: ProductImageService,
  ) {}

  @ApiOperation({
    summary: 'Find and list product',
  })
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @Get()
  async findProducts(@Query(ValidationPipe) queryDto: FindProductQueryDto, @Req() req) {
    const user = req.user as User
    queryDto.user_id = user.id
    return await this.productService.findProducts(queryDto)
  }

  @ApiOperation({
    summary: 'Create a new product',
  })
  @Post()
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async create(@Body(ValidationPipe) createProductDto: ProductDto): Promise<ReturnProductDto> {
    const product = await this.productService.createProduct(createProductDto)
    return {
      message: 'Produto cadastrado com sucesso!',
      product
    }
  }

  @ApiOperation({
    summary: 'Update a product',
  })
  @Patch(':id')
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async update(@Body() updateProductDto: ProductDto, @Param('id') id: string) {
    return await this.productService.update(updateProductDto, Number(id))
  }

  @ApiOperation({
    summary: 'Find a product by id',
  })
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @Get(':id')
  async findbyId(@Param('id') id: number, @Req() req) {
    const user = req.user as User
    return await this.productService.findById(id, Number(user.id))
  }

  @ApiOperation({
    summary: 'Find a product by barcode',
  })
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @Get('findbybarcode/:barcode')
  async findbyBarcode(@Param('barcode') barcode: string, @Req() req) {
    const user = req.user as User
    return await this.productService.findbyBarcode(barcode, Number(user.id))
  }

  @ApiOperation({
    summary: 'Delete a product',
  })
  @Delete(':id')
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async delete(@Param('id') id: string) {
    await this.productService.delete(Number(id))
    return {
      message: 'Produto deletado com sucesso!',
    }
  }

  @Put('image/s3/:productID')
  @UseInterceptors(FileInterceptor('file'))
  async uploadImage(@Param('productID') productID: number, @UploadedFile() file: any) {

    const product = await this.productService.findById(productID)
    const newFilename = `${product.barcode}${extname(file.originalname)}`

    let s3URL = await this.productService.verifyImageS3(newFilename)
    if( !s3URL ){
      console.debug(`A imagem do produto ${productID} nao existia ainda`)
      s3URL = await this.productService.uploadS3Image(file, newFilename)
    }else{
      console.debug(`Imagem do produto ${productID} já existia`, s3URL)
    }

    await this.productService.updateImageProduct(productID, s3URL)

    return { message: `Imagem '${newFilename}' inserida no produto -> ${productID}` }
  }

  @Get('image/s3/:filename')
  async getImageS3(@Param('filename') filename: string) {
    return await this.productService.getImageS3(filename)
  }

  @Put('image/:productID')
  @UseGuards(AuthGuard(), AccessLevelGuard)
  @UseInterceptors(FileInterceptor('file', multerOptions))
  async upload(@Param('productID') productID: number, @UploadedFile() file: any): Promise<any> {
    const product = await this.productService.findById(productID)
    const newFilename = `${product.barcode}${extname(file.filename)}`
    await this.productImageService.rename(file.path, `./images/${newFilename}`)
    console.log(file)

    await this.productService.updateImageProduct(productID, newFilename)
    console.log(`Produto ${productID}`)
    // console.log(file)
    return { message: `Imagem '${file.originalname}' inserida no produto -> ${productID}` }
  }

  @Get('image/:filename')
  async seeUploadedFile(@Param('filename') filename: string, @Res() res) {
    // const product = await this.productService.findById(productID)
    // const filename = `${product.barcode}.jpg`
    // const filename = product.image_url.substring(product.image_url.lastIndexOf('/') + 1)
    // console.log(`filename: `,filename)
    await this.productImageService.checkImageExists(filename)

    return res.sendFile(filename, { root: './images' })
  }

  @ApiOperation({
    summary: 'Find product ID by params',
  })
  // @UseGuards(AuthGuard(), AccessLevelGuard)
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @Get('searchProductID/:id')
  async searchProductID(@Param('id') id: string) {
    return await this.productService.searchProductID(id)
  }
}
