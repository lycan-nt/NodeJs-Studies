import { Brackets, EntityRepository, Repository } from 'typeorm'
import { Product } from './product.entity'
import { BadRequestException, ConflictException, InternalServerErrorException } from '@nestjs/common'
import {
  paginate,
  Pagination,
  IPaginationOptions,
} from 'nestjs-typeorm-paginate';
import { FindProductQueryDto } from './dto/find-product-query.dto'
import { ProductDto } from './dto/product.dto'
import { DepartmentProduct } from '../department-product/department-product.entity';
import { SectionProduct } from '../section-product/section-product.entity';
import { LikeProduct } from '../like-product/like-product.entity';

@EntityRepository(Product)
export class ProductRepository extends Repository<Product> {

  async findProducts(queryDto: FindProductQueryDto): Promise<Pagination<Product>> {

    const {
      description,
      is_offer,
      is_available,
      is_fractional,
      is_liked,
      user_id,
      department_id,
      section_id,
      page,
      limit,
      sort
    } = queryDto
    const query = this.createQueryBuilder('product')


    const options: IPaginationOptions = {
      page: Math.max(1, page || 1),
      limit: Math.min(100, limit || 10)
    }

    !!department_id && query.andWhere(qb => {
      const subQuery = qb.subQuery()
        .select("department_product.product_id")
        .from(DepartmentProduct, "department_product")
        .where("department_product.department_id = :department_id", { department_id })
        .getQuery();
      return "product.id IN " + subQuery;
    })

    !!section_id && query.andWhere(qb => {
      const subQuery = qb.subQuery()
        .select("section_product.product_id")
        .from(SectionProduct, "section_product")
        .where("section_product.section_id = :section_id", { section_id })
        .getQuery();
      return "product.id IN " + subQuery;
    })

    typeof (is_liked) !== "undefined" && query.andWhere(qb => {
      // conversão necessária, pois is_liked é atribuido como string e não como boolean
      const liked = ['true', '1'].includes(is_liked as unknown as string)
      const subQuery = qb.subQuery()
        .select("like_product.product_id")
        .from(LikeProduct, "like_product")
        .where("like_product.user_id = :user_id", { user_id })
        .getQuery();
      return `product.id ${liked ? 'IN' : 'NOT IN'} ${subQuery}`;
    })

    !!description && query.andWhere(new Brackets(qb => {
      qb.where('product.description ILIKE :description', { description: `%${description}%` })
        .orWhere('product.barcode ILIKE :description', { description: `%${description}%` })
    }))

    typeof (is_offer) !== "undefined"
      && query.andWhere('product.is_offer = :is_offer', { is_offer })
    typeof (is_available) !== "undefined"
      && query.andWhere('product.is_available = :is_available', { is_available })
    typeof (is_fractional) !== "undefined"
      && query.andWhere('product.is_fractional = :is_fractional', { is_fractional })

    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('likes.user_id', 'user')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')

    try {
      query.orderBy(JSON.parse(sort || "{}"))
      query.addOrderBy("product.image_url", "ASC")
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<Product>(query, options);
  }

  async findbyId(id: number, user_id?: number): Promise<Product> {
    const query = this.createQueryBuilder('product')

    query.where("product.id = :id", { id })
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')
    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('likes.user_id', 'user')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')

    return query.getOne()

  }

  async findbyBarcode(barcode: string, user_id?: number): Promise<Product> {
    const query = this.createQueryBuilder('product')

    query.where("product.barcode = :barcode", { barcode })
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')
    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('likes.user_id', 'user')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')
    query.loadRelationCountAndMap('product.reclamations_count', 'product.reclamations')

    return query.getOne()

  }

  async createProduct(createProductDto: ProductDto): Promise<Product> {
     // verify duplicated barcode
     const query = this.createQueryBuilder('product')
     query.where("product.barcode = :barcode", { barcode: createProductDto.barcode })
     const barcodeQuery = await query.getOne()
     if(barcodeQuery && createProductDto.barcode != ""){
       throw new BadRequestException('Já existe um produto com o mesmo código de barras cadastrado!')
     }

    const product = this.create({
      ...createProductDto,
    })

    try {
      return await this.save(product)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Produto já cadastrado')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar o produto no sistema.')
      }
    }
  }

  async searchProductID(id: string) {
    const query = this.createQueryBuilder('product')

    query.where("product.barcode = :id", { id })

    return query.getOne()

  }
}
