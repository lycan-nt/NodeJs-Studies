import { BadRequestException, Inject, Injectable, NotFoundException } from '@nestjs/common'
import { ProductDto } from './dto/product.dto'
import { FindProductQueryDto } from './dto/find-product-query.dto'
import { Product } from './product.entity'
import { ProductRepository } from './product.repository'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository } from 'typeorm'
import * as AWS from 'aws-sdk'
import { extname } from 'path'
import { v4 as uuid } from 'uuid'

@Injectable()
export class ProductService {
  private productRepository: ProductRepository
  private companyName: string
  private s3: AWS.S3

  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.productRepository = getCustomRepository(ProductRepository, this.companyName)
    this.s3 = new AWS.S3({
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      region: process.env.AWS_REGION,
    })
  }
  async findProducts(queryDto: FindProductQueryDto) {
    return await this.productRepository.findProducts(queryDto)
  }

  async createProduct(createProductDto: ProductDto) {
    return this.productRepository.createProduct(createProductDto)
  }

  async findById(id: number, user_id?: number): Promise<Product> {
    let product = null
    if (user_id) {
      product = await this.productRepository.findbyId(id, user_id)
    } else {
      product = await this.productRepository.findOne(id)
    }

    if (!product) throw new NotFoundException('Produto não encontrado')

    return product
  }

  async findbyBarcode(barcode: string, user_id?: number): Promise<Product> {
    const product = await this.productRepository.findbyBarcode(barcode, user_id)

    if (!product) throw new NotFoundException('Produto não encontrado')

    return product
  }

  async update(updateProductDto: ProductDto, id: number) {
    const result = await this.productRepository.update({ id }, updateProductDto)
    if (result.affected > 0) {
      return await this.findById(id)
    } else {
      throw new NotFoundException('Produto não encontrado')
    }
  }

  async delete(productId: number): Promise<void> {
    const result = await this.productRepository.delete({ id: productId })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi possivel encontrar o produto com o ID informado')
    }
  }

  async updateImageProduct(productId: number, filename: string): Promise<void> {
    const updateProductData = {
      // image_url: `${process.env.BASE_URL}/product/image/${filename}`
      image_url: `${filename}`,
    }

    const result = await this.productRepository.update({ id: productId }, updateProductData)
    if (result.affected === 0) {
      throw new NotFoundException('Não foi possivel encontrar o produto com o ID informado')
    }
  }

  async uploadS3Image(file: any, filename: string): Promise<any> {
    const AWS_S3_BUCKET_NAME = 'flink-products-images'

    const imageMimeTypes = ['image/jpg', 'image/jpeg', 'image/png', 'image/bmp']

    const mimeType = imageMimeTypes.find(im => im === file.mimetype)

    if (!mimeType) {
      console.log('formato nao suportado')
      throw new BadRequestException(`Formato ${extname(file.originalname)} não suportado!`)
    }

    // const urlKey = `products/${file.originalname}`
    const urlKey = `products/${filename}`
    const params = {
      Body: file.buffer,
      Bucket: AWS_S3_BUCKET_NAME,
      Key: urlKey,
    }

    await this.s3.putObject(params).promise()

    return `https://flink-products-images.s3.us-east-2.amazonaws.com/products/${filename}`
  }

  // generatePresignedUrl
  async getImageS3(filename: string) {
    try {
      const params = {
        Bucket: 'flink-products-images',
        Key: `products/${filename}`,
      }
      await this.s3.headObject(params).promise() //check if image exists else throw
      const url = await this.s3.getSignedUrlPromise('getObject', params)
      return { url }
    } catch (error) {
      if (error.code === 'NotFound') {
        throw new NotFoundException('Imagem não encontrada!')
      }
    }
  }

  async verifyImageS3(filename: string) {
    try {
      const params = {
        Bucket: 'flink-products-images',
        Key: `products/${filename}`,
      }
      await this.s3.headObject(params).promise() //check if image exists else throw

      return `https://flink-products-images.s3.us-east-2.amazonaws.com/products/${filename}`
    } catch (error) {
      if (error.code === 'NotFound') {
        return ''
      }
    }
  }

  async searchProductID(id: string) {
    return await this.productRepository.searchProductID(id)
  }
}
