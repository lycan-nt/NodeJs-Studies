import { Injectable, NotFoundException } from '@nestjs/common'
import * as fs from 'fs'

@Injectable()
export class ProductImageService {
  async checkImageExists(filename: string): Promise<void> {
    const filePath = `./images/${filename}`
    try {
      await fs.promises.access(filePath)
      // The check succeeded
    } catch (error) {
      // The check failed
      throw new NotFoundException(`Imagem ${filename} não encontrada!`)
    }
  }

  async rename(path, newFileNamePath){
    fs.rename(path, newFileNamePath, (error) => {
      if (error) {
        throw error;
      }
      console.log("Successfully Renamed File!");
    });
  }
}
