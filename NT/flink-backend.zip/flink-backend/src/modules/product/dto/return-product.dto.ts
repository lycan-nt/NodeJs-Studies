import { Product } from '../product.entity'

export class ReturnProductDto {
  product: Product
  message: string
}
