import { ApiProperty } from '@nestjs/swagger'
import { IsOptional, MaxLength, IsBoolean, IsString, IsNumber } from 'class-validator'

export class ProductDto {

  @ApiProperty({ required: true })
  @IsString()
  @MaxLength(255, {
    message: 'A descrição deve ter no máximo 255 caracteres',
  })
  description: string

  @ApiProperty({ required: true })
  @IsString()
  @MaxLength(13, {
    message: 'O código de barras deve ter no máximo 13 caracteres',
  })
  barcode: string

  @ApiProperty({ required: false })
  @IsNumber()
  price: number

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  is_offer: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  is_fractional: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  is_active: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  is_avaliable: boolean
}
