import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto'
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, MaxLength, IsBooleanString, IsNumber, IsNumberString } from 'class-validator';

export class FindProductQueryDto extends BaseQueryParametersDto {

  @ApiPropertyOptional({ description: 'Busca pela descrição' })
  @IsOptional()
  @MaxLength(255, { message: 'A descrição deve ter no máximo 255 caracteres' })
  description: string

  @ApiPropertyOptional({ description: 'Filtra ofertas' })
  @IsOptional()
  @IsBooleanString({ message: 'is_active: informe apenas true ou false' })
  is_offer: boolean

  @ApiPropertyOptional({ description: 'Filtra produtos fracionados' })
  @IsOptional()
  @IsBooleanString({ message: 'is_fractional: informe apenas true ou false' })
  is_fractional: boolean

  @ApiPropertyOptional({ description: 'Filtra produtos em estoque' })
  @IsOptional()
  @IsBooleanString({ message: 'is_available: informe apenas true ou false' })
  is_available: boolean

  @ApiPropertyOptional({ description: 'Filtra produtos favoritados pelo usuário' })
  @IsOptional()
  @IsBooleanString({ message: 'is_liked: informe apenas true ou false' })
  is_liked: boolean

  @ApiPropertyOptional({ description: 'Id do usuário para relacionar com os likes (automaticamente preenchido para customer)' })
  @IsOptional()
  @IsNumberString({ no_symbols: true }, { message: 'user_id: informe um id válido para usuário' })
  user_id: Number

  @ApiPropertyOptional({ description: 'Id do departamento' })
  @IsOptional()
  @IsNumberString({ no_symbols: true }, { message: 'department_id: informe um id válido para o departamento' })
  department_id: Number

  @ApiPropertyOptional({ description: 'Id da seção' })
  @IsOptional()
  @IsNumberString({ no_symbols: true }, { message: 'section_id: informe um id válido para a seção' })
  section_id: Number

}

