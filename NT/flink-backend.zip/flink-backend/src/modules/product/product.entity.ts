/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany, ManyToMany, ManyToOne, JoinColumn, JoinTable } from 'typeorm'
import { Company } from '../company/company.entity'
import { Department } from '../department/department.entity'
import { LikeProduct } from '../like-product/like-product.entity'
import { OrderProduct } from '../order-product/order-product.entity'
import { Reclamation } from '../reclamation/reclamation.entity'
import { Section } from '../section/section.entity'
import { ShoppingCartProduct } from '../shopping-cart-product/shopping-cart-product.entity'

export enum PaymentType {
  App = 'app',
  Debit = 'debit',
  Credit = 'credit',
}

export enum Status {
  Paid = 'paid',
  GiveUp = 'give_up',
  InProgress = 'in_progress',
}

@Entity()
@Unique(['id'])
export class Product extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ nullable: false, type: 'varchar', length: 255 })
  description: string

  @Column({ nullable: false, type: 'varchar', length: 50 })
  barcode: string

  @Column({ nullable: true, type: 'varchar', length: 50 })
  barcode_reference: string

  @Column({ nullable: true, type: 'varchar', length: 50 })
  product_id_in_company_database: string

  @Column({ nullable: false, type: 'decimal', precision: 12, scale: 2 })
  price: number

  @Column({ nullable: false, type: 'boolean', default: false })
  is_offer: boolean

  @Column({ nullable: false, type: 'boolean', default: false })
  is_fractional: boolean

  @Column({ nullable: true, type: 'decimal', precision: 12, scale: 2 })
  original_price: number

  @Column({ nullable: true, type: 'date' })
  due_date: Date

  @Column({ nullable: false, type: 'int', default: 0 })
  max_amount: number

  @Column({ nullable: false, type: 'boolean', default: false })
  is_active: boolean

  @Column({ nullable: false, type: 'boolean', default: false })
  is_available: boolean

  @Column({ nullable: false, type: 'int', default: 0 })
  section_id: number

  @Column({ nullable: true, type: 'varchar', length: 255 })
  image_url: string

  @Column({ nullable: true, type: 'varchar', length: 255 })
  note: string

  @Column({ nullable: true, type: 'varchar', length: 255 })
  unit_of_measurement: string

  @Column({ nullable: false, type: 'boolean', default: false })
  is_alcohol_drink: boolean

  @Column({ nullable: false, type: 'int' })
  department_item_id: number

  @Column({ nullable: false, type: 'int' })
  section_item_id: number

  @ManyToOne(() => Company, company => company.products, { nullable: false, eager: true })
  @JoinColumn({ name: 'company_id' })
  company_id: Company

  @OneToMany(() => Reclamation, reclamation => reclamation.product_id)
  reclamations: Reclamation[]

  @OneToMany(() => ShoppingCartProduct, shoppingCartProduct => shoppingCartProduct.product_id)
  shopping_carts: ShoppingCartProduct[]

  @OneToMany(() => LikeProduct, likeProduct => likeProduct.product_id)
  likes: LikeProduct[]

  @OneToMany(() => OrderProduct, orderProduct => orderProduct.product_id)
  orders: OrderProduct[]

  @ManyToMany(() => Department, department => department.products)
  @JoinTable({
    name: 'department_product',
    joinColumn: {
      name: 'product_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'department_id',
      referencedColumnName: 'id',
    },
  })
  departments: Department[];

  @ManyToMany(() => Section, section => section.products)
  @JoinTable({
    name: 'section_product',
    joinColumn: {
      name: 'product_id',
      referencedColumnName: 'id',
    },
    inverseJoinColumn: {
      name: 'section_id',
      referencedColumnName: 'id',
    },
  })
  sections: Section[];

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
