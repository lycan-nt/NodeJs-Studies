/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToMany, ManyToOne, JoinColumn } from 'typeorm'
import { Department } from '../department/department.entity';
import { Product } from '../product/product.entity'
import { Section } from '../section/section.entity';

@Entity('section_product')
export class SectionProduct extends BaseEntity {

  @ManyToOne(() => Product, product => product.sections, { nullable: false, eager: true, primary: true })
  @JoinColumn({ name: 'product_id' })
  product: Product;

  @ManyToOne(() => Section, section => section.products, { nullable: false, eager: true, primary: true })
  @JoinColumn({ name: 'section_id' })
  section: Section;

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
