import { Inject, Injectable, NotFoundException } from '@nestjs/common'
import { UserRepository } from './users.repository'
import { CreateUserDto } from './dto/create-user.dto'
import { User } from './user.entity'
import { UpdateUserDto } from './dto/update-user.dto'
import { FindUsersQueryDto } from './dto/find-users-query-dto'
import { Pagination } from 'nestjs-typeorm-paginate'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository } from 'typeorm'

@Injectable()
export class UsersService {
  private userRepository: UserRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.userRepository = getCustomRepository(UserRepository, this.companyName)
  }

  async createAdminUser(createUserDto: CreateUserDto): Promise<User> {
    return this.userRepository.createUser(createUserDto)
  }

  async findUserById(userId: number): Promise<User> {
    const user = await this.userRepository.findOne(userId, {
      // select: ['email', 'first_name', 'id'],
    })

    if (!user) throw new NotFoundException('Usuário não encontrado')

    return user
  }

  async updateUser(updateUserDto: UpdateUserDto, id: number) {
    const result = await this.userRepository.update({ id }, updateUserDto)
    if (result.affected > 0) {
      const user = await this.findUserById(id)
      return user
    } else {
      throw new NotFoundException('Usuário não encontrado')
    }
  }

  async deleteUser(userId: number) {
    const result = await this.userRepository.delete({ id: userId })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrado um usuário com o ID informado')
    }
  }

  async findUsers(queryDto: FindUsersQueryDto): Promise<Pagination<User>> {
    return await this.userRepository.findUsers(queryDto)
  }
}
