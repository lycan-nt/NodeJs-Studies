import {
  IsEmail,
  IsNotEmpty,
  MaxLength,
  IsNumberString,
  IsDate,
  IsBoolean,
  IsLatitude,
  Length,
  IsNumber,
  IsEnum,
  IsOptional,
  IsDateString,
  IsLongitude,
  IsString,
  MinLength,
  Matches,
} from 'class-validator'
import { ApiProperty } from '@nestjs/swagger'
import { Genre, UserAccessLevel } from '../user.entity'
import { Company } from 'src/modules/company/company.entity'

export class CreateUserDto {
  @ApiProperty()
  @IsNotEmpty({
    message: 'Informe o nome do usuário',
  })
  @MaxLength(50, {
    message: 'O primeiro nome deve ter menos de 50 caracteres',
  })
  first_name: string

  @ApiProperty()
  @IsNotEmpty({
    message: 'Informe o último nome do usuário',
  })
  @MaxLength(50, {
    message: 'O último nome deve ter menos de 50 caracteres',
  })
  last_name: string

  @ApiProperty({ enum: Genre, enumName: 'Genre', required: false })
  @IsOptional()
  @MaxLength(1, {
    message: 'O gênero deve ser F, M ou N',
  })
  genre: Genre

  @ApiProperty({ required: false })
  @IsOptional()
  @IsEmail({}, { message: 'Informe um endereço de email válido', },)
  @MaxLength(255, { message: 'O endereço de email deve ter menos de 255 caracteres', })
  email: string

  @ApiProperty()
  @IsNotEmpty({ message: 'Informe um número de telefone', })
  @IsNumberString({ no_symbols: true }, { message: 'O telefone deve conter apenas números' })
  @MaxLength(20, { message: 'O número de telefone deve ter menos de 20 caracteres', })
  phone: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumberString()
  @MaxLength(11, { message: 'O número de CPF deve ter menos de 11 caracteres', })
  cpf: string

  @ApiProperty()
  @IsString({
    message: 'Informe uma senha válida',
  })
  @MinLength(6, {
    message: 'A senha deve ter no mínimo 6 caracteres',
  })
  @MaxLength(32, {
    message: 'A senha deve ter no máximo 32 caracteres.',
  })
  @Matches(/((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/, {
    message:
      'A senha deve conter pelo menos uma letra maiúscula, uma letra minúscula, um número ou um símbolo',
  })
  password: string

  @ApiProperty({ enum: UserAccessLevel, enumName: 'UserAccessLevel', required: false, default: UserAccessLevel.Customer })
  @IsOptional()
  @IsEnum(UserAccessLevel)
  access_level: UserAccessLevel

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDate({ message: 'Informe uma data válida para o último acesso' })
  last_access: Date

  @ApiProperty()
  @IsNotEmpty({ message: 'Informe o código da empresa associada' })
  @IsNumber()
  company_id: Company

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDateString()
  birthday: Date

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  allow_offers: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  allow_notifications: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsLatitude({ message: 'Informe uma coordenada válida.' })
  latitude: number

  @ApiProperty({ required: false })
  @IsOptional()
  @IsLongitude({ message: 'Informe uma coordenada válida.' })
  longitude: number

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @MaxLength(255, { message: 'O endereço deve ter menos de 255 caracteres', })
  street: string

  @ApiProperty({ required: false })
  @IsOptional()
  @MaxLength(10, { message: 'O número da residência deve ter menos de 10 caracteres', })
  number: string

  @ApiProperty({ required: false })
  @IsOptional()
  @MaxLength(100, { message: 'O nome do bairro deve ter menos de 100 caracteres', })
  district: string

  @ApiProperty({ required: false })
  @IsOptional()
  @MaxLength(8, { message: 'O CEP deve ter menos de 8 caracteres', })
  cep: string

  @ApiProperty({ required: false })
  @IsOptional()
  @Length(2, 2, { message: 'A Unidade Federativa deve ter 2 caracteres', })
  uf: string

  @ApiProperty({ required: false })
  @IsOptional()
  @MaxLength(255, { message: 'O nome da cidade deve ter menos de 255 caracteres', })
  city: string

  @ApiProperty({ description: 'Define se o usuário está ativo', default: false, required: false })
  @IsOptional()
  is_active: Boolean = false
}
