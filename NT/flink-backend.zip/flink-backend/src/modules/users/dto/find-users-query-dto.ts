import { ApiPropertyOptional } from '@nestjs/swagger'
import { IsBoolean, IsBooleanString, IsEmail, IsNumberString, IsOptional, IsString, MaxLength } from 'class-validator'
import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto'

export class FindUsersQueryDto extends BaseQueryParametersDto {

  @ApiPropertyOptional({ description: 'Busca pelo primeiro nome' })
  @IsOptional()
  @MaxLength(50, { message: 'O primeiro nome deve ter menos de 50 caracteres' })
  first_name: string

  @ApiPropertyOptional({ description: 'Busca pelo último nome' })
  @IsOptional()
  @MaxLength(50, { message: 'O último nome deve ter menos de 50 caracteres' })
  last_name: string

  @ApiPropertyOptional({ description: 'Busca por email' })
  @IsOptional()
  @MaxLength(255, { message: 'O endereço de email deve ter menos de 255 caracteres' })
  email: string

  @ApiPropertyOptional({ description: 'Busca por telefone' })
  @IsOptional()
  @MaxLength(20, { message: 'O número de telefone deve ter menos de 20 caracteres', })
  phone: string

  @ApiPropertyOptional({ description: 'Busca pelo CPF' })
  @IsOptional()
  @IsNumberString({ no_symbols: true }, { message: 'CPF deve conter apenas números' })
  @MaxLength(11, { message: 'O número de CPF deve ter menos de 11 caracteres', })
  cpf: string

  @ApiPropertyOptional({ description: 'Filtra por usuário ativos ou não' })
  @IsOptional()
  @IsBooleanString({ message: 'is_active: informe apenas true ou false' })
  is_active: boolean
}
