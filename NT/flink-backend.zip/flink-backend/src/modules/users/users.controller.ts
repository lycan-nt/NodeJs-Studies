import { Controller, Post, Body, ValidationPipe, UseGuards, Get, Param, Patch, Delete, Query, Req, ForbiddenException, UsePipes } from '@nestjs/common'
import { ApiBearerAuth, ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger'
import { CreateUserDto } from './dto/create-user.dto'
import { UsersService } from './users.service'
import { ReturnUserDto } from './dto/return-user.dto'
import { AuthGuard } from '@nestjs/passport'
import { AccessLevelGuard } from '../auth/roles.guard'
import { AccessLevel } from '../auth/role.decorator'
import { UpdateUserDto } from './dto/update-user.dto'
import { UserAccessLevel } from './user.entity'
import { FindUsersQueryDto } from './dto/find-users-query-dto'

@ApiTags('users')
@ApiBearerAuth('JWT')
@Controller('users')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class UsersController {
  constructor(private usersService: UsersService) { }

  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async createAdminUser(@Body(ValidationPipe) createUserDto: CreateUserDto): Promise<ReturnUserDto> {
    const user = await this.usersService.createAdminUser(createUserDto)
    return {
      user,
      message: 'Administrador cadastrado com sucesso',
    }
  }

  @Get(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async findUserById(@Param('id') id): Promise<ReturnUserDto> {
    const user = await this.usersService.findUserById(id)
    return {
      user,
      message: 'Usuário encontrado',
    }
  }

  @Patch(':id')
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async updateUser(
    @Body() updateUserDto: UpdateUserDto,
    @Param('id') id: number,
    @Req() req: any) {
    const { user } = req

    if ([UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)) {
      return this.usersService.updateUser(updateUserDto, id)
    } else if (user.id === Number(id)) {
      updateUserDto.access_level = user.access_level
      return this.usersService.updateUser(updateUserDto, id)
    }
    throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
  }

  @Delete(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async deleteUser(@Param('id') id: number) {
    await this.usersService.deleteUser(id)
    return {
      message: 'Usuário removido com sucesso',
    }
  }

  @Get()
  @ApiOperation({
    summary: 'Lista todos usuários',
    description: 'Lista todos os usuário cadastrados'
  })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async findUsers(@Query(ValidationPipe) query: FindUsersQueryDto) {
    const found = await this.usersService.findUsers(query)
    return found
  }
}
