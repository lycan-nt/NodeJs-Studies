import { EntityRepository, Repository } from 'typeorm'
import { User, UserAccessLevel } from './user.entity'
import { CreateUserDto } from './dto/create-user.dto'
import * as bcrypt from 'bcrypt'
import * as crypto from 'crypto'
import { BadRequestException, ConflictException, ForbiddenException, InternalServerErrorException, UnauthorizedException } from '@nestjs/common'
import { FindUsersQueryDto } from './dto/find-users-query-dto'
import { VerificationCodeDto } from '../auth/dto/verification-code.dto'
import { CredentialsDto } from '../auth/dto/credentials.dto'
import { ChangePasswordDto } from '../auth/dto/change-password.dto'
import {
  paginate,
  Pagination,
  IPaginationOptions,
} from 'nestjs-typeorm-paginate';
import { AuthEmployeeDto } from '../auth/dto/auth-employee.dto'

@EntityRepository(User)
export class UserRepository extends Repository<User> {
  async findUsers(queryDto: FindUsersQueryDto): Promise<Pagination<User>> {

    const {
      first_name,
      last_name,
      email,
      phone,
      cpf,
      is_active,
      page,
      limit,
      sort
    } = queryDto
    const query = this.createQueryBuilder('user')

    const options: IPaginationOptions = {
      page: Math.max(1, page || 1),
      limit: Math.min(100, limit || 10)
    }

    !!first_name && query.andWhere('user.first_name ILIKE :first_name', { first_name: `%${first_name}%` })
    !!last_name && query.andWhere('user.last_name ILIKE :last_name', { last_name: `%${last_name}%` })
    !!email && query.andWhere('user.email ILIKE :email', { email: `%${email}%` })
    !!phone && query.andWhere('user.phone ILIKE :phone', { phone: `%${phone}%` })
    !!cpf && query.andWhere('user.cpf ILIKE :cpf', { cpf: `%${cpf}%` })
    typeof (is_active) != "undefined"
      && query.andWhere('user.is_active = :is_active', { is_active })
    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<User>(query, options);
  }

  async createUser(createUserDto: CreateUserDto, accessLevel?: UserAccessLevel): Promise<User> {
    const user = this.create({
      ...createUserDto,
      access_level: accessLevel || createUserDto.access_level,
      confirmation_token: crypto.randomBytes(32).toString('hex'),
    })

    user.salt = await bcrypt.genSalt();
    if (!!createUserDto.password)
      user.password = await this.hashPassword(createUserDto.password, user.salt);

    try {
      await this.save(user)
      delete user.confirmation_token
      delete user.access_token_google
      delete user.recover_token
      delete user.password
      delete user.salt
      return user
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Usuário já existe')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar o usuário no banco de dados')
      }
    }
  }

  async changePassword(changePasswordDto: ChangePasswordDto, user: User) {
    user.salt = await bcrypt.genSalt();
    user.password = await this.hashPassword(changePasswordDto.new_password, user.salt);
    await this.save(user)
  }

  async checkPhoneExists(phoneNumber: string): Promise<User> {
    const user = await this.findOneOrFail(
      { phone: phoneNumber },
      { select: ['id', 'phone'], })
    return user
  }

  async checkCredentials(credentialsDto: CredentialsDto): Promise<User> {
    const { phone, password } = credentialsDto;
    const user = await this.findOne({ phone }, {
      select: [
        'id', 'first_name', 'last_name',
        'genre', 'email', 'phone', 'cpf',
        'password', 'access_level', 'last_access',
        'birthday', 'allow_offers', 'allow_notifications',
        'latitude', 'longitude', 'street', 'number',
        'district', 'cep', 'uf', 'city', 'is_active',
        'salt', 'company_id', 'created_at', 'updated_at'
      ]
    });

    if (!user || !await user.checkPassword(password))
      throw new UnauthorizedException('Usuário ou senha incorretos')

    if (!user.is_active)
      throw new ForbiddenException('Usuário inativo')

    return user;
  }

  async checkCredentialsEmployee(authEmployeeDto: AuthEmployeeDto): Promise<User> {
    const { cpf, password } = authEmployeeDto;
    const user = await this.findOne({ cpf }, {
      select: [
        'id', 'first_name', 'last_name',
        'genre', 'email', 'phone', 'cpf',
        'password', 'access_level', 'last_access',
        'birthday', 'allow_offers', 'allow_notifications',
        'latitude', 'longitude', 'street', 'number',
        'district', 'cep', 'uf', 'city', 'is_active',
        'salt', 'company_id', 'created_at', 'updated_at'
      ]
    });

    if (!user || !await user.checkPassword(password))
      throw new UnauthorizedException('Usuário ou senha incorretos')

    if (!user.is_active)
      throw new ForbiddenException('Usuário inativo')

    return user;
  }

  async checkCredentialsSmsCode(verificationCodeDto: VerificationCodeDto): Promise<User> {
    const { verificationCode } = verificationCodeDto
    const user = await this.findOne(
      { phone: verificationCode, is_active: true },
      {
        select: ['id', 'salt', 'password'],
      },
    )

    if (user) {
      return user
    } else {
      return null
    }
  }

  private async hashPassword(password: string, salt: string): Promise<string> {
    return bcrypt.hash(password, salt)
  }
}
