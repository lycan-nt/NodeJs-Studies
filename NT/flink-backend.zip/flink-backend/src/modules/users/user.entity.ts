/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany, ManyToOne, JoinColumn } from 'typeorm'
import * as bcrypt from 'bcrypt'
import { Suggestion } from '../suggestion/suggestion.entity'
import { AuthenticationCodes } from '../auth/mfa/authentication-codes.entity'
import { UserShoppingCart } from '../user-shopping-cart/user-shopping-cart.entity'
import { ShoppingCart } from '../shopping-cart/shopping-cart.entity'
import { Reclamation } from '../reclamation/reclamation.entity'
import { LikeProduct } from '../like-product/like-product.entity'
import { Order } from '../order/order.entity'
import { Company } from '../company/company.entity'

export enum Genre {
  F = 'F',
  M = 'M',
  N = 'N',
}

export enum UserAccessLevel {
  Owner = 'owner',
  Manager = 'manager',
  Employee = 'employee',
  Observer = 'observer',
  Customer = 'customer',
}

@Entity()
@Unique(['id', 'email', 'cpf', 'phone'])
export class User extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ nullable: false, type: 'varchar', length: 50 })
  first_name: string

  @Column({ nullable: false, type: 'varchar', length: 50 })
  last_name: string

  @Column({ nullable: true, type: 'enum', enum: Genre })
  genre: Genre

  @Column({ nullable: true, type: 'varchar', length: 200, unique: true })
  email: string

  @Column({ nullable: false, type: 'varchar', length: 20, unique: true })
  phone: string

  @Column({ nullable: true, type: 'varchar', length: 11, unique: true })
  cpf: string

  @Column({ nullable: false, type: 'varchar', length: 255, select: false })
  password: string

  @Column({ nullable: false, type: 'enum', enum: UserAccessLevel, default: UserAccessLevel.Customer })
  access_level: UserAccessLevel

  @Column({ nullable: true, type: 'date' })
  last_access: Date

  @Column({ nullable: true, type: 'date' })
  birthday: Date

  @Column({ nullable: false, type: 'boolean', default: true })
  allow_offers: Boolean

  @Column({ nullable: false, type: 'boolean', default: true })
  allow_notifications: Boolean

  @Column({ nullable: true, type: 'float' })
  latitude: Number

  @Column({ nullable: true, type: 'float' })
  longitude: Number

  @Column({ nullable: true, type: 'varchar', length: 255 })
  street: string

  @Column({ nullable: true, type: 'varchar', length: 10 })
  number: string

  @Column({ nullable: true, type: 'varchar', length: 100 })
  district: string

  @Column({ nullable: true, type: 'varchar', length: 8 })
  cep: string

  @Column({ nullable: true, type: 'varchar', length: 2 })
  uf: string

  @Column({ nullable: true, type: 'varchar', length: 255 })
  city: string

  @Column({ nullable: false, type: 'boolean', default: false })
  is_active: Boolean

  @Column({ nullable: true, type: 'varchar', length: 255, select: false })
  access_token_google: string

  @Column({ nullable: true, type: 'varchar', length: 64, select: false })
  confirmation_token: string

  @Column({ nullable: true, type: 'varchar', length: 64, select: false })
  recover_token: string

  @Column({ nullable: false, select: false })
  salt: string

  @OneToMany(() => AuthenticationCodes, authenticationCodes => authenticationCodes.user_id)
  authentication_codes: AuthenticationCodes[]

  @OneToMany(() => Suggestion, suggestions => suggestions.user_id)
  suggestions: Suggestion[]

  @OneToMany(() => UserShoppingCart, userShoppingCart => userShoppingCart.user_id)
  user_shopping_carts: UserShoppingCart[]

  @OneToMany(() => Reclamation, reclamation => reclamation.user_id)
  reclamations: Reclamation[]

  @OneToMany(() => LikeProduct, likeProduct => likeProduct.user_id)
  likes: LikeProduct[]

  @OneToMany(() => Order, order => order.user_id)
  orders: Order[]

  @OneToMany(() => Order, order => order.employee_id)
  employee_orders: Order[]

  @ManyToOne(() => Company, company => company.users, { nullable: false, eager: false })
  @JoinColumn({ name: 'company_id' })
  company_id: Company

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date

  async checkPassword(password: string): Promise<boolean> {
    const hash = await bcrypt.hash(password, this.salt)
    return hash === this.password
  }
}
