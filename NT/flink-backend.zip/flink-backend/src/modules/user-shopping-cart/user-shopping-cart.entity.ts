/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm'
import { ShoppingCart } from '../shopping-cart/shopping-cart.entity'
import { User } from '../users/user.entity'

@Entity()
@Unique(['id'])
@Unique('UQ_shopping_cart_user', ['shopping_cart_id', 'user_id'])
export class UserShoppingCart extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @ManyToOne(() => User, user => user.user_shopping_carts, { nullable: false, eager: false })
  @JoinColumn({ name: 'user_id' })
  user_id: User

  @ManyToOne(() => ShoppingCart, shoppingCart => shoppingCart.user_shopping_carts, { nullable: false, eager: false })
  @JoinColumn({ name: 'shopping_cart_id' })
  shopping_cart_id: ShoppingCart

  @Column({ nullable: false, type: 'boolean', default: false })
  is_owner: Boolean

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
