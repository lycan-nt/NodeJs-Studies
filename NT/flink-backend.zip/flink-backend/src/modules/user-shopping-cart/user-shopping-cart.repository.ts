import { DeepPartial, EntityRepository, Repository } from 'typeorm'
import { BadRequestException, InternalServerErrorException } from '@nestjs/common'
import {
  paginate,
  Pagination,
  IPaginationOptions,
} from 'nestjs-typeorm-paginate';
import { UserShoppingCart } from './user-shopping-cart.entity';

@EntityRepository(UserShoppingCart)
export class UserShoppingCartRepository extends Repository<UserShoppingCart> {
  // async findShoppingCart(queryDto: FindShoppingCartQueryDto): Promise<Pagination<ShoppingCart>> {
  //   const { name, note, owner_user_id, page, limit, sort } = queryDto
  //   const query = this.createQueryBuilder('shopping_cart')

  //   const options: IPaginationOptions = {
  //     page: Math.max(1, page || 1),
  //     limit: Math.min(100, limit || 10)
  //   }

  //   !!name && query.andWhere('shopping_cart.name ILIKE :name', { name: `%${name}%` })
  //   !!note && query.andWhere('shopping_cart.note ILIKE :note', { note: `%${note}%` })
  //   !!owner_user_id && query.andWhere(
  //     'shopping_cart.owner_user_id = :owner_user_id',
  //     { owner_user_id: Number(owner_user_id) }
  //   )

  //   try {
  //     query.orderBy(JSON.parse(sort || "{}"))
  //   } catch (err) {
  //     throw new BadRequestException("Filtro de ordenação inválido")
  //   }

  //   return paginate<ShoppingCart>(query, options);
  // }

  async createUserShoppingCart(entityLikeArray: DeepPartial<UserShoppingCart>[]): Promise<UserShoppingCart[]> {
    const userShoppingCart = this.create(entityLikeArray)

    try {
      return userShoppingCart
    } catch (error) {
      throw new InternalServerErrorException(error.message, 'Erro ao salvar o carrinho no banco de dados')
    }
  }
}
