import { Inject, Injectable, NotFoundException } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import { InjectRepository } from '@nestjs/typeorm'
import { Pagination } from 'nestjs-typeorm-paginate'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository } from 'typeorm'
import { UserShoppingCartRepository } from './user-shopping-cart.repository'

@Injectable()
export class UserShoppingCartService {
  private userShoppingCartRepository: UserShoppingCartRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.userShoppingCartRepository = getCustomRepository(UserShoppingCartRepository, this.companyName)
  }

  // async createAdminUser(createUserDto: CreateUserDto): Promise<User> {
  //   return this.userRepository.createUser(createUserDto)
  // }

  // async findUserById(userId: string): Promise<User> {
  //   const user = await this.userRepository.findOne(userId, {
  //     // select: ['email', 'first_name', 'id'],
  //   })

  //   if (!user) throw new NotFoundException('Usuário não encontrado')

  //   return user
  // }

  // async updateUser(updateUserDto: UpdateUserDto, id: string) {
  //   const result = await this.userRepository.update({ id }, updateUserDto)
  //   if (result.affected > 0) {
  //     const user = await this.findUserById(id)
  //     return user
  //   } else {
  //     throw new NotFoundException('Usuário não encontrado')
  //   }
  // }

  // async deleteUser(userId: string) {
  //   const result = await this.userRepository.delete({ id: userId })
  //   if (result.affected === 0) {
  //     throw new NotFoundException('Não foi encontrado um usuário com o ID informado')
  //   }
  // }

  // async findUsers(queryDto: FindUsersQueryDto): Promise<Pagination<User>> {
  //   return await this.userRepository.findUsers(queryDto)
  // }
}
