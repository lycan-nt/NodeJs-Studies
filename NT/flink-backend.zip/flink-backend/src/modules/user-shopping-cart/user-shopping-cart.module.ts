import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { UserShoppingCartRepository } from './user-shopping-cart.repository';
import { UserShoppingCartService } from './user-shopping-carts.service'

@Module({
  imports: [
    TypeOrmModule.forFeature([UserShoppingCartRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [UserShoppingCartService],
  // controllers: [ShoppingCartController],
  exports: [UserShoppingCartModule]
})
export class UserShoppingCartModule { }
