/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany } from 'typeorm'
import { Order } from '../order/order.entity'
import { ShoppingCartProduct } from '../shopping-cart-product/shopping-cart-product.entity'
import { UserShoppingCart } from '../user-shopping-cart/user-shopping-cart.entity'

@Entity()
@Unique(['id'])
export class ShoppingCart extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ nullable: false, type: 'varchar', length: 50 })
  name: string

  @Column({ nullable: true, type: 'varchar', length: 255 })
  note: string

  @OneToMany(() => UserShoppingCart, userShoppingCart => userShoppingCart.shopping_cart_id)
  user_shopping_carts: UserShoppingCart[]

  @OneToMany(() => ShoppingCartProduct, shoppingCartProduct => shoppingCartProduct.shopping_cart_id)
  products: ShoppingCartProduct[]

  @OneToMany(() => Order, order => order.shopping_cart_id)
  orders: Order[]

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
