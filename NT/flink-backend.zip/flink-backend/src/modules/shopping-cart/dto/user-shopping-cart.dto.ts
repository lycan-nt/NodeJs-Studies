import {
  IsNotEmpty,
  IsNumberString,
  MaxLength,
} from 'class-validator'
import { ApiProperty } from '@nestjs/swagger'

export class UserShoppingCartDto {
  @ApiProperty({ description: 'Número de telefone do usuário que será adicionado/removido ao carrinho' })
  @IsNumberString({ no_symbols: true }, { message: 'O número de telefone deve conter apenas números' })
  @IsNotEmpty({ message: 'Informe o número de telefone', })
  @MaxLength(50, { message: 'O número de telefone deve ter menos de 50 caracteres' })
  phone: string
}
