import { ApiPropertyOptional } from '@nestjs/swagger'
import { IsOptional, MaxLength } from 'class-validator'
import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto'

export class FindShoppingCartQueryDto extends BaseQueryParametersDto {

  @ApiPropertyOptional({ description: 'Busca pelo nome do carrinho' })
  @IsOptional()
  @MaxLength(50, { message: 'O nome do carrinho deve ter menos de 50 caracteres' })
  name: string

  @ApiPropertyOptional({ description: 'Busca pelo observação do carrinho' })
  @IsOptional()
  @MaxLength(255, { message: 'O campo "note" deve ter menos de 255 caracteres' })
  note: string

  @ApiPropertyOptional({ description: 'Busca pelos carrinhos que pertencem ao usuário informado' })
  @IsOptional()
  user_id: number
}
