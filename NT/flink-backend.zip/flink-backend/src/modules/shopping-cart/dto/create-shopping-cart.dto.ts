import {
  IsNotEmpty,
  IsOptional,
  MaxLength,
} from 'class-validator'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { User } from 'src/modules/users/user.entity'
import { ShoppingCartProduct } from 'src/modules/shopping-cart-product/shopping-cart-product.entity'

export class CreateShoppingCartDto {
  @ApiProperty({ description: 'Nome do carrinho associado ao usuário' })
  @IsNotEmpty({ message: 'Informe o nome do carrinho', })
  @MaxLength(50, { message: 'O nome do carrinho ter menos de 50 caracteres' })
  name: string

  @ApiPropertyOptional({ description: 'Descrição do carrinho inserida pelo usuário' })
  @IsOptional()
  @MaxLength(255, { message: 'O campo "note" deve ter menos de 255 caracteres' })
  note: string

  @ApiPropertyOptional({
    description: 'Lista de produtos para ser adicionado no carrinho<br>'
      + 'Ao informar este campo, a lista de produtos será substituída pela enviada.<br>'
      + 'Para remover todos os produtos da lista, basta apenas enviar um array vazio<br>',
    example: {
      products: {
        product_id: 2,
        multiplier_price: 1.0,
        quantity: 5
      }
    },
  })
  @IsOptional()
  products: ShoppingCartProduct[]

  owner_user_id: User
}
