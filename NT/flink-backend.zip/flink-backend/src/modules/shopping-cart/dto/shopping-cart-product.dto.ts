import { IsOptional, MaxLength } from 'class-validator'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { Product } from 'src/modules/product/product.entity'

export class ShoppingCartProductDto {
  @ApiProperty({ description: 'Id do Produto' })
  @MaxLength(50, { message: 'Id do produto a ser adicionado ao carrinho' })
  product: Product

  @ApiPropertyOptional({ description: 'Multiplicador de preço para produtos fracionados. Padrão = 1.0' })
  @IsOptional()
  multiplier_price: number = 1.0

  @ApiPropertyOptional({ description: 'Quantidade de produtos a ser adicionado ao carrinho' })
  @IsOptional()
  @MaxLength(255, { message: 'Informa a quantidade de produto que será adicionada no carrinho. Padrão = 1' })
  quantity: number = 1
}
