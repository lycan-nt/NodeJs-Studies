import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { ShoppingCartRepository } from './shopping-cart.repository';
import { ShoppingCartService } from './shopping-cart.service';
import { ShoppingCartController } from './shopping-cart.controller';
import { UserShoppingCartRepository } from '../user-shopping-cart/user-shopping-cart.repository';

@Module({
  imports: [
    TypeOrmModule.forFeature([ShoppingCartRepository, UserShoppingCartRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [ShoppingCartService],
  controllers: [ShoppingCartController],
  exports: [ShoppingCartModule, ShoppingCartService]
})
export class ShoppingCartModule { }
