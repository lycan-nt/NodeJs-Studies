import { BadRequestException, ConflictException, ForbiddenException, Inject, Injectable, NotFoundException } from '@nestjs/common'
import { Pagination } from 'nestjs-typeorm-paginate'
import { ShoppingCartRepository } from './shopping-cart.repository'
import { FindShoppingCartQueryDto } from './dto/find-shopping-cart-query-dto'
import { ShoppingCart } from './shopping-cart.entity'
import { CreateShoppingCartDto } from './dto/create-shopping-cart.dto'
import { UpdateShoppingCartDto } from './dto/update-shopping-cart.dto'
import { UserShoppingCartRepository } from '../user-shopping-cart/user-shopping-cart.repository'
import { UserShoppingCartDto } from './dto/user-shopping-cart.dto'
import { getCustomRepository, getRepository } from 'typeorm'
import { User } from '../users/user.entity'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'

@Injectable()
export class ShoppingCartService {
  private shoppingCartRepository: ShoppingCartRepository
  private userShoppingCartRepository: UserShoppingCartRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.shoppingCartRepository = getCustomRepository(ShoppingCartRepository, this.companyName)
    this.userShoppingCartRepository = getCustomRepository(UserShoppingCartRepository, this.companyName)
  }

  async createShoppingCart(createShoppingCartDto: CreateShoppingCartDto): Promise<ShoppingCart> {
    const { owner_user_id: user_id, ...rest } = createShoppingCartDto
    const shopping_cart_id = await this.shoppingCartRepository.createShoppingCart(rest as CreateShoppingCartDto)
    const userShoppingCart = this.userShoppingCartRepository.create({ shopping_cart_id, user_id, is_owner: true })
    await this.userShoppingCartRepository.save(userShoppingCart)
    return this.shoppingCartRepository.findShoppingCartById(shopping_cart_id.id.toString())
  }

  async addUserToShoppingCart(id: string, { phone }: UserShoppingCartDto, user_owner_id?: User): Promise<ShoppingCart> {
    const shopping_cart_id = await this.shoppingCartRepository.findOne({ id: Number(id) }, { select: ['id'] })
    if (!shopping_cart_id) {
      throw new NotFoundException('Carrinho não encontrado!')
    }

    if (!!user_owner_id && !(await this.isOwner(id, user_owner_id))) {
      throw new ForbiddenException('Usuário não possui autorização para gerenciar este carrinho')
    }

    const userRepository = getRepository(User, this.companyName)
    const user_id = await userRepository.findOne({ phone, is_active: true }, { select: ['id'] })
    if (!user_id) {
      throw new BadRequestException('Usuário não encontrado')
    }

    const shareExists = typeof (await this.isOwner(String(shopping_cart_id.id), user_id)) != "undefined"
    if (shareExists) {
      throw new ConflictException('Usuário já possui acesso ao carrinho')
    }

    const userShoppingCart = this.userShoppingCartRepository.create({ shopping_cart_id, user_id, is_owner: false })
    await this.userShoppingCartRepository.save(userShoppingCart)
    return this.shoppingCartRepository.findShoppingCartById(shopping_cart_id.id.toString())
  }

  async removeUserToShoppingCart(id: string, { phone }: UserShoppingCartDto, user_owner_id?: User): Promise<void> {
    const shopping_cart_id = await this.shoppingCartRepository.findOne({ id: Number(id) }, { select: ['id'] })
    if (!shopping_cart_id) {
      throw new NotFoundException('Carrinho não encontrado!')
    }

    if (!!user_owner_id && !(await this.isOwner(id, user_owner_id))) {
      throw new ForbiddenException('Usuário não possui autorização para gerenciar este carrinho')
    }

    const userRepository = getRepository(User, this.companyName)
    const user_id = await userRepository.findOne({ phone }, { select: ['id'] })
    if (!user_id) {
      throw new BadRequestException('Usuário não encontrado')
    }

    const userShoppingCart = await this.userShoppingCartRepository.findOne({ shopping_cart_id, user_id, is_owner: false })
    if (!userShoppingCart) {
      throw new ConflictException('Compartilhamento não encontrado')
    }
    await userShoppingCart.remove()
  }

  async findShoppingCartById(id: string, user_id?: Number): Promise<ShoppingCart> {
    return await this.shoppingCartRepository.findShoppingCartById(id, user_id)
  }

  async updateShoppingCart(updateShoppingCartDto: UpdateShoppingCartDto, id: string, user_owner_id?: User) {
    if (!!user_owner_id && !(await this.isOwner(id, user_owner_id))) {
      throw new ForbiddenException('Usuário não possui autorização para gerenciar este carrinho')
    }

    const { products, ...rest } = updateShoppingCartDto

    if (Array.isArray(updateShoppingCartDto.products)) {
      await this.shoppingCartRepository.updateProductList(products, id, this.companyName)
    }

    const result = await this.shoppingCartRepository.update(id, rest)

    if (result.affected > 0) {
      const shoppingCart = await this.findShoppingCartById(id)
      return shoppingCart
    } else {
      throw new NotFoundException('Carrinho não encontrado')
    }
  }

  async deleteShoppingCart(id: string, user_owner_id?: User) {
    const shopping_cart_id = await this.shoppingCartRepository.findOne({ id: Number(id) }, { select: ['id'] })
    if (!shopping_cart_id) {
      throw new NotFoundException('Carrinho não encontrado!')
    }

    if (!!user_owner_id && !(await this.isOwner(id, user_owner_id))) {
      throw new ForbiddenException('Usuário não possui autorização para gerenciar este carrinho')
    }

    await this.shoppingCartRepository.deleteShoppingCart(id, this.companyName)

    // const result = await this.shoppingCartRepository.delete(id)
    // if (result.affected === 0) {
    //   throw new NotFoundException('Carrinho não encontrado')
    // }
  }

  async findShoppingCarts(queryDto: FindShoppingCartQueryDto): Promise<Pagination<ShoppingCart>> {
    return await this.shoppingCartRepository.findShoppingCart(queryDto)
  }

  async isOwner(shoppingCart_id: string, user: User): Promise<Boolean> {
    const shoppingCart = await this.findShoppingCartById(shoppingCart_id)
    const result = await this.userShoppingCartRepository.findOne(
      { shopping_cart_id: shoppingCart, user_id: user },
      { select: ['is_owner'] })

    return result?.is_owner
  }
}
