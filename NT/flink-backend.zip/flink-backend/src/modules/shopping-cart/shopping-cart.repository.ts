import { EntityRepository, getConnection, Repository } from 'typeorm'
import { BadRequestException, InternalServerErrorException } from '@nestjs/common'
import {
  paginate,
  Pagination,
  IPaginationOptions,
} from 'nestjs-typeorm-paginate';
import { ShoppingCart } from './shopping-cart.entity'
import { FindShoppingCartQueryDto } from './dto/find-shopping-cart-query-dto'
import { CreateShoppingCartDto } from './dto/create-shopping-cart.dto';
import { UserShoppingCart } from '../user-shopping-cart/user-shopping-cart.entity';
import { ShoppingCartProduct } from '../shopping-cart-product/shopping-cart-product.entity';

@EntityRepository(ShoppingCart)
export class ShoppingCartRepository extends Repository<ShoppingCart> {
  async findShoppingCart(queryDto: FindShoppingCartQueryDto): Promise<Pagination<ShoppingCart>> {
    const { name, note, user_id, page, limit, sort } = queryDto
    const query = this.createQueryBuilder('shopping_cart')

    const options: IPaginationOptions = {
      page: Math.max(1, page || 1),
      limit: Math.min(100, limit || 10)
    }

    !!name && query.andWhere('shopping_cart.name ILIKE :name', { name: `%${name}%` })
    !!note && query.andWhere('shopping_cart.note ILIKE :note', { note: `%${note}%` })

    !!user_id && query.andWhere(qb => {
      const subQuery = qb.subQuery()
        .select("user_shopping_cart.shopping_cart_id")
        .from(UserShoppingCart, "user_shopping_cart")
        .where("user_shopping_cart.user_id = :user_id", { user_id })
        .getQuery();
      return "shopping_cart.id IN " + subQuery;
    })
    query.leftJoinAndSelect('shopping_cart.products', 'shopping_cart_products',
      '(select is_active from product where product.id = shopping_cart_products.product_id) = :active', { active: true })
    query.leftJoinAndSelect('shopping_cart_products.product_id', 'product', 'product.is_active = :active', { active: true })
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')
    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('shopping_cart.orders', 'order')
    query.leftJoinAndSelect('shopping_cart.user_shopping_carts', 'user_shopping_cart')
    query.leftJoin('user_shopping_cart.user_id', 'user')
      .addSelect(["user.id", "user.first_name", "user.last_name", "user.phone"])

    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<ShoppingCart>(query, options);
  }

  async findShoppingCartById(id: string, user_id?: Number): Promise<ShoppingCart> {
    const query = this.createQueryBuilder('shopping_cart')

    query.where("user_shopping_cart.shopping_cart_id = :shopping_cart_id", { shopping_cart_id: Number(id) })
    !!user_id && query.andWhere(qb => {
      const subQuery = qb.subQuery()
        .select("user_shopping_cart.shopping_cart_id")
        .from(UserShoppingCart, "user_shopping_cart")
        .where("user_shopping_cart.user_id = :user_id", { user_id })
        .getQuery();
      return "shopping_cart.id IN " + subQuery;
    })
    query.leftJoinAndSelect('shopping_cart.products', 'shopping_cart_products',
      '(select is_active from product where product.id = shopping_cart_products.product_id) = :active', { active: true })
    query.leftJoinAndSelect('shopping_cart_products.product_id', 'product', 'product.is_active = :active', { active: true })
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')
    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('product.company_id', 'company')
    query.leftJoinAndSelect('shopping_cart.orders', 'order')
    query.leftJoinAndSelect('shopping_cart.user_shopping_carts', 'user_shopping_cart')
    query.leftJoin('user_shopping_cart.user_id', 'user')
      .addSelect(["user.id", "user.first_name", "user.last_name", "user.phone"])

    return query.getOne()
  }

  async createShoppingCart(createShoppingCartDto: CreateShoppingCartDto): Promise<ShoppingCart> {
    const shoppingCart = this.create(createShoppingCartDto)
    shoppingCart.products = createShoppingCartDto.products

    try {
      await this.save(shoppingCart)
    } catch (error) {
      throw new InternalServerErrorException(error.message, 'Erro ao salvar o carrinho no banco de dados')
    }

    if (Array.isArray(createShoppingCartDto.products)) {
      const productsAdded = createShoppingCartDto.products.map(({ product_id, multiplier_price, quantity }) => {
        return ShoppingCartProduct.create({
          shopping_cart_id: shoppingCart,
          product_id,
          multiplier_price,
          quantity
        })
      })
      await this.manager.save(productsAdded)
    }

    return shoppingCart
  }

  async updateProductList(productsList: ShoppingCartProduct[], shopping_cart_id: string, companyName: string) {
    await getConnection(companyName)
      .createQueryBuilder()
      .delete()
      .from(ShoppingCartProduct)
      .where("shopping_cart_id = :id", { id: shopping_cart_id })
      .execute();


    const productsAdded = productsList.map(({ product_id, multiplier_price, quantity }) => {
      return ShoppingCartProduct.create({
        shopping_cart_id: { id: Number(shopping_cart_id) },
        product_id,
        multiplier_price,
        quantity
      })
    })

    return await this.manager.save(productsAdded)

  }

  async deleteShoppingCart(id: string, companyName: string) {
    await getConnection(companyName)
      .createQueryBuilder()
      .delete()
      .from(UserShoppingCart)
      .where("shopping_cart_id = :id", { id })
      .execute();

    await getConnection(companyName)
      .createQueryBuilder()
      .delete()
      .from(ShoppingCartProduct)
      .where("shopping_cart_id = :id", { id })
      .execute();

    return this.delete({ id: Number(id) })
  }
}
