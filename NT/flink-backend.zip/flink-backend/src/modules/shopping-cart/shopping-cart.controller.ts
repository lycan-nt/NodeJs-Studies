import { Controller, Post, Body, ValidationPipe, UseGuards, Get, Param, Patch, Delete, Query, Req, ForbiddenException, UsePipes } from '@nestjs/common'
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger'
import { AuthGuard } from '@nestjs/passport'
import { AccessLevelGuard } from '../auth/roles.guard'
import { ShoppingCartService } from './shopping-cart.service'
import { User, UserAccessLevel } from '../users/user.entity'
import { CreateShoppingCartDto } from './dto/create-shopping-cart.dto'
import { ShoppingCart } from './shopping-cart.entity'
import { UpdateShoppingCartDto } from './dto/update-shopping-cart.dto'
import { FindShoppingCartQueryDto } from './dto/find-shopping-cart-query-dto'
import { UserShoppingCartDto } from './dto/user-shopping-cart.dto'

@ApiBearerAuth('JWT')
@ApiTags('shopping-cart')
@Controller('shopping-cart')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class ShoppingCartController {
  constructor(
    private shoppingCartService: ShoppingCartService,
  ) { }

  @ApiOperation({
    summary: 'Create a shopping cart',
    description: 'Create a new shopping cart with name and description'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post()
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async createShoppingCart(
    @Body() createShoppingCartDto: CreateShoppingCartDto,
    @Req() req: any): Promise<ShoppingCart> {

    const { user } = req
    createShoppingCartDto.owner_user_id = user as User
    const shoppingCart = await this.shoppingCartService.createShoppingCart(createShoppingCartDto)
    return shoppingCart
  }

  @ApiOperation({
    summary: 'Find a shopping cart by id',
    description: ''
  })
  @ApiResponse({ status: 200, description: 'Carrinho encontrado' })
  @ApiResponse({ status: 403, description: 'Carrinho inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get(':id')
  async findShoppingCartById(
    @Param('id') id,
    @Req() req: any): Promise<ShoppingCart> {

    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    let user_id = null
    if (!isAdmin) {
      user_id = user.id
    }

    const shoppingCart = await this.shoppingCartService.findShoppingCartById(id, user_id)

    if (!!shoppingCart)
      return shoppingCart

    throw new ForbiddenException('Carrinho inexistente ou você não tem autorização de acesso')
  }

  @ApiOperation({
    summary: 'Update a shopping cart info',
    description: 'Atualiza as informações do carrinho (nome e/ou descrição). Apenas usuários que são donos dos carrinhos podem fazer esta alteração.'
  })
  @ApiResponse({ status: 200, description: 'Carrinho atualizado com sucesso' })
  @ApiResponse({ status: 403, description: 'Carrinho inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 404, description: 'Carrinho não encontrado' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch(':id')
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async updateShoppingCart(
    @Body() updateShoppingCartDto: UpdateShoppingCartDto,
    @Param('id') id: string,
    @Req() req: any) {

    const { user } = req
    const isOwner = await this.shoppingCartService.isOwner(id, user)
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    if (isAdmin || isOwner) {
      return this.shoppingCartService.updateShoppingCart(updateShoppingCartDto, id)
    }
    throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
  }

  @ApiOperation({
    summary: 'Share a shopping cart',
    description: 'Share a shopping cart with others users'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos ou usuário inexistente' })
  @ApiResponse({ status: 403, description: 'Carrinho inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 404, description: 'Carrinho não encontrado' })
  @ApiResponse({ status: 409, description: 'Usuário já possui acesso ao carrinho' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch('share/:id')
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async shareShoppingCart(
    @Body() userShoppingCartDto: UserShoppingCartDto,
    @Param('id') shopping_cart_id: string,
    @Req() req: any) {

    const { user } = req
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    if (!isAdmin) {
      return this.shoppingCartService.addUserToShoppingCart(shopping_cart_id, userShoppingCartDto, user as User)
    }
    return this.shoppingCartService.addUserToShoppingCart(shopping_cart_id, userShoppingCartDto)
  }

  @ApiOperation({
    summary: 'Remove user from a shopping cart share',
  })
  @ApiResponse({ status: 200, description: 'Usuário removido do compartilhamento' })
  @ApiResponse({ status: 403, description: 'Usuário não possui autorização para gerenciar este carrinho' })
  @ApiResponse({ status: 404, description: 'Carrinho não encontrado!' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete('share/:id')
  @UsePipes(new ValidationPipe({ whitelist: true }))
  async deleteShoppingCartShare(
    @Body() userShoppingCartDto: UserShoppingCartDto,
    @Param('id') shopping_cart_id: string,
    @Req() req: any) {

    const { user } = req
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    if (!isAdmin) {
      return this.shoppingCartService.removeUserToShoppingCart(shopping_cart_id, userShoppingCartDto, user as User)
    }
    return this.shoppingCartService.removeUserToShoppingCart(shopping_cart_id, userShoppingCartDto)
  }

  @ApiOperation({
    summary: 'Delete a shopping cart',
    description: 'Remove all users from share and delete the shopping cart'
  })
  @ApiResponse({ status: 200, description: 'Carrinho removido com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover este carrinho' })
  @ApiResponse({ status: 404, description: 'Carrinho não encontrado' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete(':id')
  async deleteShoppingCart(
    @Param('id') id: string,
    @Req() req: any) {

    const { user } = req
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    if (!isAdmin) {
      return await this.shoppingCartService.deleteShoppingCart(id, user)
    }
    return await this.shoppingCartService.deleteShoppingCart(id)
  }

  @ApiOperation({
    summary: 'Find and list shopping carts',
    description: 'List all or filter shopping carts by query'
  })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get()
  async findShoppingCarts(
    @Query(ValidationPipe) query: FindShoppingCartQueryDto,
    @Req() req: any) {

    const { user } = req
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    if (!isAdmin) {
      query.user_id = user.id
    }

    const shoppingCarts = await this.shoppingCartService.findShoppingCarts(query)
    return shoppingCarts
  }
}
