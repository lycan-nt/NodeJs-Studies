/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm'
import { Order } from '../order/order.entity'
import { Product } from '../product/product.entity'

export const CHECKOUT_STATUS = {
  NOT_CONFIRMED: 0,
  CONFIRMED: 1,
  ADDED_LATER: 2,
}
@Entity()
@Unique(['id'])
export class OrderProduct extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @ManyToOne(() => Product, Product => Product.orders, { nullable: false, eager: false })
  @JoinColumn({ name: 'product_id' })
  product_id: Product

  @ManyToOne(() => Order, order => order.products, { nullable: false, eager: false })
  @JoinColumn({ name: 'order_id' })
  order_id: Order

  @Column({ nullable: false, type: 'decimal', precision: 12, scale: 2 })
  product_price: number

  @Column({ nullable: false, type: 'decimal', precision: 12, scale: 2 })
  multiplier_price: number

  @Column({ nullable: false, type: 'int', default: CHECKOUT_STATUS.NOT_CONFIRMED, comment: '0 - not_confirmed, 1 - confirmed, 2 - added_later' })
  checkout_status: number

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
