import { DeepPartial, EntityRepository, Repository } from 'typeorm'
import { InternalServerErrorException } from '@nestjs/common'
import { OrderProduct } from './order-product.entity';

@EntityRepository(OrderProduct)
export class OrderProductRepository extends Repository<OrderProduct> {
  async createOrderProduct(orderProduct: DeepPartial<OrderProduct>): Promise<OrderProduct> {
    const result = this.create(orderProduct)

    try {
      return result
    } catch (error) {
      throw new InternalServerErrorException(error.message, 'Erro ao adicionar produto ao checkout')
    }
  }
}
