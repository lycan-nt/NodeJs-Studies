import { ApiProperty } from '@nestjs/swagger'
import { IsNotEmpty, IsOptional, MaxLength, IsBoolean, IsString } from 'class-validator'
import { User } from '../../users/user.entity'
import { Product } from '../../product/product.entity'

export class CreateReclamationDto {
  
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @MaxLength(255, {
    message: 'A nota deve ter no máximo 255 caracteres',
  })
  note: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  wrong_price: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  wrong_image: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  out_of_stock: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  resolved: boolean

  @ApiProperty()
  @IsNotEmpty({
    message: 'Informe o usuário responsável pela reclamação',
  })
  user_id: User

  @ApiProperty()
  @IsNotEmpty({
    message: 'Informe o produto relacionado à reclamação',
  })
  product_id: Product
}
