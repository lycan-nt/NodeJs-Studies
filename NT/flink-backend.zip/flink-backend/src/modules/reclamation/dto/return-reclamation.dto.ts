import { Reclamation } from '../reclamation.entity'

export class ReturnReclamationDto {
  reclamation: Reclamation
  message: string
}
