import { ApiProperty } from '@nestjs/swagger'
import { IsOptional, MaxLength, IsString, IsBoolean } from 'class-validator'

export class UpdateReclamationDto {

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @MaxLength(255, { message: 'A nota deve ter no máximo 255 caracteres' })
  note: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  wrong_price: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  wrong_image: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  out_of_stock: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean({ message: 'Informe apenas com "true" ou "false"' })
  resolved: boolean
}
