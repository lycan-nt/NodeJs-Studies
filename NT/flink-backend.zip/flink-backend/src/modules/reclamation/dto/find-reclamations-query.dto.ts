import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto'
import { User } from '../../users/user.entity'
import { Product } from '../../product/product.entity'
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, MaxLength, IsBooleanString } from 'class-validator';

export class FindReclamationsQueryDto extends BaseQueryParametersDto {

  @ApiPropertyOptional({ description: 'Busca pela nota da reclamação' })
  @IsOptional()
  @MaxLength(255, { message: 'A nota deve ter no máximo 255 caracteres' })
  note: string

  @ApiPropertyOptional({ description: 'Filtra reclamação pelo campo preço errado' })
  @IsOptional()
  @IsBooleanString({ message: 'wrong_price: informe apenas true ou false' })
  wrong_price: boolean

  @ApiPropertyOptional({ description: 'Filtra reclamação pelo campo imagem errada' })
  @IsOptional()
  @IsBooleanString({ message: 'wrong_image: informe apenas true ou false' })
  wrong_image: boolean

  @ApiPropertyOptional({ description: 'Filtra reclamação pelo campo fora de estoque' })
  @IsOptional()
  @IsBooleanString({ message: 'out_of_stock: informe apenas true ou false' })
  out_of_stock: boolean

  @ApiPropertyOptional({ description: 'Filtra reclamação pelo campo resolvido(a)' })
  @IsOptional()
  @IsBooleanString({ message: 'resolved: informe apenas true ou false' })
  resolved: boolean

  @ApiPropertyOptional({ description: 'Busca pelo id do usuário relacionado à reclamação' })
  @IsOptional()
  user_id: User
  
  @ApiPropertyOptional({ description: 'Busca pelo id do produto relacionado à reclamação' })
  @IsOptional()
  product_id: Product
}

