import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { ReclamationRepository } from './reclamation.repository'
import { PassportModule } from '@nestjs/passport'
import { ReclamationsService } from './reclamations.service'
import { ReclamationsController } from './reclamations.controller'

@Module({
  imports: [
    TypeOrmModule.forFeature([ReclamationRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [ReclamationsService],
  controllers: [ReclamationsController],
  exports: [ReclamationsModule]
})
export class ReclamationsModule {}
