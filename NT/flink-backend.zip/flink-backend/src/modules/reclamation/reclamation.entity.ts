/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm'
import { Product } from '../product/product.entity'
import { User } from '../users/user.entity'

@Entity()
@Unique(['id'])
export class Reclamation extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @ManyToOne(() => Product, Product => Product.reclamations, { nullable: false, eager: true })
  @JoinColumn({ name: 'product_id' })
  product_id: Product

  @ManyToOne(() => User, user => user.reclamations, { nullable: false, eager: true })
  @JoinColumn({ name: 'user_id' })
  user_id: User

  @Column({ nullable: true, type: 'varchar', length: 255 })
  note: string

  @Column({ nullable: true, type: 'boolean', default: false })
  wrong_price: boolean

  @Column({ nullable: true, type: 'boolean', default: false })
  wrong_image: boolean

  @Column({ nullable: true, type: 'boolean', default: false })
  out_of_stock: boolean

  @Column({ nullable: true, type: 'boolean', default: false })
  resolved: boolean

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
