import {ApiBearerAuth, ApiOperation, ApiResponse, ApiTags} from '@nestjs/swagger'
import {
  Body,
  Controller,
  Delete, ForbiddenException,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UseGuards,
  ValidationPipe,
} from '@nestjs/common'
import { AuthGuard } from '@nestjs/passport'
import { AccessLevelGuard } from '../auth/roles.guard'
import { ReclamationsService } from './reclamations.service'
import { AccessLevel } from '../auth/role.decorator'
import { UserAccessLevel } from '../users/user.entity'
import { ReturnReclamationDto } from './dto/return-reclamation.dto'
import { UpdateReclamationDto } from './dto/update-reclamation.dto'
import { FindReclamationsQueryDto } from './dto/find-reclamations-query.dto'
import { CreateReclamationDto } from './dto/create-reclamation.dto'

@ApiTags('reclamation')
@ApiBearerAuth('JWT')
@Controller('reclamation')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class ReclamationsController {
  constructor(private reclamationsService: ReclamationsService) {}

  @ApiOperation({
    summary: 'Cadastra reclamação',
    description: 'Cadastrar uma nova reclamação no banco de dados.'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Reclamação inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async createReclamation(
    @Body(ValidationPipe) createReclamationDto: CreateReclamationDto,
    @Req() req: any) : Promise<ReturnReclamationDto> {
    const { user } = req

    const reclamation = await this.reclamationsService.createReclamation(createReclamationDto, user)
    return {
      reclamation,
      message: 'Reclamação cadastrada com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Busca reclamação pelo id',
    description: 'Busca a reclamação no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Reclamação encontrada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Reclamação inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async findReclamationById(@Param('id') id: string): Promise<ReturnReclamationDto> {
    const reclamation = await this.reclamationsService.findReclamationById(Number(id))
    return {
      reclamation,
      message: 'Reclamação encontrada',
    }
  }

  @ApiOperation({
    summary: 'Altera reclamação',
    description: 'Altera dados da reclamação no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Reclamação atualizada com sucesso' })
  @ApiResponse({ status: 403, description: 'Reclamação inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 404, description: 'Reclamação não encontrada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async updateReclamation(
    @Body() updateReclamationDto: UpdateReclamationDto,
    @Param('id') id: string,
    @Req() req: any) {
    const { reclamation } = req

    if ([UserAccessLevel.Manager, UserAccessLevel.Owner].includes(reclamation.access_level)) {
      return this.reclamationsService.updateReclamation(updateReclamationDto, Number(id))
    } else if (reclamation.id === Number(id)) {
      return this.reclamationsService.updateReclamation(updateReclamationDto, Number(id))
    }
    throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
  }

  @ApiOperation({
    summary: 'Deleta reclamação',
    description: 'Deleta reclamação no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Reclamação removida com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover esta reclamação' })
  @ApiResponse({ status: 404, description: 'Reclamação não encontrada' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async deleteReclamation(@Param('id') id: string) {
    await this.reclamationsService.deleteReclamation(Number(id))
    return {
      message: 'Reclamação removida com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Lista todas as reclamações',
    description: 'Lista todas as reclamações cadastradas no banco de dados.'
  })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para listar reclamações' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @Get()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async findReclamations(@Query() query: FindReclamationsQueryDto) {
    const found = await this.reclamationsService.findReclamations(query)
    return found
  }
}
