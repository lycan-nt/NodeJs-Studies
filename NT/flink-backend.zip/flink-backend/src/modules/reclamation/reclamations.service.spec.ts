import { Test, TestingModule } from '@nestjs/testing'
import { UsersService } from '../users/users.service'
import { UserRepository } from '../users/users.repository'
import { NotFoundException, UnprocessableEntityException } from '@nestjs/common'
import { ReclamationRepository } from './reclamation.repository'
import { ReclamationsService } from './reclamations.service'
import { CreateReclamationDto } from './dto/create-reclamation.dto'
import { FindReclamationsQueryDto } from './dto/find-reclamations-query.dto'
import { CreateUserDto } from '../users/dto/create-user.dto'

const mockReclamationRepository = () => ({
  createReclamation: jest.fn(),
  findOne: jest.fn(),
  delete: jest.fn(),
  findReclamations: jest.fn(),
  update: jest.fn(),
});

xdescribe('ReclamationsService', () => {
  let reclamationRepository;
  let service;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        UsersService,
        {
          provide: UserRepository,
          useFactory: mockReclamationRepository,
        },
      ],
    }).compile();

    reclamationRepository = await module.get<ReclamationRepository>(ReclamationRepository);
    service = await module.get<ReclamationsService>(ReclamationsService);
  });

  xit('should be defined', () => {
    expect(service).toBeDefined();
    expect(reclamationRepository).toBeDefined();
  });

  xdescribe('createReclamation', () => {
    let mockCreateReclamationDto: CreateReclamationDto;
    let mockCreateUserDto: CreateUserDto;

    beforeEach(() => {
      mockCreateReclamationDto = {
        note: 'Teste',
        wrong_price: true,
        wrong_image: false,
        out_of_stock: false,
        resolved: false,
      };
    });

    xit('should create a reclamation', async () => {

    });
  });

  xdescribe('findReclamationById', () => {
    xit('should return the found reclamation', async () => {
      reclamationRepository.findOne.mockResolvedValue('mockReclamation');
      expect(reclamationRepository.findOne).not.toHaveBeenCalled();

      const result = await service.findReclamationById('mockId');
      const select = ['note', 'wrong_price', 'wrong_image', 'out_of_stock','user_id', 'product_id', 'id'];
      expect(reclamationRepository.findOne).toHaveBeenCalledWith('mockId', { select });
      expect(result).toEqual('mockReclamation');
    });

    xit('should throw an error as reclamation is not found', async () => {
      reclamationRepository.findOne.mockResolvedValue(null);
      expect(service.findReclamationById('mockId')).rejects.toThrow(NotFoundException);
    });
  });

  xdescribe('deleteReclamation', () => {
    xit('should return affected > 0 if reclamation is deleted', async () => {
      reclamationRepository.delete.mockResolvedValue({ affected: 1 });

      await service.deleteReclamation('mockId');
      expect(reclamationRepository.delete).toHaveBeenCalledWith({ id: 'mockId' });
    });

    xit('should throw an error if no reclamation is deleted', async () => {
      reclamationRepository.delete.mockResolvedValue({ affected: 0 });

      expect(service.deleteReclamation('mockId')).rejects.toThrow(NotFoundException);
    });
  });

  xdescribe('findReclamations', () => {
    xit('should call the findReclamations method of the reclamationRepository', async () => {
      reclamationRepository.findReclamations.mockResolvedValue('resultOfsearch');
      const mockFindReclamationsQueryDto: FindReclamationsQueryDto = {
        note: '',
        wrong_price: false,
        wrong_image: false,
        out_of_stock: false,
        resolved: false,
        user_id: undefined,
        product_id: undefined,
        limit: 1,
        page: 1,
        sort: ''
      };
      const result = await service.findUsers(mockFindReclamationsQueryDto);
      expect(reclamationRepository.findUsers).toHaveBeenCalledWith(
        mockFindReclamationsQueryDto,
      );
      expect(result).toEqual('resultOfsearch');
    });
  });

  xdescribe('updateReclamation', () => {
    xit('should return affected > 0 if reclamation data is updated and return the new reclamation', async () => {
      reclamationRepository.update.mockResolvedValue({ affected: 1 });
      reclamationRepository.findOne.mockResolvedValue('mockReclamation');

      const result = await service.updateReclamation('mockUpdateReclamationDto', 'mockId');
      expect(reclamationRepository.update).toHaveBeenCalledWith(
        { id: 'mockId' },
        'mockUpdateReclamationDto',
      );
      expect(result).toEqual('mockReclamation');
    });

    xit('should throw an error if no row is affected in the DB', async () => {
      reclamationRepository.update.mockResolvedValue({ affected: 0 });

      expect(service.updateReclamation('mockUpdateReclamationDto', 'mockId')).rejects.toThrow(
        NotFoundException,
      );
    });
  });
});
