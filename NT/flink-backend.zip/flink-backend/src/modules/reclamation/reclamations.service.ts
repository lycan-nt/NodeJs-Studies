import { Inject, Injectable, NotFoundException } from '@nestjs/common'
import { ReclamationRepository } from './reclamation.repository'
import { Reclamation } from './reclamation.entity'
import { UpdateReclamationDto } from './dto/update-reclamation.dto'
import { FindReclamationsQueryDto } from './dto/find-reclamations-query.dto'
import { CreateReclamationDto } from './dto/create-reclamation.dto'
import { Pagination } from 'nestjs-typeorm-paginate';
import { User } from '../users/user.entity';
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository } from 'typeorm'

@Injectable()
export class ReclamationsService {
  private reclamationRepository: ReclamationRepository
  private companyName: string

  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.reclamationRepository = getCustomRepository(ReclamationRepository, this.companyName)
  }

  async createReclamation(createReclamationDto: CreateReclamationDto, user: User): Promise<Reclamation> {
    return this.reclamationRepository.createReclamation(createReclamationDto, user)
  }

  async findReclamationById(reclamationId: number): Promise<Reclamation> {
    const reclamation = await this.reclamationRepository.findOne(reclamationId)

    if (!reclamation) throw new NotFoundException('Reclamação não encontrada')

    return reclamation
  }

  async updateReclamation(updateReclamationDto: UpdateReclamationDto, id: number) {
    const result = await this.reclamationRepository.update({ id }, updateReclamationDto)
    if (result.affected > 0) {
      const reclamation = await this.findReclamationById(id)
      return reclamation
    } else {
      throw new NotFoundException('Reclamação não encontrada')
    }
  }

  async deleteReclamation(reclamationId: number) {
    const result = await this.reclamationRepository.delete({ id: reclamationId })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrada uma reclamação com o ID informado')
    }
  }

  async findReclamations(queryDto: FindReclamationsQueryDto): Promise<Pagination<Reclamation>> {
    return await this.reclamationRepository.findReclamations(queryDto)
  }
}
