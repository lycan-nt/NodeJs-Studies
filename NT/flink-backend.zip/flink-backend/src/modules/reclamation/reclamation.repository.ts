import { EntityRepository, Repository } from 'typeorm'
import { Reclamation } from './reclamation.entity'
import { FindReclamationsQueryDto } from './dto/find-reclamations-query.dto'
import { CreateReclamationDto } from './dto/create-reclamation.dto'
import { BadRequestException, ConflictException, InternalServerErrorException } from '@nestjs/common'
import { User } from '../users/user.entity'
import {
  paginate,
  Pagination,
  IPaginationOptions,
} from 'nestjs-typeorm-paginate';

@EntityRepository(Reclamation)
export class ReclamationRepository extends Repository<Reclamation> {

  async findReclamations(queryDto: FindReclamationsQueryDto): Promise<Pagination<Reclamation>> {
    queryDto.page = queryDto.page < 1 ? 1 : queryDto.page
    queryDto.limit = queryDto.limit > 100 ? 100 : queryDto.limit

    const {
      note,
      wrong_price,
      wrong_image,
      out_of_stock,
      resolved,
      user_id,
      product_id,
      page,
      limit,
      sort
    } = queryDto
    const query = this.createQueryBuilder('reclamation')
    query.where('reclamation.user_id = :user_id', { user_id })

    const options: IPaginationOptions = {
      page,
      limit,
    }

   !!note && query.andWhere('reclamation.note ILIKE :note', { note: `%${note}%` })

    typeof (wrong_price) !== undefined
      && query.andWhere('reclamation.wrong_price = :wrong_price', { wrong_price })

    typeof (wrong_image) !== undefined
      && query.andWhere('reclamation.wrong_image = :wrong_image', { wrong_image })

    typeof (out_of_stock) !== undefined
      && query.andWhere('reclamation.out_of_stock = :out_of_stock', { out_of_stock })

    typeof (resolved) !== undefined
      && query.andWhere('reclamation.resolved = :resolved', { resolved })

    if (product_id) {
      query.andWhere('reclamation.product_id = :product_id', { product_id })
    }

    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<Reclamation>(query, options);
  }

  async createReclamation(createReclamationDto: CreateReclamationDto, user: User): Promise<Reclamation> {
    let reclamation = this.create({
      ...createReclamationDto,
    })

    reclamation.user_id = user

    try {
      return await this.save(reclamation)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Reclamação já cadastrada')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar a reclamação no banco de dados')
      }
    }
  }
}
