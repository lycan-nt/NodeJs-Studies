import { BadRequestException, ConflictException, InternalServerErrorException } from "@nestjs/common";
import { IPaginationOptions, paginate, Pagination } from "nestjs-typeorm-paginate";
import { EntityRepository, Repository } from "typeorm";
import { CreateOrderDto } from "./dto/create-order.dto";
import { FindOrderQueryDto } from "./dto/find-order-query-dto";
import { Order } from "./order.entity";

@EntityRepository(Order)
export class OrderRepository extends Repository<Order> {

  async createOrder(createOrderDto: CreateOrderDto): Promise<Order> {
    const order = this.create(createOrderDto)

    try {
      return await this.save(order)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Checkout já existe')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar o checkout no banco de dados')
      }
    }
  }

  async findOrder(queryDto: FindOrderQueryDto): Promise<Pagination<Order>> {
    const query = this.createQueryBuilder('order')
    const {
      status,
      user_id,
      employee_id,
      payment_type,
      shopping_cart_id,
      page,
      limit,
      sort
    } = queryDto

    const options: IPaginationOptions = {
      page: Math.max(1, page || 1),
      limit: Math.min(100, limit || 10)
    }


    !!status && query.andWhere('order.status = :status', { status })
    !!user_id && query.andWhere('order.user_id = :user_id', { user_id: user_id.id })
    !!employee_id && query.andWhere('order.employee_id = :employee_id', { employee_id })
    !!payment_type && query.andWhere('order.payment_type = :payment_type', { payment_type })
    !!shopping_cart_id && query.andWhere('order.shopping_cart_id = :shopping_cart_id', { shopping_cart_id })

    query.leftJoinAndSelect('order.products', 'products')
    query.leftJoinAndMapOne('products.product', 'products.product_id', 'product')
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')
    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id: user_id.id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('order.shopping_cart_id', 'shopping_cart_id')
    query.leftJoinAndSelect('shopping_cart_id.products', 'shopping_cart_products')
    query.leftJoinAndSelect('shopping_cart_products.product_id', 'shoppingCartProduct', 'shoppingCartProduct.is_active = :active', { active: true })
    query.leftJoinAndSelect('order.user_id', 'user_id')
    query.leftJoin('order.employee_id', 'employee_id')
      .addSelect(['employee_id.id', 'employee_id.first_name', 'employee_id.last_name'])

    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<Order>(query, options)
  }

  async findOrderById(id: string, user_id?: Number): Promise<Order> {
    const query = this.createQueryBuilder('order')

    query.where("order.id = :id", { id: Number(id) })
    !!user_id && query.andWhere('order.user_id = :user_id', { user_id })

    query.leftJoinAndSelect('order.products', 'products')
    query.leftJoinAndMapOne('products.product', 'products.product_id', 'product')
    query.leftJoinAndSelect('product.departments', 'departments')
    query.leftJoinAndSelect('product.sections', 'sections')
    query.loadRelationCountAndMap('product.likes_count', 'product.likes')
    !!user_id
      ? query.leftJoinAndSelect('product.likes', 'likes', 'likes.user_id = :user_id', { user_id })
      : query.leftJoinAndSelect('product.likes', 'likes')
    query.leftJoinAndSelect('order.shopping_cart_id', 'shopping_cart_id')
    query.leftJoinAndSelect('shopping_cart_id.products', 'shopping_cart_products')
    query.leftJoinAndSelect('shopping_cart_products.product_id', 'shoppingCartProduct', 'shoppingCartProduct.is_active = :active', { active: true })
    query.leftJoinAndSelect('order.user_id', 'user_id')
    query.leftJoin('order.employee_id', 'employee_id')
      .addSelect(['employee_id.id', 'employee_id.first_name', 'employee_id.last_name'])

    return query.getOne()
  }

}
