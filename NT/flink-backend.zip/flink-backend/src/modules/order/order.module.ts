import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { PassportModule } from '@nestjs/passport'
import { OrderRepository } from './order.repository'
import { OrderController } from './order.controller'
import { OrderService } from './order.service'
import { ShoppingCartModule } from '../shopping-cart/shopping-cart.module'

@Module({
  imports: [
    TypeOrmModule.forFeature([OrderRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
    ShoppingCartModule,
  ],
  controllers: [OrderController],
  providers: [OrderService],
})
export class OrderModule { }
