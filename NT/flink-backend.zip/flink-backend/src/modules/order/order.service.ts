import { BadRequestException, ConflictException, ForbiddenException, Inject, Injectable, NotFoundException } from "@nestjs/common";
import { Pagination } from "nestjs-typeorm-paginate";
import { ShoppingCartService } from "../shopping-cart/shopping-cart.service";
import { User, UserAccessLevel } from "../users/user.entity";
import { CreateOrderDto } from "./dto/create-order.dto";
import { FindOrderQueryDto } from "./dto/find-order-query-dto";
import { UserRequestCheckoutDto } from "./dto/user-request-checkout.dto";
import { UpdateOrderDto } from "./dto/update-order.dto";
import { Order, Status } from "./order.entity";
import { OrderRepository } from "./order.repository";
import { AddProductToOrderDto } from "./dto/add-product-order.dto";
import { getCustomRepository, getRepository, Repository } from "typeorm";
import { Product } from "../product/product.entity";
import { CHECKOUT_STATUS, OrderProduct } from "../order-product/order-product.entity";
import { RemoveProductToOrderDto } from "./dto/remove-product-order.dto";
import { PayOrderDto } from "./dto/pay-order.dto";
import { ShoppingCart } from "../shopping-cart/shopping-cart.entity";
import { REQUEST } from "@nestjs/core";
import { DatabaseMiddleware } from "src/infrastructure/middleware/database.middleware";
import { UpdateMultiplierPriceDto } from "./dto/update-multiplier-price.dto";

@Injectable()
export class OrderService {
  private orderRepository: OrderRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
    private shoppingCartService: ShoppingCartService,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.orderRepository = getCustomRepository(OrderRepository, this.companyName)
  }

  async createOrder(createOrderDto: CreateOrderDto): Promise<Order> {
    return await this.orderRepository.createOrder(createOrderDto);
  }

  async findOrderById(orderId: string, user_id?: Number): Promise<Order> {
    return await this.orderRepository.findOrderById(orderId, user_id);
  }

  async findOrders(findOrderDto: FindOrderQueryDto): Promise<Pagination<Order>> {
    return await this.orderRepository.findOrder(findOrderDto);
  }

  async updateOrder(updateOrderDto: UpdateOrderDto, id: string): Promise<Order> {
    const result = await this.orderRepository.update(id, updateOrderDto);

    if (result.affected > 0) {
      const order = await this.findOrderById(id);
      return order;
    } else {
      throw new NotFoundException('Compra não encontrada')
    }
  }

  async deleteOrder(id: string) {
    const result = await this.orderRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrado uma compra com o ID informado')
    }
  }

  async takeCheckout(id: string, employee_id: User): Promise<Order> {
    const order = await this.findOrderById(id);
    if (!order) {
      throw new NotFoundException('Checkout não encontrado')
    }
    if (order.status != Status.WaitingCheckout) {
      throw new ConflictException('Não foi possível obter este checkout')
    }

    order.employee_id = employee_id
    order.status = Status.InProgress
    return await this.orderRepository.save(order)
  }

  async requestCheckout(checkout: UserRequestCheckoutDto, user_id: User): Promise<Order> {
    let shoppingCart: ShoppingCart
    if (!!checkout.shopping_cart_id) {
      shoppingCart = await this.shoppingCartService.findShoppingCartById(
        checkout.shopping_cart_id.toString(),
        user_id.id)
      if (!shoppingCart) {
        throw new ForbiddenException('Usuário não possui autorização para gerenciar este carrinho')
      }
    }

    const order = await this.createOrder({
      shopping_cart_id: shoppingCart,
      note: checkout.note,
      status: Status.WaitingCheckout,
      user_id,
    } as CreateOrderDto)

    const productRepository = getRepository(Product, this.companyName)
    const orderProducts: OrderProduct[] = []
    try {
      await Promise.all(
        checkout.products.map(async product => {
          orderProducts.push(...(await this.createProductListEntity({
            ...product,
            product_id: product.id
          }, productRepository, order, CHECKOUT_STATUS.NOT_CONFIRMED)))
        }))
    } catch (error) {
      await this.orderRepository.remove(order)
      throw error
    }
    order.first_total = this.productsTotalPrice(orderProducts)
    await this.orderRepository.save(order)
    await this.orderRepository.manager.save(orderProducts)

    return order
  }

  productsTotalPrice = (orderProducts: OrderProduct[]): number => (
    orderProducts.reduce((accum, { product_price }) => accum + product_price, 0.0)
  )

  async createProductListEntity(
    products: AddProductToOrderDto,
    productRepository: Repository<Product>,
    order: Order,
    checkout_status: number
  ): Promise<OrderProduct[]> {
    const product = await productRepository.findOne(
      { id: products.product_id },
      { select: ['id', 'price', 'is_fractional'] }
    )
    if (!product) {
      throw new NotFoundException('Produto não encontrado!', JSON.stringify(products))
    }

    if (!product.is_fractional) {
      products.multiplier_price = 1.0
    }
    let product_price = product.price * products.multiplier_price

    const orderProducts: OrderProduct[] = []
    for (let i = 0; i < products.quantity; i++) {
      // Cria o objeto do OrderProduct, mas não persiste no DB
      orderProducts.push(OrderProduct.create({
        product_id: product,
        multiplier_price: products.multiplier_price,
        product_price,
        order_id: order,
        checkout_status
      }))
    }
    return orderProducts
  }

  async addProduct(products: AddProductToOrderDto[], order_id: string) {
    const order = await this.findOrderById(order_id)

    if (!order) {
      throw new NotFoundException('Checkout não encontrado!')
    }

    if (order.status != Status.InProgress) {
      throw new ConflictException('Order não disponível para adição de produtos!')
    }

    const orderProducts: OrderProduct[] = []
    const productRepository = getRepository(Product, this.companyName)
    const orderProductQuery = getRepository(OrderProduct, this.companyName)
      .createQueryBuilder('order_product')
    await Promise.all(products.map(async product => {
      let { multiplier_price = 1.0, product_id, quantity = 1 } = product
      // Procura por produtos já existentes na lista do Order e atualiza
      // "checkout_status" para CONFIRMED, respeitando a quantidade informada
      // pelo colaborador
      const existentsProducts = await orderProductQuery
        .update(OrderProduct)
        .set({ checkout_status: CHECKOUT_STATUS.CONFIRMED })
        .where('order_product.id IN ('
          + getRepository(OrderProduct, this.companyName)
            .createQueryBuilder()
            .select('id')
            .andWhere('product_id = :product_id')
            .andWhere('multiplier_price = :multiplier_price')
            .andWhere('checkout_status = :checkout_status')
            .andWhere('order_id = :order_id')
            .limit(quantity)
            .getQuery()
          + ')')
        .setParameters({
          product_id,
          multiplier_price,
          checkout_status: CHECKOUT_STATUS.NOT_CONFIRMED,
          order_id
        })
        .execute()

      // Caso o produto não esteja na lista inicial ou houve excedentes,
      // ele será adicionado à lista e marcado com "checkout_status" = ADDED_LATER
      quantity -= existentsProducts.affected
      orderProducts.push(...(
        await this.createProductListEntity({
          multiplier_price, product_id, quantity
        }, productRepository, order, CHECKOUT_STATUS.ADDED_LATER)
      ))
    }))
    return await this.orderRepository.manager.save(orderProducts)
  }

  async removeProduct(product: RemoveProductToOrderDto, order_id: string) {
    const { multiplier_price, order_product_id, product_id, quantity } = product

    const order = await this.orderRepository.findOrderById(order_id)
    if (order.status != Status.InProgress) {
      throw new ConflictException('Order não disponível para remoção de produtos!')
    }

    if (!order_product_id && !product_id) {
      throw new BadRequestException('Deve ser informado o order_product_id ou product_id')
    }
    const orderProductRepository = getRepository(OrderProduct, this.companyName)

    const whereSubQuery = getRepository(OrderProduct, this.companyName)
      .createQueryBuilder()
      .select('id')
      .where('order_id = :order_id')
      .andWhere('checkout_status > :not_confirmed')
    quantity !== undefined && whereSubQuery.limit(quantity)
    !!order_product_id && whereSubQuery.andWhere('id = :order_product_id')
    !!product_id && whereSubQuery.andWhere('product_id = :product_id')
    !!multiplier_price && whereSubQuery.andWhere('multiplier_price = :multiplier_price')

    // todo: primeiro apagar os produtos ADDED_LATER para depois resetar o status para NOT_CONFIRMED
    const query = orderProductRepository.createQueryBuilder('order_product')
      .update(OrderProduct)
      .set({ checkout_status: CHECKOUT_STATUS.NOT_CONFIRMED })
      .andWhere('order_product.id IN (' + whereSubQuery.getQuery() + ')')
      .setParameters({
        order_id,
        product_id,
        order_product_id,
        multiplier_price,
        added_later: CHECKOUT_STATUS.ADDED_LATER,
        not_confirmed: CHECKOUT_STATUS.NOT_CONFIRMED
      })
    const result = await query.execute()
    if (result.affected === 0) {
      throw new NotFoundException('Produto não encontrado. Nada foi alterado')
    }

    return result
  }

  async giveupCheckout(id: string, user: User) {
    const order = await this.findOrderById(id)
    if (!order) {
      throw new NotFoundException('Checkout não encontrado')
    }

    if (![Status.InProgress, Status.WaitingCheckout, Status.WaitingPayment].includes(order.status)) {
      throw new ConflictException('Não foi possível aplicar a desistência do cliente')
    }

    if (user.access_level === UserAccessLevel.Customer
      && (order.user_id.id !== user.id || order.status !== Status.WaitingCheckout)) {
      throw new ForbiddenException('Usuário não tem permissão para este recurso ')
    }

    order.status = Status.GiveUp
    return await this.orderRepository.save(order)
  }

  async waitForPayment(id: string) {
    const order = await this.findOrderById(id)
    if (!order) {
      throw new NotFoundException('Checkout não encontrado')
    }

    if (order.status !== Status.InProgress) {
      throw new ConflictException('Não é possível aguardar pelo pagamento para esta order')
    }

    order.status = Status.WaitingPayment
    return await this.orderRepository.save(order)
  }

  async payCheckout(payOrder: PayOrderDto, id: string) {
    const order = await this.findOrderById(id)
    if (!order) {
      throw new NotFoundException('Checkout não encontrado')
    }

    if (![Status.WaitingPayment].includes(order.status)) {
      throw new ConflictException('Não foi possível efetuar o pagamento para esta compra')
    }

    order.payment_type = payOrder.payment_type
    order.total_paid = payOrder.total_paid
    order.status = Status.Paid
    return await this.orderRepository.save(order)
  }

  async updateMultiplierPrice({ multiplier_price }: UpdateMultiplierPriceDto, id: string) {
    const orderProductRepository = getRepository(OrderProduct, this.companyName)
    const orderProduct = await orderProductRepository.findOne(
      { id: Number(id) },
      { relations: ['product_id', 'order_id'] }
    )

    if (!orderProduct) {
      throw new NotFoundException('OrderProduct não encontrado');
    }

    if (orderProduct.order_id.status !== Status.InProgress || !orderProduct.product_id.is_fractional) {
      throw new ConflictException('Não é possível atualizar o multiplier_price deste produto')
    }

    orderProduct.multiplier_price = multiplier_price;
    orderProduct.product_price = multiplier_price * orderProduct.product_id.price;
    await orderProductRepository.save(orderProduct);

    return this.findOrderById(orderProduct.order_id.id.toString());
  }

}
