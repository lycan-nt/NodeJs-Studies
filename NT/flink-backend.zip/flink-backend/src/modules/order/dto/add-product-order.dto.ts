import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { IsNumber, IsOptional } from 'class-validator'

export class AddProductToOrderDto {
  @ApiProperty({ description: 'Id do produto para adicionar ao checkout' })
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id válido para o product_id' })
  product_id: number

  @ApiPropertyOptional({ description: 'Valor fracionado do produto para ser adicionado ao carrinho. Ex. 0.5 (kg)', default: 1.0 })
  @IsOptional()
  multiplier_price: number = 1.0

  @ApiPropertyOptional({ description: 'Quantidade de itens do mesmo produto que está sendo adicionado ao carrinho', default: 1 })
  @IsOptional()
  quantity: number = 1
}
