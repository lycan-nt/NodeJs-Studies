import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { IsNumber, IsOptional } from 'class-validator'

export class RemoveProductToOrderDto {
  @ApiPropertyOptional({ description: 'Id do produto no checkout (na relação Order-Product)' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id (numérico) válido para o order_product_id' })
  order_product_id: number

  @ApiPropertyOptional({ description: 'Id do produto' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id (numérico) válido para o product_id' })
  product_id: number

  @ApiPropertyOptional({ description: 'Valor fracionado do produto a ser localizado' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 }, { message: 'Informe um valor (numérico) válido para o multiplier_price' })
  multiplier_price: number

  @ApiPropertyOptional({ description: 'Quantidadde do produto que será removido da Order' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um valor inteiro válido para o quantity' })
  quantity: number
}
