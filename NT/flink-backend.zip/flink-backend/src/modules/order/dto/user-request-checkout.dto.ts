import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { IsNumber, IsOptional } from 'class-validator'

export class ProductsCheckoutDto {
  @ApiProperty({ description: 'Id do produto para ser inserido à lista do checkout' })
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id válido para o produto' })
  id: number

  @ApiPropertyOptional({ description: 'Quantidade de vezes que o produto informado será adicionado ao checkout' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um valor do tipo inteiro para o produto' })
  quantity: number

  @ApiPropertyOptional({ description: 'Valor fracionado do produto' })
  @IsOptional()
  multiplier_price: number
}

export class UserRequestCheckoutDto {
  @ApiPropertyOptional({ description: 'Id do carrinho para efetuar checkout' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id válido para o shopping_cart_id' })
  shopping_cart_id: number

  @ApiPropertyOptional({ description: 'Descrição para apresentar ao colaborador' })
  @IsOptional()
  note: string

  @ApiProperty({ description: 'Id do carrinho para efetuar checkout', type: [ProductsCheckoutDto] })
  products: ProductsCheckoutDto[]
}
