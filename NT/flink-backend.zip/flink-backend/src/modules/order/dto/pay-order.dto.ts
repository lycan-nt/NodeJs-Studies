import { ApiProperty } from '@nestjs/swagger'
import { IsEnum, IsNumber } from 'class-validator'
import { PaymentType } from '../order.entity'

export class PayOrderDto {
  @ApiProperty({ description: 'Valor final pago pelo cliente' })
  @IsNumber({ maxDecimalPlaces: 2 }, { message: 'Informe um valor válido para o total pago' })
  total_paid: number

  @ApiProperty({ enum: PaymentType, enumName: 'PaymentType' })
  @IsEnum(PaymentType, { message: 'Tipo de pagamento inválido' })
  payment_type: PaymentType
}
