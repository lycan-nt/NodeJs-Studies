import {
  MaxLength,
  IsNumber,
  IsEnum,
  IsOptional,
  IsString,
} from 'class-validator'
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger'
import { PaymentType, Status } from '../order.entity'
import { User } from 'src/modules/users/user.entity'
import { ShoppingCart } from 'src/modules/shopping-cart/shopping-cart.entity'

export class CreateOrderDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 }, {
    message: 'Deve ser informado um valor de até duas casas decimais'
  })
  first_total: number

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 2 }, {
    message: 'Deve ser informado um valor de até duas casas decimais'
  })
  total_paid: number

  @ApiPropertyOptional({ enum: PaymentType, enumName: 'PaymentType' })
  @IsOptional()
  @IsEnum(PaymentType)
  payment_type: PaymentType

  @ApiProperty()
  @IsOptional()
  @IsString({ message: 'Deve ser informado uma string' })
  @MaxLength(255, { message: 'O text deve ter menos de 255 caracteres' })
  note: string

  @ApiProperty({ description: 'Id do cliente que está finalizando a compra' })
  @IsNumber()
  user_id: User

  @ApiProperty()
  @IsNumber()
  shopping_cart_id: ShoppingCart

  @ApiPropertyOptional({ description: 'Id do colaborador que está finalizando a compra' })
  @IsOptional()
  @IsNumber()
  employee_id: User

  @ApiPropertyOptional({ enum: Status, enumName: 'Status' })
  @IsOptional()
  @IsEnum(Status)
  status: Status
}
