import { ApiPropertyOptional } from '@nestjs/swagger'
import { IsNumber, IsOptional } from 'class-validator'

export class UpdateProductToOrderDto {
  @ApiPropertyOptional({ description: 'Definindo esta propriedade faz com que a alteração aconteça apenas no produto selecionado' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id (numérico) válido para o order_product_id' })
  order_product_id: number

  @ApiPropertyOptional({ description: 'Definindo apenas esta propriedade faz com que a alteração aconteça em todos os produtos do checkout' })
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'Informe um id (numérico) válido para o product_id' })
  product_id: number

  @ApiPropertyOptional({ description: 'Valor fracionado do produto para ser adicionado ao carrinho. Ex. 0.5 (kg)', default: 1.0 })
  @IsOptional()
  multiplier_price: number

  @ApiPropertyOptional({
    description: 'Definindo esta propriedade, fará com que todos os produtos do filtro aplicado (order_product_id e product_id) seja excluído do checkout para, então, ser adicionado novamente com os novos valores'
  })
  @IsOptional()
  quantity: number
}
