import { ApiProperty } from '@nestjs/swagger'
import { IsNumber } from 'class-validator'

export class UpdateMultiplierPriceDto {
  @ApiProperty({ description: 'Valor fracionado do produto para ser adicionado ao carrinho. Ex. 0.5 (kg)', required: true, example: 0.5 })
  @IsNumber({ maxDecimalPlaces: 2 }, { message: 'Deve ser informado um valor numérico' })
  multiplier_price: number;
}
