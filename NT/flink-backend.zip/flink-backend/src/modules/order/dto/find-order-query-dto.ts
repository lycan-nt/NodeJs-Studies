import { ApiPropertyOptional } from '@nestjs/swagger'
import { ShoppingCart } from 'src/modules/shopping-cart/shopping-cart.entity'
import { User } from 'src/modules/users/user.entity'
import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto'
import { PaymentType, Status } from '../order.entity'

export class FindOrderQueryDto extends BaseQueryParametersDto {
  @ApiPropertyOptional({ description: 'Filtrar por tipo de pagamento' })
  payment_type: PaymentType

  @ApiPropertyOptional({ description: 'Filtrar por id do cliente' })
  user_id: User

  @ApiPropertyOptional({ description: 'Filtrar por id do carrinho' })
  shopping_cart_id: ShoppingCart

  @ApiPropertyOptional({ description: 'Filtrar por id do colaborador' })
  employee_id: User

  @ApiPropertyOptional({ description: 'Filtrar por status de compra' })
  status: Status
}
