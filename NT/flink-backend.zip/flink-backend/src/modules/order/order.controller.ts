import { Body, Controller, Delete, Get, NotFoundException, Param, Patch, Post, Query, Req, UseGuards, ValidationPipe } from "@nestjs/common";
import { AuthGuard } from "@nestjs/passport";
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from "@nestjs/swagger";
import { Pagination } from "nestjs-typeorm-paginate";
import { AccessLevel } from "../auth/role.decorator";
import { AccessLevelGuard } from "../auth/roles.guard";
import { User, UserAccessLevel } from "../users/user.entity";
import { CreateOrderDto } from "./dto/create-order.dto";
import { FindOrderQueryDto } from "./dto/find-order-query-dto";
import { UpdateOrderDto } from "./dto/update-order.dto";
import { UserRequestCheckoutDto } from "./dto/user-request-checkout.dto";
import { AddProductToOrderDto } from "./dto/add-product-order.dto";
import { Order } from "./order.entity";
import { OrderService } from "./order.service";
import { RemoveProductToOrderDto as RemoveProductFromOrderDto } from "./dto/remove-product-order.dto";
import { PayOrderDto } from "./dto/pay-order.dto";
import { UpdateMultiplierPriceDto } from "./dto/update-multiplier-price.dto";


@ApiTags('order')
@ApiBearerAuth('JWT')
@Controller('order')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class OrderController {
  constructor(private orderService: OrderService) { }

  @ApiOperation({
    summary: 'Create Order',
    description: 'Cria uma nova compra'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 409, description: 'Compra já existe' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async createOrder(@Body(ValidationPipe) createOrderDto: CreateOrderDto): Promise<Order> {
    return await this.orderService.createOrder(createOrderDto)
  }

  @ApiOperation({
    summary: 'Find Order',
    description: 'Retorna os dados de uma compra a partir do Id.'
  })
  @ApiResponse({ status: 200, description: 'Compra encontrada' })
  @ApiResponse({ status: 404, description: 'Compra não encontrada ou você não tem permissão de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get(':id')
  async findOrderById(
    @Param('id') id,
    @Req() req: any): Promise<Order> {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    let user_id = null
    if (!isAdmin) {
      user_id = user.id
    }
    const order = await this.orderService.findOrderById(id, user_id)
    if (!order) {
      throw new NotFoundException('Compra não encontrada ou você não tem permissão de acesso!')
    }
    return order
  }

  @ApiOperation({
    summary: 'Find Order',
    description: 'Lista todas as compras no sistema, podendo ter filtros.'
  })
  @ApiResponse({ status: 200, description: 'Compras encontradas' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get()
  async findOrders(
    @Query() query: FindOrderQueryDto,
    @Req() req: any): Promise<Pagination<Order>> {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)

    if (!isAdmin) {
      query.user_id = user
    }
    return await this.orderService.findOrders(query)
  }

  @ApiOperation({
    summary: 'Update Order',
    description: 'Atualiza uma compra'
  })
  @ApiResponse({ status: 200, description: 'Compra atualizada' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async updateOrder(@Body(ValidationPipe) updateOrderDto: UpdateOrderDto, @Param('id') id: string) {
    return await this.orderService.updateOrder(updateOrderDto, id)
  }

  @ApiOperation({
    summary: 'Delete Order',
    description: 'Apaga uma compra'
  })
  @ApiResponse({ status: 200, description: 'Compra atualizada' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async deleteOrder(@Param('id') id: string) {
    await this.orderService.deleteOrder(id)
    return {
      message: 'Compra removida com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Take a Order checkout',
    description:
      `- O colaborador faz um Get para \`/v1/order/checkout/:id_order\`.
- O sistema irá alterar o status de \`wait_checkout\` para \`in_progress\` e associar a Order ao id do colaborador.
- O customer receberá uma notificação de que o checkout foi iniciado.`
  })
  @ApiResponse({ status: 200, description: 'Checkout iniciado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'Checkout não encontrado' })
  @ApiResponse({ status: 409, description: 'Não foi possível obter este checkout' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get('checkout/:id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee])
  async takeCheckout(
    @Param('id') id: string,
    @Req() req: any) {

    const { user } = req
    return await this.orderService.takeCheckout(id, user)
  }

  @ApiOperation({
    summary: 'Request a new Order checkout',
    description:
      `- O Customer faz um POST para \`/v1/order/checkout\` informando o \`id\` do carrinho e uma breve descrição que ajude o colaborador identificá-lo fisicamente
- O sistema irá criar uma nova Order com o status \`waiting_checkout\` e notificará todos os colaboradores ativos no momento.`
  })
  @ApiResponse({ status: 200, description: 'Checkout iniciado' })
  @ApiResponse({ status: 403, description: 'Usuário não possui autorização para gerenciar este carrinho' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post('checkout')
  async requestCheckout(
    @Body(ValidationPipe) checkout: UserRequestCheckoutDto,
    @Req() req: any) {
    const { user } = req
    return await this.orderService.requestCheckout(checkout, user)
  }

  @ApiOperation({
    summary: 'Add a product to checkout',
    description:
      `- O colaborador faz um POST para \`/v1/order/product/:id_order\`.
- O corpo da mensagem deve ter, obrigatoriamente, o id do produto e, opcionalmente, a quantidade e o multiplicador de preço do produto.
- O sistema irá armazenar a quantidade de itens informado.
- Também irá armazenar o preço do produto no momento da compra seguindo o cálculo \`price x multiplier_price\`, sendo válido apenas para produtos que sejam \`is_fractional = true\`.`
  })
  @ApiResponse({ status: 201, description: 'Produto adicionado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'Checkout não encontrado ou Produto não encontrado!' })
  @ApiResponse({ status: 409, description: 'Checkout não disponível para adição de produtos!' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post('product/:id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee])
  async addProduct(
    @Param('id') id: string,
    @Body(ValidationPipe) product: AddProductToOrderDto[]
  ) {
    await this.orderService.addProduct(product, id)
    return await this.orderService.findOrderById(id)
  }

  @ApiOperation({
    summary: 'Update multiplier price from product',
    description:
      `- O colaborador faz um PATCH para \`/v1/order/product/multiplier_price/:order_product_id\`.
- O corpo da mensagem deve ter, obrigatoriamente, o multiplicador de preço do produto.
- O sistema irá atualizar o produto com o valor informado, desde que o produto seja de uma Order que está com o status \`in_progress\`.
- Também irá atualizar o preço do produto (\`product_price\`) seguindo o cálculo \`price x multiplier_price\`.`
  })
  @ApiResponse({ status: 200, description: 'Produto atualizado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'OrderProduct não encontrado!' })
  @ApiResponse({ status: 409, description: 'Não é possível atualizar o multiplier_price deste produto!' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch('product/multiplier_price/:order_product_id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee])
  async updateMultiplierPrice(
    @Param('order_product_id') id: string,
    @Body(ValidationPipe) multiplierPrice: UpdateMultiplierPriceDto
  ) {
    return await this.orderService.updateMultiplierPrice(multiplierPrice, id);
  }

  // @ApiOperation({
  //   summary: 'Update a product in checkout',
  //   description: 'Atualiza um produto do checkout'
  // })
  // @Post('product/:id')
  // // @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee])
  // async updateProduct(
  //   @Param('id') id: string,
  //   @Body(ValidationPipe) product: UpdateProductToOrderDto,
  //   @Req() req: any) {
  //   const { user } = req
  //   return await this.orderService.updateProduct(product, id)
  // }

  @ApiOperation({
    summary: 'Remove a product from checkout',
    description: 'Remove um produto do checkout'
  })
  @ApiResponse({ status: 201, description: 'Produto adicionado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'Produto não encontrado no checkout' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete('product/:id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager])
  async DeleteProduct(
    @Param('id') id: string,
    @Body(ValidationPipe) product: RemoveProductFromOrderDto
  ) {
    return await this.orderService.removeProduct(product, id)
  }

  @ApiOperation({
    summary: 'Informa que o cliente desistiu da compra',
    description: `- O colaborador faz um Get para \`/v1/order/giveup/:id_order\`.
- O sistema irá alterar o status para \`give_up\`.`
  })
  @ApiResponse({ status: 200, description: 'Produto adicionado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'Checkout não encontrado' })
  @ApiResponse({ status: 409, description: 'Não foi possível aplicar a desistência do cliente' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get('giveup/:id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee, UserAccessLevel.Customer])
  async customerGiveUp(
    @Param('id') id: string,
    @Req() req: any
  ) {
    const user = req.user as User
    return await this.orderService.giveupCheckout(id, user)
  }

  @ApiOperation({
    summary: 'Informa que o colaborador finalizou o checkout e está aguardando pelo pagamento do cliente',
    description: `- O colaborador faz um Get para \`/v1/order/waitpayment/:id_order\`.
- O sistema irá alterar o status para \`waiting_payment\`.`
  })
  @ApiResponse({ status: 200, description: 'Status do checkout alterado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'Checkout não encontrado' })
  @ApiResponse({ status: 409, description: 'Não é possível aguardar pelo pagamento para esta order' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get('waitpayment/:id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee])
  async waitForPayment(
    @Param('id') id: string
  ) {
    return await this.orderService.waitForPayment(id)
  }

  @ApiOperation({
    summary: 'Informa que o cliente pagou a compra',
    description:
      `- O colaborador faz um Get para \`/v1/order/pay/:id_order\`.
- O sistema irá alterar o status para \`paid\`.`
  })
  @ApiResponse({ status: 200, description: 'Produto adicionado' })
  @ApiResponse({ status: 403, description: 'Usuário não tem permissão de acesso' })
  @ApiResponse({ status: 404, description: 'Checkout não encontrado' })
  @ApiResponse({ status: 409, description: 'Não foi possível efetuar o pagamento para esta compra' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post('pay/:id')
  @AccessLevel([UserAccessLevel.Owner, UserAccessLevel.Manager, UserAccessLevel.Employee])
  async customerPay(
    @Param('id') id: string,
    @Body(ValidationPipe) payOrder: PayOrderDto
  ) {
    return await this.orderService.payCheckout(payOrder, id)
  }
}
