/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany, ManyToOne, JoinColumn } from 'typeorm'
import { OrderProduct } from '../order-product/order-product.entity'
import { ShoppingCart } from '../shopping-cart/shopping-cart.entity'
import { User } from '../users/user.entity'

export enum PaymentType {
  App = 'app',
  Debit = 'debit',
  Credit = 'credit',
}

export enum Status {
  Paid = 'paid',
  GiveUp = 'give_up',
  InProgress = 'in_progress',
  WaitingCheckout = 'waiting_checkout',
  WaitingPayment = 'waiting_payment',
}

@Entity()
@Unique(['id'])
export class Order extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ nullable: false, type: 'decimal', precision: 12, scale: 2, default: 0.00 })
  first_total: number

  @Column({ nullable: false, type: 'decimal', precision: 12, scale: 2, default: 0.00 })
  total_paid: number

  @Column({ nullable: true, type: 'enum', enum: PaymentType })
  payment_type: PaymentType

  @Column({ nullable: true, type: 'varchar', length: 255 })
  note: string

  @Column({ nullable: true, type: 'enum', enum: Status })
  status: Status

  @OneToMany(() => OrderProduct, orderProduct => orderProduct.order_id)
  products: OrderProduct[]

  @ManyToOne(() => ShoppingCart, shoppingCart => shoppingCart.orders, { nullable: true, eager: false })
  @JoinColumn({ name: 'shopping_cart_id' })
  shopping_cart_id: ShoppingCart

  @ManyToOne(() => User, user => user.orders, { nullable: false, eager: false })
  @JoinColumn({ name: 'user_id' })
  user_id: User

  @ManyToOne(() => User, user => user.employee_orders, { nullable: true, eager: false })
  @JoinColumn({ name: 'employee_id' })
  employee_id: User

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
