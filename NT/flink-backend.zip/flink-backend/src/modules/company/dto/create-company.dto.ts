import {
  IsEmail,
  IsNotEmpty,
  MaxLength,
  IsNumberString,
  IsNumber,
  IsEnum,
  IsOptional,
} from 'class-validator'
import { ApiProperty } from '@nestjs/swagger'
import { AccountType } from 'src/modules/company/company.entity'

export class CreateCompanyDto {
  @ApiProperty()
  @IsNotEmpty({ message: 'Informe o nome da empresa' })
  @MaxLength(255, { message: 'O nome da empresa deve ter menos de 255 caracteres' })
  name: string

  @ApiProperty()
  @IsNumberString({ no_symbols: true }, { message: 'Informe um CNPJ válido' })
  @IsNotEmpty({ message: 'Informe o número do CNPJ', })
  @MaxLength(14, { message: 'O número do CNPJ deve ter menos de 14 caracteres', })
  cnpj: string

  @ApiProperty()
  @IsNotEmpty({ message: 'Informe um endereço de email', })
  @IsEmail({}, { message: 'Informe um endereço de email válido', },)
  @MaxLength(255, { message: 'O endereço de email deve ter menos de 255 caracteres', })
  email: string

  @ApiProperty()
  @IsNotEmpty({ message: 'Informe um número de telefone' })
  @IsNumberString()
  @MaxLength(20, { message: 'O número de telefone deve ter menos de 20 caracteres' })
  phone: string

  @ApiProperty()
  @IsOptional()
  @IsNumberString({ no_symbols: true }, { message: 'O código do banco deve conter apenas números' })
  @MaxLength(5, { message: 'O código do banco deve ter menos de 5 caracteres' })
  bank: string

  @ApiProperty({ enum: AccountType, enumName: 'AccountType' })
  @IsOptional()
  @IsEnum(AccountType)
  account_type: AccountType

  @ApiProperty()
  @IsOptional()
  @IsNumber({ maxDecimalPlaces: 0 }, { message: 'A agência bancária deve conter apenas números inteiros' })
  agency: number

  @ApiProperty()
  @IsOptional()
  @IsNumberString({ no_symbols: true }, { message: 'A conta bancária deve conter apenas números' })
  @MaxLength(20, { message: 'O número da conta bancária deve ter até 20 caracteres' })
  account_number: string

  @ApiProperty()
  @IsOptional()
  @MaxLength(100, { message: 'O código do Ebanx API Key deve ter até 100 caracteres' })
  ebanx_api_key: string

  @ApiProperty()
  @IsOptional()
  @MaxLength(100, { message: 'O código do Google Client ID deve ter até 100 caracteres' })
  google_client_id: string

  @ApiProperty()
  @IsOptional()
  @MaxLength(100, { message: 'O código Google Secret deve ter até 100 caracteres' })
  google_secret: string
}
