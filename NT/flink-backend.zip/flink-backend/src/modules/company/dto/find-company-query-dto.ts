import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto'

export class FindCompanyQueryDto extends BaseQueryParametersDto {
  name: string
  cnpj: string
}
