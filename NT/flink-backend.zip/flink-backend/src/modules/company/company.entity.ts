/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, OneToMany, ManyToOne, JoinColumn } from 'typeorm'
import { Product } from '../product/product.entity'
import { User } from '../users/user.entity'

export enum AccountType {
  Poupanca = 'p',
  ContaCorrent = 'cc',
}

@Entity()
@Unique(['id', 'cnpj'])
export class Company extends BaseEntity {

  // constructor() {
  //   super()
  //   this.certificate_hex = "\\x" + (this.certificate ? this.certificate.toString("hex") : "");
  // }

  @PrimaryGeneratedColumn()
  id: number

  @Column({ nullable: false, type: 'varchar', length: 255 })
  name: string

  @Column({ nullable: false, type: 'varchar', length: 14 })
  cnpj: string

  @Column({ nullable: false, type: 'varchar', length: 255 })
  email: string

  @Column({ nullable: false, type: 'varchar', length: 20 })
  phone: string

  @Column({ nullable: true, type: 'varchar', length: 5, comment: 'Código da instituição financeira' })
  bank: string

  @Column({ nullable: true, type: 'enum', enum: AccountType })
  account_type: AccountType

  @Column({ nullable: true, type: 'int' })
  agency: number

  @Column({ nullable: true, type: 'varchar', length: 20 })
  account_number: string

  // https://github.com/typeorm/typeorm/issues/2878

  // @Column({ nullable: false, type: 'bytea', name: "cerificate" })
  // certificate_hex: string;

  // private _certificate: Buffer | undefined;

  // get certificate(): Buffer {
  //   if (!this._certificate) this._certificate = Buffer.from(this.certificate_hex, "hex");
  //   return this._certificate;
  // }

  @Column({ nullable: true, type: 'varchar', length: 100 })
  ebanx_api_key: string

  @Column({ nullable: true, type: 'varchar', length: 100 })
  google_client_id: string

  @Column({ nullable: true, type: 'varchar', length: 100 })
  google_secret: string

  @OneToMany(() => User, user => user.company_id)
  users: User[]

  @OneToMany(() => Product, product => product.company_id)
  products: Product[]

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
