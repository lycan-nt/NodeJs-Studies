import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { CompanyRepository } from './company.repository';
import { CompanyService } from './company.service';
import { CompanyController } from './company.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([CompanyRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [CompanyService],
  controllers: [CompanyController],
  exports: [CompanyModule]
})
export class CompanyModule { }
