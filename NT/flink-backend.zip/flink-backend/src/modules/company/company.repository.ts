import { EntityRepository, Repository } from 'typeorm'
import { ConflictException, InternalServerErrorException } from '@nestjs/common'
import { Company } from './company.entity'
import { CreateCompanyDto } from './dto/create-company.dto'
import { UpdateCompanyDto } from './dto/update-company.dto'
import { FindCompanyQueryDto } from './dto/find-company-query-dto'

@EntityRepository(Company)
export class CompanyRepository extends Repository<Company> {
  async createCompany(createCompanyDto: CreateCompanyDto): Promise<Company> {
    const company = this.create(createCompanyDto)

    try {
      return await this.save(company)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Empresa já existe')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar a empresa no banco de dados')
      }
    }
  }

  async findCompanies(queryDto: FindCompanyQueryDto): Promise<{ companies: Company[], total: number }> {
    queryDto.page = queryDto.page < 1 ? 1 : queryDto.page
    queryDto.limit = Math.min(queryDto.limit, 100)

    const { cnpj, name } = queryDto
    const query = this.createQueryBuilder('company')

    if (cnpj) {
      query.andWhere('company.cnpj ILIKE :cnpj', { cnpj: `%${cnpj}%` })
    }

    if (name) {
      query.andWhere('company.name ILIKE :name', { name: `%${name}%` })
    }

    // query.skip((queryDto.page - 1) * queryDto.limit);
    // query.take(+queryDto.limit);
    queryDto.sort && query.orderBy(JSON.parse(queryDto.sort))

    const [companies, total] = await query.getManyAndCount()

    return { companies, total }
  }

  async findOneCompany(id: string): Promise<Company> {
    return this.findOneOrFail(id);
  };

  async updateCompany(id: string, updateCompanyDto: UpdateCompanyDto): Promise<Company> {
    return this.save({ ...updateCompanyDto, id: Number(id) });
  };

  async removeCompany(id: string) {
    await this.findOneOrFail(id);
    return this.delete(id);
  };
}
