import { Inject, Injectable, NotFoundException } from '@nestjs/common'
import { CompanyRepository } from './company.repository'
import { CreateCompanyDto } from './dto/create-company.dto'
import { Company } from './company.entity'
import { UpdateCompanyDto } from './dto/update-company.dto'
import { FindCompanyQueryDto } from './dto/find-company-query-dto'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository } from 'typeorm'

@Injectable()
export class CompanyService {
  private companyRepository: CompanyRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.companyRepository = getCustomRepository(CompanyRepository, this.companyName)
  }

  async createCompnay(createCompanyDto: CreateCompanyDto): Promise<Company> {
    return this.companyRepository.createCompany(createCompanyDto)
  }

  async findCompanyById(companyId: string): Promise<Company> {
    const company = await this.companyRepository.findOne(companyId, {
      // select: ['email', 'name', 'phone', 'id'],
    })

    if (!company) throw new NotFoundException('Empresa não encontrada')

    return company
  }

  async updateCompany(updateCompanyDto: UpdateCompanyDto, id: string) {
    const result = await this.companyRepository.update(id, updateCompanyDto)
    if (result.affected > 0) {
      const company = await this.findCompanyById(id)
      return company
    } else {
      throw new NotFoundException('Empresa não encontrada')
    }
  }

  async deleteCompany(id: string) {
    const result = await this.companyRepository.delete(id)
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrado uma empresa com o ID informado')
    }
  }

  async findCompanies(queryDto: FindCompanyQueryDto): Promise<{ companies: Company[]; total: number }> {
    return await this.companyRepository.findCompanies(queryDto)
  }
}
