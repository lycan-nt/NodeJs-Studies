import { Controller, Post, Body, ValidationPipe, UseGuards, Get, Param, Patch, Delete, Query } from '@nestjs/common'
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger'
import { AuthGuard } from '@nestjs/passport'
import { AccessLevelGuard } from '../auth/roles.guard'
import { AccessLevel } from '../auth/role.decorator'
import { CompanyService } from './company.service'
import { CreateCompanyDto } from './dto/create-company.dto'
import { Company } from './company.entity'
import { UpdateCompanyDto } from './dto/update-company.dto'
import { FindCompanyQueryDto } from './dto/find-company-query-dto'
import { UserAccessLevel } from '../users/user.entity'

@ApiTags('company')
@ApiBearerAuth('JWT')
@Controller('company')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class CompanyController {
  constructor(private companyService: CompanyService) { }

  @ApiOperation({
    summary: 'Create Company',
    description: 'Create a new customer'
  })
  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async createCompany(@Body(ValidationPipe) createCompanyDto: CreateCompanyDto): Promise<Company> {
    return await this.companyService.createCompnay(createCompanyDto)
  }

  @ApiOperation({
    summary: 'Find Company',
    description: 'Find a company by id'
  })
  @Get(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async findCompanyById(@Param('id') id): Promise<Company> {
    return await this.companyService.findCompanyById(id)
  }

  @ApiOperation({
    summary: 'Find Companies',
    description: 'Find companies by query'
  })
  @Get()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async findCompanies(@Query() query: FindCompanyQueryDto) {
    return await this.companyService.findCompanies(query)
  }

  @ApiOperation({
    summary: 'Update Company',
    description: 'Update a company by id'
  })
  @Patch(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async updateCompany(@Body(ValidationPipe) updateCompanyDto: UpdateCompanyDto, @Param('id') id: string) {
    // if (user.role != UserRole.ADMIN && user.id.toString() != id) {
    //   throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
    // }
    return this.companyService.updateCompany(updateCompanyDto, id)
  }

  @ApiOperation({
    summary: 'Delete Company',
    description: 'Delete a company by id'
  })
  @Delete(':id')
  @AccessLevel([UserAccessLevel.Owner])
  async deleteCompany(@Param('id') id: string) {
    await this.companyService.deleteCompany(id)
    return {
      message: 'Empresa removida com sucesso',
    }
  }
}
