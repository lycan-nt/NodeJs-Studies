import { ApiPropertyOptional } from "@nestjs/swagger"

export abstract class BaseQueryParametersDto {
  @ApiPropertyOptional({ description: 'Organiza o resultado na ordem escolhida', example: { id: "DESC" } })
  sort: string

  @ApiPropertyOptional({ description: 'Seleciona a página para a consulta realizada', example: 1 })
  page: number

  @ApiPropertyOptional({ description: 'Define a quantidade de itens que cada consulta deve retornar', example: 10 })
  limit: number
}
