import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateSectionDto {

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @MaxLength(255, { message: 'O nome deve ter no máximo 255 caracteres' })
  name: string

}
