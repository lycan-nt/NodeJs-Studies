import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, MaxLength } from 'class-validator';

export class FindSectionsQueryDto extends BaseQueryParametersDto {

  @ApiPropertyOptional({ description: 'Busca pelo nome da seção' })
  @IsOptional()
  @MaxLength(255, { message: 'O nome deve ter no máximo 255 caracteres' })
  name: string

}
