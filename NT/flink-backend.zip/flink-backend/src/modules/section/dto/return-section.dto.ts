import { Section } from '../section.entity';

export class ReturnSectionDto {
  section: Section
  message: string
}
