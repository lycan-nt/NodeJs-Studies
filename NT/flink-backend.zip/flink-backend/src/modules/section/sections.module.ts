import { Module } from '@nestjs/common';
import { SectionRepository } from './section.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { SectionsService } from './sections.service';
import { SectionsController } from './sections.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([SectionRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [SectionsService],
  controllers: [SectionsController],
  exports: [SectionsModule]
})
export class SectionsModule {}
