import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { SectionRepository } from './section.repository';
import { CreateSectionDto } from './dto/create-section.dto';
import { Section } from './section.entity';
import { UpdateSectionDto } from './dto/update-section.dto';
import { FindSectionsQueryDto } from './dto/find-sections-query.dto';
import { Pagination } from 'nestjs-typeorm-paginate';
import { REQUEST } from '@nestjs/core';
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware';
import { getCustomRepository } from 'typeorm';

@Injectable()
export class SectionsService {
  private sectionRepository: SectionRepository
  private companyName: string

  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.sectionRepository = getCustomRepository(SectionRepository, this.companyName)
  }

  async createSection(createSectionDto: CreateSectionDto): Promise<Section> {
    return this.sectionRepository.createSection(createSectionDto)
  }

  async findSectionById(sectionId: number): Promise<Section> {
    const section = await this.sectionRepository.findOne(sectionId)

    if (!section) throw new NotFoundException('Seção não encontrada')

    return section
  }

  async updateSection(updateSectionDto: UpdateSectionDto, id: number) {
    const result = await this.sectionRepository.update({ id }, updateSectionDto)
    if (result.affected > 0) {
      const section = await this.findSectionById(id)
      return section
    } else {
      throw new NotFoundException('Seção não encontrada')
    }
  }

  async deleteSection(sectionId: number) {
    const result = await this.sectionRepository.delete({ id: sectionId })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrada uma seção com o ID informado')
    }
  }

  async findSections(queryDto: FindSectionsQueryDto): Promise<Pagination<Section>> {
    return await this.sectionRepository.findSections(queryDto)
  }

}
