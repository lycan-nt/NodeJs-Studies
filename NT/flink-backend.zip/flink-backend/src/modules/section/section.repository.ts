import { EntityRepository, Repository } from 'typeorm';
import { FindSectionsQueryDto } from './dto/find-sections-query.dto';
import { Pagination, IPaginationOptions, paginate } from 'nestjs-typeorm-paginate';
import { Section } from './section.entity';
import { BadRequestException, ConflictException, InternalServerErrorException } from '@nestjs/common';
import { CreateSectionDto } from './dto/create-section.dto';

@EntityRepository(Section)
export class SectionRepository extends Repository<Section> {

  async findSections(queryDto: FindSectionsQueryDto): Promise<Pagination<Section>> {
    queryDto.page = queryDto.page < 1 ? 1 : queryDto.page
    queryDto.limit = queryDto.limit > 100 ? 100 : queryDto.limit

    const {
      name,
      page,
      limit,
      sort
    } = queryDto
    const query = this.createQueryBuilder('section')

    const options: IPaginationOptions = {
      page,
      limit,
    }

    !!name && query.andWhere('section.name ILIKE :name', { name: `%${name}%` })

    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<Section>(query, options);
  }

  async createSection(createSectionDto: CreateSectionDto): Promise<Section> {
    const found = await this.findOne(createSectionDto)
    if(found){
      return found
    }
    const section = this.create({
        ...createSectionDto,
    })

    try {
      return await this.save(section)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Seção já cadastrada')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar a seção no banco de dados')
      }
    }
  }

}
