import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Controller, UseGuards, Post, Body, ValidationPipe, Get, Param, Patch, Req, ForbiddenException, Delete, Query } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AccessLevelGuard } from '../auth/roles.guard';
import { SectionsService } from './sections.service';
import { AccessLevel } from '../auth/role.decorator';
import { UserAccessLevel } from '../users/user.entity';
import { CreateSectionDto } from './dto/create-section.dto';
import { ReturnSectionDto } from './dto/return-section.dto';
import { UpdateSectionDto } from './dto/update-section.dto';
import { FindSectionsQueryDto } from './dto/find-sections-query.dto';

@ApiTags('section')
@ApiBearerAuth('JWT')
@Controller('section')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class SectionsController {
  constructor(private sectionsService: SectionsService) {}

  @ApiOperation({
    summary: 'Cadastra seção',
    description: 'Cadastrar uma nova seção no banco de dados.'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Seção inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async createSection(
    @Body(ValidationPipe) createSectionDto: CreateSectionDto) : Promise<ReturnSectionDto>  {
    const section = await this.sectionsService.createSection(createSectionDto)
    return {
      section,
      message: 'Seção cadastrada com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Busca seção pelo id',
    description: 'Busca a seção no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Seção encontrada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Seção inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async findSectionById(@Param('id') id: string): Promise<ReturnSectionDto> {
    const section = await this.sectionsService.findSectionById(Number(id))
    return {
      section,
      message: 'Seção encontrada',
    }
  }

  @ApiOperation({
    summary: 'Altera seção',
    description: 'Altera dados da seção no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Seção atualizada com sucesso' })
  @ApiResponse({ status: 403, description: 'Seção inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 404, description: 'Seção não encontrada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async updateSection(
      @Body() updateSectionDto: UpdateSectionDto,
      @Param('id') id: string,
      @Req() req: any) {
      const { section } = req

      if ([UserAccessLevel.Manager, UserAccessLevel.Owner].includes(section.access_level)) {
        return this.sectionsService.updateSection(updateSectionDto, Number(id))
      } else if (section.id === Number(id)) {
        return this.sectionsService.updateSection(updateSectionDto, Number(id))
      }
      throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
  }

  @ApiOperation({
    summary: 'Deleta seção',
    description: 'Deleta seção no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Seção removida com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover esta seção' })
  @ApiResponse({ status: 404, description: 'Seção não encontrada' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async deleteSection(@Param('id') id: string) {
      await this.sectionsService.deleteSection(Number(id))
      return {
        message: 'Seção removida com sucesso',
      }
  }

  @ApiOperation({
    summary: 'Lista todas as seções',
    description: 'Lista todas as seções cadastradas no banco de dados.'
  })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para listar seções' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async findSections(@Query() query: FindSectionsQueryDto) {
      const found = await this.sectionsService.findSections(query)
      return found
  }

}
