import { Module } from '@nestjs/common';
import { DepartmentRepository } from './department.repository';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { DepartmentService } from './department.service';
import { DepartmentController } from './department.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([DepartmentRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [DepartmentService],
  controllers: [DepartmentController],
  exports: [DepartmentModule]
})
export class DepartmentModule {}
