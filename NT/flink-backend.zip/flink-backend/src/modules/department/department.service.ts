import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { DepartmentRepository } from './department.repository';
import { CreateDepartmentDto } from './dto/create-department.dto';
import { Department } from './department.entity';
import { UpdateDepartmentDto } from './dto/update-department.dto';
import { FindDepartmentQueryDto } from './dto/find-department-query.dto';
import { Pagination } from 'nestjs-typeorm-paginate';
import { REQUEST } from '@nestjs/core';
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware';
import { getCustomRepository } from 'typeorm';

@Injectable()
export class DepartmentService {
  private departmentRepository: DepartmentRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.departmentRepository = getCustomRepository(DepartmentRepository, this.companyName)
  }

  async create(createDepartmentDto: CreateDepartmentDto): Promise<Department> {
    return this.departmentRepository.createDepartment(createDepartmentDto)
  }

  async findDepartmentById(departmentId: number): Promise<Department> {
    const department = await this.departmentRepository.findOne(departmentId)

    if (!department) throw new NotFoundException('Departamento não encontrado')

    return department
  }

  async update(updateDepartmentDto: UpdateDepartmentDto, id: number) {
    const result = await this.departmentRepository.update({ id }, updateDepartmentDto)
    if (result.affected > 0) {
      const department = await this.findDepartmentById(id)
      return department
    } else {
      throw new NotFoundException('Departamento não encontrado')
    }
  }

  async delete(departmentId: number) {
    const result = await this.departmentRepository.delete({ id: departmentId })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrada um departamento com o ID informado')
    }
  }

  async find(queryDto: FindDepartmentQueryDto): Promise<Pagination<Department>> {
    return await this.departmentRepository.findDepartment(queryDto)
  }

}
