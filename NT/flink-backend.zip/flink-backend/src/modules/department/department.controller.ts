import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Controller, UseGuards, Post, Body, ValidationPipe, Get, Param, Patch, Req, ForbiddenException, Delete, Query } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AccessLevelGuard } from '../auth/roles.guard';
import { DepartmentService } from './department.service';
import { AccessLevel } from '../auth/role.decorator';
import { UserAccessLevel } from '../users/user.entity';
import { CreateDepartmentDto } from './dto/create-department.dto';
import { ReturnDepartmentDto } from './dto/return-department.dto';
import { UpdateDepartmentDto } from './dto/update-department.dto';
import { FindDepartmentQueryDto } from './dto/find-department-query.dto';

@ApiTags('department')
@ApiBearerAuth('JWT')
@Controller('department')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class DepartmentController {
  constructor(private departmentService: DepartmentService) {}

  @ApiOperation({
    summary: 'Cadastra departamento'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Departamento inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async create(
    @Body(ValidationPipe) createDepartmentDto: CreateDepartmentDto) : Promise<ReturnDepartmentDto>  {
    const department = await this.departmentService.create(createDepartmentDto)
    return {
      department,
      message: 'Departamento cadastrado com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Busca departamento pelo id'
  })
  @ApiResponse({ status: 200, description: 'Departamento encontrado' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Departamento inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async findById(@Param('id') id: string): Promise<ReturnDepartmentDto> {
    const department = await this.departmentService.findDepartmentById(Number(id))
    return {
      department,
      message: 'Departamento encontrado',
    }
  }

  @ApiOperation({
    summary: 'Altera departamento',
    description: 'Altera dados do departamento no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Departamento atualizado com sucesso' })
  @ApiResponse({ status: 403, description: 'Departamento inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 404, description: 'Departamento não encontrada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Patch(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async update(
      @Body() updateDepartmentDto: UpdateDepartmentDto,
      @Param('id') id: string,
      @Req() req: any) {
      const { user } = req

      if ([UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)) {
        return this.departmentService.update(updateDepartmentDto, Number(id))
      } else if (user.id === Number(id)) {
        return this.departmentService.update(updateDepartmentDto, Number(id))
      }
      throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
  }

  @ApiOperation({
    summary: 'Deleta Departamento',
    description: 'Deleta Departamento no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Departamento removido com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover este departamento' })
  @ApiResponse({ status: 404, description: 'Departamento não encontrado' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner])
  async delete(@Param('id') id: string) {
      await this.departmentService.delete(Number(id))
      return {
        message: 'Departamento removida com sucesso',
      }
  }

  @ApiOperation({
    summary: 'Lista todos os departamentos',
    description: 'Lista todos os departamentos cadastrados no banco de dados.'
  })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para listar seções' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async find(@Query() query: FindDepartmentQueryDto) {
      return await this.departmentService.find(query)
  }

}
