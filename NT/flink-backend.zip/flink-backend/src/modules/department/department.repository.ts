import { EntityRepository, Repository } from 'typeorm';
import { FindDepartmentQueryDto } from './dto/find-department-query.dto';
import { Pagination, IPaginationOptions, paginate } from 'nestjs-typeorm-paginate';
import { Department } from './department.entity';
import { BadRequestException, ConflictException, InternalServerErrorException } from '@nestjs/common';
import { CreateDepartmentDto } from './dto/create-department.dto';

@EntityRepository(Department)
export class DepartmentRepository extends Repository<Department> {

  async findDepartment(queryDto: FindDepartmentQueryDto): Promise<Pagination<Department>> {

    const {
      name,
      page,
      limit,
      sort
    } = queryDto
    const query = this.createQueryBuilder('department')

    const options: IPaginationOptions = {
      page: Math.max(1, page || 1),
      limit: Math.min(100, limit || 10)
    }

    !!name && query.andWhere('department.name ILIKE :name', { name: `%${name}%` })

    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<Department>(query, options);
  }

  async createDepartment(createDepartmentDto: CreateDepartmentDto): Promise<Department> {
    const department = this.create({
      ...createDepartmentDto,
    })

    try {
      return await this.save(department)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Departamento já cadastrado')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar o departamento no banco de dados')
      }
    }
  }

}
