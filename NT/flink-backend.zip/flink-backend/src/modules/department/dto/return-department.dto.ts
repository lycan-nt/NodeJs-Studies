import { Department } from '../department.entity';

export class ReturnDepartmentDto {
  department: Department
  message: string
}
