import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, MaxLength } from 'class-validator';

export class CreateDepartmentDto {

  @ApiProperty()
  @IsString()
  @IsNotEmpty({
    message: 'Informe o nome do departamento',
  })
  @MaxLength(255, {
    message: 'O nome deve ter no máximo 255 caracteres',
  })
  name: string

}
