/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToMany } from 'typeorm'
import { Product } from '../product/product.entity'

@Entity()
@Unique(['id'])
export class Department extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ nullable: true, type: 'varchar', length: 50 })
  name: string

  @ManyToMany(() => Product, product => product.departments)
  products: Product[];

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
