import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LikeProductRepository } from './like-product.repository';
import { PassportModule } from '@nestjs/passport';
import { LikesProductService } from './likes-product.service';
import { LikesProductController } from './likes-product.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([LikeProductRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [LikesProductService],
  controllers: [LikesProductController],
  exports: [LikesProductModule]
})
export class LikesProductModule {}
