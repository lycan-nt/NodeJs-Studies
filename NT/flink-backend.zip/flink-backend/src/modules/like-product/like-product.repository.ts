import { EntityRepository, Repository } from 'typeorm';
import { LikeProduct } from './like-product.entity';
import { User } from '../users/user.entity';
import { FindLikesProductQueryDto } from './dto/find-likes-product-query.dto';
import { Pagination, IPaginationOptions, paginate } from 'nestjs-typeorm-paginate';
import { BadRequestException, ConflictException, InternalServerErrorException } from '@nestjs/common';
import { CreateLikeProductDto } from './dto/create-like-product.dto';

@EntityRepository(LikeProduct)
export class LikeProductRepository extends Repository<LikeProduct> {

  async findLikesProduct(queryDto: FindLikesProductQueryDto): Promise<Pagination<LikeProduct>> {
    const {
      user_id,
      product_id,
      page,
      limit,
      sort
    } = queryDto
    const query = this.createQueryBuilder('like_product')

    const options: IPaginationOptions = {
      page: Math.max(1, page || 1),
      limit: Math.min(100, limit || 10)
    }

    if (user_id) {
      query.andWhere('like_product.user_id = :user_id', { user_id })
    }

    if (product_id) {
      query.andWhere('like_product.product_id = :product_id', { product_id })
    }


    query.leftJoinAndSelect('like_product.product_id', 'product_id')
    query.leftJoinAndSelect('like_product.user_id', 'user_id')

    try {
      query.orderBy(JSON.parse(sort || "{}"))
    } catch (err) {
      throw new BadRequestException("Filtro de ordenação inválido")
    }

    return paginate<LikeProduct>(query, options);
  }

  async createLikeProduct(createLikeProductDto: CreateLikeProductDto): Promise<LikeProduct> {
    const { product_id, user_id } = createLikeProductDto
    const alreadyExists = await this.findOne({
      product_id,
      user_id
    })

    if (alreadyExists) {
      throw new ConflictException('Usuário já possui Like para este produto')
    }

    let likeProduct = this.create({
      product_id,
      user_id
    })

    try {
      return await this.save(likeProduct)
    } catch (error) {
      if (error.code.toString() === '23505') {
        throw new ConflictException('Like já cadastrado')
      } else {
        throw new InternalServerErrorException(error.message, 'Erro ao salvar like no banco de dados')
      }
    }
  }
}
