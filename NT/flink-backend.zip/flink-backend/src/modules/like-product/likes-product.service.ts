import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { LikeProductRepository } from './like-product.repository';
import { CreateLikeProductDto } from './dto/create-like-product.dto';
import { LikeProduct } from './like-product.entity';
import { FindLikesProductQueryDto } from './dto/find-likes-product-query.dto';
import { Pagination } from 'nestjs-typeorm-paginate';
import { User } from '../users/user.entity';
import { DeleteResult, getCustomRepository } from 'typeorm';
import { REQUEST } from '@nestjs/core';
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware';

@Injectable()
export class LikesProductService {
  private likeProductRepository: LikeProductRepository
  private companyName: string

  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.likeProductRepository = getCustomRepository(LikeProductRepository, this.companyName)
  }

  async createLikeProduct(createLikeProductDto: CreateLikeProductDto): Promise<LikeProduct> {
    return await this.likeProductRepository.createLikeProduct(createLikeProductDto)
  }

  async findLikeProductById(id: number, user_id?: User): Promise<LikeProduct> {
    let likeProduct: LikeProduct
    if (user_id)
      likeProduct = await this.likeProductRepository.findOne({ id, user_id })
    else
      likeProduct = await this.likeProductRepository.findOne({ id })

    if (!likeProduct) throw new NotFoundException('Like não encontrado')

    return likeProduct
  }

  async deleteLikeProduct(id: number, user_id?: User) {
    let result: DeleteResult
    if (user_id)
      result = await this.likeProductRepository.delete({ id, user_id })
    else
      result = await this.likeProductRepository.delete({ id })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrado like com o ID informado ou você não tem permissão para este recurso')
    }
  }

  async deleteLikeByProduct(likeDto: CreateLikeProductDto) {
    let result: DeleteResult
    result = await this.likeProductRepository.delete({
      user_id: likeDto.user_id,
      product_id: likeDto.product_id
    })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrado like com o ID informado ou você não tem permissão para este recurso')
    }
  }

  async findLikesProduct(queryDto: FindLikesProductQueryDto): Promise<Pagination<LikeProduct>> {
    return await this.likeProductRepository.findLikesProduct(queryDto)
  }

}
