import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsNotEmpty, IsOptional } from 'class-validator';
import { User } from '../../users/user.entity';
import { Product } from '../../product/product.entity';

export class CreateLikeProductDto {

  @ApiPropertyOptional()
  @IsOptional()
  @IsNotEmpty({
    message: 'Informe o usuário responsável pelo like',
  })
  user_id: User

  @ApiProperty()
  @IsNotEmpty({
    message: 'Informe o produto relacionado ao like',
  })
  product_id: Product

}
