import { LikeProduct } from '../like-product.entity';

export class ReturnLikeProductDto {
  likeProduct: LikeProduct
  message: string
}
