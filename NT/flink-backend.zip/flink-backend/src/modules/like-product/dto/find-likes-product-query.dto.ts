import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional } from 'class-validator';
import { User } from '../../users/user.entity';
import { Product } from '../../product/product.entity';

export class FindLikesProductQueryDto extends BaseQueryParametersDto {

  @ApiPropertyOptional({ description: 'Busca pelo id do usuário relacionado ao like' })
  @IsOptional()
  user_id: Number

  @ApiPropertyOptional({ description: 'Busca pelo id do produto relacionado ao like' })
  @IsOptional()
  product_id: Product

}
