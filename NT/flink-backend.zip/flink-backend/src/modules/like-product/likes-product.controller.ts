import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Controller, UseGuards, Post, Body, ValidationPipe, Param, Get, Delete, Query, Req } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AccessLevelGuard } from '../auth/roles.guard';
import { AccessLevel } from '../auth/role.decorator';
import { User, UserAccessLevel } from '../users/user.entity';
import { CreateLikeProductDto } from './dto/create-like-product.dto';
import { ReturnLikeProductDto } from './dto/return-like-product.dto';
import { FindLikesProductQueryDto } from './dto/find-likes-product-query.dto';
import { LikesProductService } from './likes-product.service';

@ApiTags('like-product')
@ApiBearerAuth('JWT')
@Controller('like-product')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class LikesProductController {
  constructor(private likesProductService: LikesProductService) { }

  @ApiOperation({
    summary: 'Cadastra like',
    description: 'Cadastrar um like no banco de dados.'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Like inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Post()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async createLikeProduct(
    @Body(ValidationPipe) createLikeProductDto: CreateLikeProductDto,
    @Req() req: any): Promise<ReturnLikeProductDto> {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)
    if (!isAdmin || !createLikeProductDto.user_id) {
      createLikeProductDto.user_id = user
    }

    const likeProduct = await this.likesProductService.createLikeProduct(createLikeProductDto)
    return {
      likeProduct,
      message: 'Like cadastrado com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Busca like pelo id',
    description: 'Busca like no banco de dados de acordo com o id informado.'
  })
  @ApiResponse({ status: 200, description: 'Like encontrado' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Like inexistente ou você não tem autorização de acesso' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Get(':id')
  async findLikeProductById(
    @Param('id') id: string,
    @Req() req: any): Promise<ReturnLikeProductDto> {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)
    if (!isAdmin) {
      return {
        likeProduct: await this.likesProductService.findLikeProductById(Number(id), user),
        message: 'Like encontrado',
      }
    }

    return {
      likeProduct: await this.likesProductService.findLikeProductById(Number(id)),
      message: 'Like encontrado',
    }
  }

  @ApiOperation({
    summary: 'Deleta like',
    description: 'Deleta like no banco de dados de acordo com o id do like informado.'
  })
  @ApiResponse({ status: 200, description: 'Like removido com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover este like' })
  @ApiResponse({ status: 404, description: 'Like não encontrado' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete(':id')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async deleteLikeProduct(
    @Param('id') id: string,
    @Req() req: any) {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)
    if (!isAdmin) {
      await this.likesProductService.deleteLikeProduct(Number(id), user)
    } else {
      await this.likesProductService.deleteLikeProduct(Number(id))
    }
    return {
      message: 'Like removido com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Deleta like pelo id do produto',
    description: 'Deleta like no banco de dados de acordo com o id do produto informado.'
  })
  @ApiResponse({ status: 200, description: 'Like removido com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover este like' })
  @ApiResponse({ status: 404, description: 'Like não encontrado' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @Delete('')
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async deleteLikeByProduct(
    @Body(ValidationPipe) createLikeProductDto: CreateLikeProductDto,
    @Req() req: any) {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)
    if (!isAdmin || !createLikeProductDto.user_id) {
      createLikeProductDto.user_id = user
    }
    await this.likesProductService.deleteLikeByProduct(createLikeProductDto)
    return {
      message: 'Like removido com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Lista todos os likes',
    description: 'Lista todos os likes cadastrados no banco de dados.'
  })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário não possui permissão para listar os likes' })
  @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
  @ApiResponse({ status: 200, description: 'Consulta realizada' })
  @Get()
  @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
  async findLikesProduct(
    @Query() query: FindLikesProductQueryDto,
    @Req() req: any) {
    const user = req.user as User
    const isAdmin = [UserAccessLevel.Manager, UserAccessLevel.Owner].includes(user.access_level)
    if (!isAdmin) {
      query.user_id = user.id
    }
    const found = await this.likesProductService.findLikesProduct(query)
    return found
  }

}
