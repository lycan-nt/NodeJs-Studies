/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToMany, ManyToOne, JoinColumn } from 'typeorm'
import { Department } from '../department/department.entity';
import { Product } from '../product/product.entity'

@Entity('department_product')
export class DepartmentProduct extends BaseEntity {

  @ManyToOne(() => Product, product => product.departments, { nullable: false, eager: true, primary: true })
  @JoinColumn({ name: 'product_id' })
  product: Product;

  @ManyToOne(() => Department, department => department.products, { nullable: false, eager: true, primary: true })
  @JoinColumn({ name: 'department_id' })
  department: Department;

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
