import { SetMetadata } from '@nestjs/common'
import { UserAccessLevel } from '../users/user.entity'

export const AccessLevel = (accessLevel: UserAccessLevel | UserAccessLevel[]) => SetMetadata('access_level', accessLevel)
