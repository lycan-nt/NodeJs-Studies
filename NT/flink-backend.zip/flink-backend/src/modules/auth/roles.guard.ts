import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common'
import { Observable } from 'rxjs'
import { Reflector } from '@nestjs/core'

@Injectable()
export class AccessLevelGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) { }

  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
    const request = context.switchToHttp().getRequest()
    const userRole = request.user.access_level
    const requiredRole = this.reflector.get<string | string[]>('access_level', context.getHandler())

    if (!requiredRole) return true

    if (Array.isArray(requiredRole))
      return requiredRole.includes(userRole)

    return userRole === requiredRole
  }
}
