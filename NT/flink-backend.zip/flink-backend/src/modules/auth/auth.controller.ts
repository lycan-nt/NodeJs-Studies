import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { AuthGuard } from '@nestjs/passport';

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}


  @Get('/profile')
  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Get Me',
    description: 'Return current user data'
  })
  @ApiResponse({ status: 200, description: 'Perfil obtido' })
  @ApiResponse({ status: 401, description: 'Não autorizado (token vencido)' })
  @ApiResponse({ status: 500, description: 'Erro interno ao obter perfil do usuário' })
  @UseGuards(AuthGuard())
  getMe(@Req() req) {
    return this.authService.userInfo(req.user);
  }
}
