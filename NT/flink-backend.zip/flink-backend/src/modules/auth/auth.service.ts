import { Inject, Injectable } from '@nestjs/common'
import { UserRepository } from '../users/users.repository'
import { JwtService } from '@nestjs/jwt'
import { getCustomRepository } from 'typeorm'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'

@Injectable()
export class AuthService {
  private userRepository: UserRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
    private jwtService: JwtService,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.userRepository = getCustomRepository(UserRepository, this.companyName)
  }
  async userInfo({ id }) {
    const user = await this.userRepository.findOne(id)
    const token = this.jwtService.sign({ id, cn: this.companyName })
    return { ...user, token }
  }
}
