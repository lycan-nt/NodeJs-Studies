import { User } from "src/modules/users/user.entity"

export class MfaDto {
  user: User
  phoneNumber: string
  code: string
  operation: string
}
