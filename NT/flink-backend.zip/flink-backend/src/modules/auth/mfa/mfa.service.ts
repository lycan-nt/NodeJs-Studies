import { Inject, Injectable } from '@nestjs/common'
import * as AWS from 'aws-sdk'
import { MfaRepository, OperationType } from './mfa.repository'
import { User } from 'src/modules/users/user.entity'
import { VerificationCodeDto } from '../dto/verification-code.dto'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository, getManager } from 'typeorm'

@Injectable()
export class MfaService {
  private mfaRepository: MfaRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.mfaRepository = getCustomRepository(MfaRepository, this.companyName);
  }

  async generateCode(phoneNumber: string, user: User, operation: OperationType) {
    const code = String(Math.random()).slice(2, 8)

    await this.mfaRepository.saveCode({ user, code, phoneNumber, operation })

    // await this.sendSMS(code, phoneNumber)
  }

  async sendSMS(code: string, phoneNumber: string): Promise<any> {
    phoneNumber = `55${phoneNumber}`
    try {
      const params = {
        Message: `Flink Supermercados: seu codigo e ${code}`,
        PhoneNumber: phoneNumber,
      }

      const overrideAWS = AWS

      overrideAWS.config.update({
        region: 'us-east-1',
      })

      const publishTextPromise = await new overrideAWS.SNS().publish(params).promise()
      return publishTextPromise.MessageId
    } catch (error) {
      console.error(error)
      throw error
    }
  }

  async burnCode(verificationCodeDto: VerificationCodeDto) {
    await this.mfaRepository.burnCode(verificationCodeDto, this.companyName)
  }
}
