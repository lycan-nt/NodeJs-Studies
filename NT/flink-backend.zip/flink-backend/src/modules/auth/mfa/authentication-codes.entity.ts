/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm'
import { User } from 'src/modules/users/user.entity'

@Entity()
@Unique(['id', 'code', 'phoneNumber'])
export class AuthenticationCodes extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @ManyToOne(() => User, user => user.authentication_codes, { nullable: false, eager: true })
  @JoinColumn({ name: 'user_id' })
  user_id: User

  @Column({ nullable: false, type: 'varchar', length: 50 })
  phoneNumber: string

  @Column({ nullable: false, type: 'varchar', length: 50 })
  operation: string

  @Column({ nullable: false, type: 'varchar', length: 255 })
  code: string

  @Column({ nullable: false, type: 'int' })
  attempt: number

  @Column({ nullable: false, type: 'timestamp' })
  expires: Date

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
