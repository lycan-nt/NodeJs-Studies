import * as moment from 'moment'
import { EntityRepository, Repository, getRepository } from 'typeorm'
import { AuthenticationCodes } from './authentication-codes.entity'
import { MfaDto } from './mfa.dto'
import { VerificationCodeDto } from '../dto/verification-code.dto'
import { NotFoundException, UnauthorizedException } from '@nestjs/common'

export type OperationType = "register" | "recovery"

@EntityRepository(AuthenticationCodes)
export class MfaRepository extends Repository<AuthenticationCodes> {

  async saveCode(mfaDto: MfaDto) {
    const expires = moment()
      .add(3, 'minutes')
      .toDate()

    const attempt = await this.count({
      phoneNumber: mfaDto.phoneNumber,
      operation: mfaDto.operation
    }) + 1

    const authenticationCodes = this.create({
      expires,
      attempt,
      user_id: mfaDto.user,
      ...mfaDto
    })

    await this.save(authenticationCodes)
  }

  async checkAuthenticationCode(verificationCodeDto: VerificationCodeDto, operation: OperationType, companyName: string): Promise<AuthenticationCodes> {
    const authenticationCode = await getRepository(AuthenticationCodes, companyName).findOne({
      phoneNumber: verificationCodeDto.phoneNumber,
      operation
    }, { order: { id: 'DESC' } })

    if (!authenticationCode) {
      return null
    }

    if (verificationCodeDto.verificationCode !== authenticationCode.code) {
      throw new NotFoundException('Código inválido!')
    }

    if (moment().isAfter(authenticationCode.expires)) {
      throw new UnauthorizedException('Código expirou!')
    }

    return authenticationCode
  }

  async burnCode(verificationCodeDto: VerificationCodeDto, companyName: string) {
    await getRepository(AuthenticationCodes, companyName).update({
      phoneNumber: verificationCodeDto.phoneNumber,
      code: verificationCodeDto.verificationCode,
    }, { expires: '2000-01-01 00:00:00' })
  }
}
