import { MfaService } from './mfa.service'
import { Module } from '@nestjs/common'
import { MfaRepository } from './mfa.repository'
import { TypeOrmModule } from '@nestjs/typeorm'

@Module({
  imports: [
    TypeOrmModule.forFeature([MfaRepository]),
    MfaRepository,
  ],
  controllers: [],
  providers: [MfaService],
  exports: [MfaModule, MfaService, MfaRepository],
})
export class MfaModule { }
