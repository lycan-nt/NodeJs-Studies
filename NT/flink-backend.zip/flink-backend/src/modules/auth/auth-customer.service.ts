import { ConflictException, ForbiddenException, Inject, Injectable, UnauthorizedException } from '@nestjs/common'
import { UserRepository } from '../users/users.repository'
import { CreateUserDto } from '../users/dto/create-user.dto'
import { User, UserAccessLevel } from '../users/user.entity'
import { CredentialsDto } from './dto/credentials.dto'
import { JwtService } from '@nestjs/jwt'
import { VerificationCodeDto } from './dto/verification-code.dto'
import { MfaService } from './mfa/mfa.service'
import { MfaRepository } from './mfa/mfa.repository'
import { ReturnLoginDto } from './dto/return-login.dto'
import { RequestNewCodeDto } from './dto/request-new-code'
import { ChangePasswordDto } from './dto/change-password.dto'
import { ChangePasswordSmsDto } from './dto/change-password-sms.dto'
import { getCustomRepository } from 'typeorm'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'

@Injectable()
export class AuthCustomerService {
  private userRepository: UserRepository
  private mfaRepository: MfaRepository
  private companyName: string

  constructor(
    @Inject(REQUEST)
    private readonly request,
    private jwtService: JwtService,
    private mfaService: MfaService,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.userRepository = getCustomRepository(UserRepository, this.companyName)
    this.mfaRepository = getCustomRepository(MfaRepository, this.companyName)
  }

  async registerCustomer(createUserDto: CreateUserDto): Promise<User> {
    createUserDto.is_active = false
    const user = await this.userRepository.createUser(createUserDto, UserAccessLevel.Customer)
    await this.customerSignUpGenerateCode(createUserDto)
    return user
  }

  async changePasswordSms(changePasswordSmsDto: ChangePasswordSmsDto) {
    const { phone, new_password, verificationCode } = changePasswordSmsDto

    const authenticationCode = await this.mfaRepository.checkAuthenticationCode({
      phoneNumber: phone,
      verificationCode
    }, "recovery", this.companyName)

    if (authenticationCode === null) {
      throw new UnauthorizedException('Código de verificação incorreto!')
    }

    if (authenticationCode?.user_id?.is_active === false) {
      throw new ConflictException('Usuário inativo!')
    }

    await this.userRepository.changePassword({ new_password, current_password: null }, authenticationCode.user_id)
    await this.mfaService.burnCode({ phoneNumber: phone, verificationCode })
  }

  async changePassword(changePasswordDto: ChangePasswordDto, user: User) {
    const userData = await this.userRepository.findOne({ id: user.id }, { select: ["id", "salt", "password"] })
    const valid = await userData.checkPassword(changePasswordDto.current_password)

    if (!valid)
      throw new ForbiddenException('Senha atual não é válida')

    await this.userRepository.changePassword(changePasswordDto, userData)
  }

  async login(credentialsDto: CredentialsDto): Promise<ReturnLoginDto> {
    const user = await this.userRepository.checkCredentials(credentialsDto);

    user.last_access = new Date()
    this.userRepository.save(user)

    const jwtPayload = {
      id: user.id,
      cn: this.companyName
    };
    const token = await this.jwtService.sign(jwtPayload);

    user.password = user.salt = undefined;
    return { token, user };
  }

  async customerSignUpGenerateCode(credentialsDto: CredentialsDto) {
    const userCheck = await this.userRepository.checkPhoneExists(credentialsDto.phone)

    if (userCheck === null) {
      throw new UnauthorizedException('Usuário não existe!');
    }

    await this.mfaService.generateCode(credentialsDto.phone, userCheck, "register")
  }

  async recoveryBySms(requestNewCodeDto: RequestNewCodeDto) {
    const { phone } = requestNewCodeDto
    const user = await this.userRepository.findOne({ phone, is_active: true })

    if (!user)
      throw new UnauthorizedException('Usuário inativo ou inexistente')

    await this.mfaService.generateCode(phone, user, "recovery")
  }

  async customerVerificationCode(
    verificationCodeDto: VerificationCodeDto
  ): Promise<{ token: string, user: User }> {
    const authenticationCode = await this.mfaRepository.checkAuthenticationCode(verificationCodeDto, "register", this.companyName)

    if (authenticationCode === null) {
      throw new UnauthorizedException('Código de verificação incorreto!')
    }

    if (authenticationCode?.user_id?.is_active) {
      throw new ConflictException('Usuário já está ativo!')
    }

    const { id } = authenticationCode.user_id

    const jwtPayload = {
      id,
      cn: this.companyName
    }
    const token = this.jwtService.sign(jwtPayload)
    const user = await this.userRepository.findOne({ id })
    user.is_active = true
    this.userRepository.save(user)
    await this.mfaRepository.burnCode(verificationCodeDto, this.companyName)
    return { token, user }
  }

  async customerNewConfirmationCode(requestNewCodeDto: RequestNewCodeDto) {
    const { phone } = requestNewCodeDto
    const user = await this.userRepository.findOne({ phone, is_active: false })
    if (!user)
      throw new UnauthorizedException('Usuário já ativo ou inexistente')
    await this.mfaService.generateCode(phone, user, "register")
  }

  async userInfo({ id }) {
    const user = await this.userRepository.findOne(id)
    const token = this.jwtService.sign({ id, cn: this.companyName })
    return { ...user, token }
  }
}
