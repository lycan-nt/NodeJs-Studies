import { Inject, Injectable } from '@nestjs/common'
import { UserRepository } from '../users/users.repository'
import { InjectRepository } from '@nestjs/typeorm'
import { CreateUserDto } from '../users/dto/create-user.dto'
import { User, UserAccessLevel } from '../users/user.entity'
import { JwtService } from '@nestjs/jwt'
import { ReturnLoginDto } from './dto/return-login.dto'
import { AuthEmployeeDto } from './dto/auth-employee.dto'
import { REQUEST } from '@nestjs/core'
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware'
import { getCustomRepository } from 'typeorm'

@Injectable()
export class AuthEmployeeService {
  private userRepository: UserRepository
  private companyName: string

  constructor(
    @Inject(REQUEST)
    private readonly request,
    private jwtService: JwtService,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.userRepository = getCustomRepository(UserRepository, this.companyName)
  }

  async registerEmployee(createUserDto: CreateUserDto): Promise<User> {
    createUserDto.is_active = true
    return await this.userRepository.createUser(createUserDto, UserAccessLevel.Employee)
  }

  async login(authEmployeeDto: AuthEmployeeDto): Promise<ReturnLoginDto> {
    const user = await this.userRepository.checkCredentialsEmployee(authEmployeeDto);

    user.last_access = new Date()
    this.userRepository.save(user)

    const jwtPayload = {
      id: user.id,
      cn: this.companyName
    };
    const token = await this.jwtService.sign(jwtPayload);

    user.password = user.salt = undefined;
    return { token, user };
  }

}
