import { PassportStrategy } from '@nestjs/passport'
import { Strategy, ExtractJwt } from 'passport-jwt'
import { Injectable, UnauthorizedException } from '@nestjs/common'
import { UserRepository } from '../users/users.repository'
import { getCustomRepository } from 'typeorm'
const dotenv = require('dotenv')

dotenv.config();

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: process.env.JWT_SECRET_KEY,
    })
  }

  async validate(payload: { id: number, cn: string }) {
    const { id, cn } = payload
    let userRepository = getCustomRepository(UserRepository, cn)
    const user = await userRepository.findOne(id)
    if (!user) {
      throw new UnauthorizedException('Usuário não encontrado')
    }

    if (!user.is_active) {
      throw new UnauthorizedException('Usuário está bloqueado!')
    }

    return user
  }
}
