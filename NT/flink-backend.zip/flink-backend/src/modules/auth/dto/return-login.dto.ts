import { User } from "src/modules/users/user.entity";

export class ReturnLoginDto {
  token: string;
  user: User;
}
