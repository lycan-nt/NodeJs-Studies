import { ApiProperty } from '@nestjs/swagger'
import { IsNumberString } from 'class-validator'

export class AuthEmployeeDto {
  @ApiProperty()
  @IsNumberString()
  cpf: string

  @ApiProperty()
  password: string
}
