import { ApiProperty } from '@nestjs/swagger'
import { IsNumberString } from 'class-validator'

export class VerificationCodeDto {
  @ApiProperty()
  @IsNumberString({ no_symbols: true }, { message: "O número de telefone não pode conter letras e nem caracteres especiais" })
  phoneNumber: string

  @ApiProperty()
  @IsNumberString({ no_symbols: true }, { message: "O código de confirmação não pode conter letras e nem caracteres especiais" })
  verificationCode: string
}
