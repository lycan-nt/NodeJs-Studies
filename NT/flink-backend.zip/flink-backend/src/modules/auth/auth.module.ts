import { Module } from '@nestjs/common';
import { AuthCustomerController } from './auth-customer.controller';
import { AuthService } from './auth.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserRepository } from '../users/users.repository';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { JwtStrategy } from './jwt.strategy';
import { MfaModule } from './mfa/mfa.module';
import { MfaRepository } from './mfa/mfa.repository';
import { AuthEmployeeController } from './auth-employee.controller';
import { AuthEmployeeService } from './auth-employee.service';
import { AuthCustomerService } from './auth-customer.service';
import { AuthController } from './auth.controller';
import { CpfValidationService } from '../shared/cpf-validation.service';
const dotenv = require('dotenv')

dotenv.config();

@Module({
  imports: [
    TypeOrmModule.forFeature([UserRepository, MfaRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.register({
      secret: process.env.JWT_SECRET_KEY,
      signOptions: {
        expiresIn: process.env.JWT_EXPIRES_IN,
      },
    }),
    MfaModule
  ],
  controllers: [AuthController, AuthCustomerController, AuthEmployeeController],
  providers: [AuthService, AuthEmployeeService, AuthCustomerService, JwtStrategy, CpfValidationService],
  exports: [JwtStrategy, PassportModule],
})
export class AuthModule { }
