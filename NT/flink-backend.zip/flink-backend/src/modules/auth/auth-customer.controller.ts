import {
  Controller,
  Post,
  Body,
  ValidationPipe,
  Get,
  UseGuards,
  Req,
  HttpCode,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { AuthCustomerService } from './auth-customer.service';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { CredentialsDto } from './dto/credentials.dto';
import { AuthGuard } from '@nestjs/passport';
import { User } from '../users/user.entity';
import { VerificationCodeDto } from './dto/verification-code.dto';
import { RequestNewCodeDto } from './dto/request-new-code';
import { ChangePasswordDto } from './dto/change-password.dto';
import { ChangePasswordSmsDto } from './dto/change-password-sms.dto';

@ApiTags('auth/customer')
@Controller('auth/customer')
export class AuthCustomerController {
  constructor(private authCustomerService: AuthCustomerService) { }

  @ApiOperation({
    summary: 'Register Customer',
    description: 'Register a new customer'
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 409, description: 'Usuário já existe' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro ao salvar o usuário no banco de dados' })
  @Post('/register')
  async registerCustomer(
    @Body(ValidationPipe) createUserDto: CreateUserDto,
  ): Promise<{ message: string, user: User }> {
    const user = await this.authCustomerService.registerCustomer(createUserDto);
    return {
      message: 'Cadastro realizado com sucesso',
      user
    };
  }

  @ApiOperation({
    summary: 'Recover password by sms',
    description: 'Send a sms code to customer renew the password'
  })
  @ApiResponse({ status: 201, description: 'Código enviado' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 401, description: 'Usuário inativo ou inexistente' })
  @ApiResponse({ status: 500, description: 'Erro interno do servidor' })
  @Post('/recovery/sms')
  async recoveryBySms(
    @Body(ValidationPipe) phone: RequestNewCodeDto,
  ): Promise<{ message: string }> {
    await this.authCustomerService.recoveryBySms(phone);
    return {
      message: 'Código enviado',
    };
  }

  @ApiOperation({
    summary: 'Login Customer',
    description: 'Generate authentication code and send it by sms'
  })
  @ApiResponse({ status: 201, description: 'Login realizado' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 401, description: 'Usuário ou senha incorretos' })
  @ApiResponse({ status: 403, description: 'Usuário inativo' })
  @Post('/login')
  async generateLoginCode(
    @Body(ValidationPipe) credentiaslsDto: CredentialsDto,
  ): Promise<any> {
    return await this.authCustomerService.login(credentiaslsDto);
  }

  @ApiOperation({
    summary: 'Confirm Customer',
    description: 'Validate customer register by sms code'
  })
  @ApiResponse({ status: 401, description: 'Código expirado' })
  @ApiResponse({ status: 404, description: 'Código inválido' })
  @ApiResponse({ status: 409, description: 'Usuário já está ativo' })
  @ApiResponse({ status: 200, description: 'Usuário confirmado' })
  @HttpCode(200)
  @Post('/login/confirm')
  async loginConfirm(
    @Body(ValidationPipe) verificationCodeDto: VerificationCodeDto,
  ): Promise<{ token: string, user: User }> {
    return await this.authCustomerService.customerVerificationCode(verificationCodeDto);
  }

  @ApiOperation({
    summary: 'New Code',
    description: 'Request a new confirmation code'
  })
  @ApiResponse({ status: 401, description: 'Usuário já ativo ou inexistente' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 201, description: 'Código enviado' })
  @ApiResponse({ status: 500, description: 'Erro interno ao criar o código de confirmação' })
  @HttpCode(201)
  @Post('/login/code')
  async newConfirmationCode(
    @Body(ValidationPipe) requestNewCodeDto: RequestNewCodeDto,
  ) {
    return await this.authCustomerService.customerNewConfirmationCode(requestNewCodeDto);
  }

  @ApiBearerAuth('JWT')
  @ApiOperation({
    summary: 'Change user password',
    description: 'Change user password with current password'
  })
  @ApiResponse({ status: 201, description: 'Senha alterada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 403, description: 'Usuário ou senha incorretos' })
  @ApiResponse({ status: 401, description: 'Sem autorização ou usuário está bloqueado!' })
  @UseGuards(AuthGuard())
  @Post('/password/change')
  async changePassword(
    @Req() req,
    @Body(ValidationPipe) changePasswordDto: ChangePasswordDto,
  ): Promise<any> {
    const { user } = req
    return await this.authCustomerService.changePassword(changePasswordDto, user);
  }

  @ApiOperation({
    summary: 'Change user password by SMS code sent to user',
  })
  @ApiResponse({ status: 201, description: 'Senha alterada' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 401, description: 'Sem autorização ou usuário está bloqueado!' })
  @ApiResponse({ status: 403, description: 'Usuário ou senha incorretos' })
  @ApiResponse({ status: 409, description: 'Usuário inativo!' })
  @Post('/password/sms')
  async changePasswordSms(
    @Body(ValidationPipe) changePasswordSmsDto: ChangePasswordSmsDto,
  ): Promise<any> {
    return await this.authCustomerService.changePasswordSms(changePasswordSmsDto);
  }
}
