import { BadRequestException, Body, Controller, Post, ValidationPipe } from '@nestjs/common'
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger'
import { AuthEmployeeDto } from './dto/auth-employee.dto'
import { AuthEmployeeService } from './auth-employee.service'
import { CpfValidationService } from '../shared/cpf-validation.service'

@ApiTags('auth/employee')
@Controller('auth/employee')
export class AuthEmployeeController {
  constructor(
    private authEmployeeService: AuthEmployeeService,
    private readonly cpfValidationService: CpfValidationService,
  ) {}

  @ApiOperation({
    summary: 'Register Employee',
    description: 'Register a new employee',
  })
  @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
  @ApiResponse({ status: 409, description: 'Usuário já existe' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 500, description: 'Erro ao salvar o usuário no banco de dados' })
  @Post('/register')
  async registerEmployee(@Body(ValidationPipe) createUserDto: any): Promise<{ message: string }> {
    const isValidCpf = this.cpfValidationService.isCPF(createUserDto.cpf)
    if(!isValidCpf){
      throw new BadRequestException('CPF INVALIDO!')
    }
    await this.authEmployeeService.registerEmployee(createUserDto)
    return {
      message: 'Cadastro realizado com sucesso',
    }
  }

  @ApiOperation({
    summary: 'Login employee',
  })
  @ApiResponse({ status: 201, description: 'Login realizado' })
  @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
  @ApiResponse({ status: 401, description: 'Usuário ou senha incorretos' })
  @ApiResponse({ status: 403, description: 'Usuário inativo' })
  @Post('/login')
  async login(@Body(ValidationPipe) authEmployeeDto: AuthEmployeeDto): Promise<any> {
    return await this.authEmployeeService.login(authEmployeeDto)
  }
}
