import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { SuggestionRepository } from './suggestion.repository';
import { CreateSuggestionDto } from './dto/create-suggestion.dto';
import { Suggestion } from './suggestion.entity';
import { UpdateSuggestionDto } from './dto/update-suggestion.dto';
import { FindSuggestionsQueryDto } from './dto/find-suggestions-query.dto';
import { Pagination } from 'nestjs-typeorm-paginate';
import { User } from '../users/user.entity';
import { REQUEST } from '@nestjs/core';
import { DatabaseMiddleware } from 'src/infrastructure/middleware/database.middleware';
import { getCustomRepository } from 'typeorm';

@Injectable()
export class SuggestionsService {
  private suggestionRepository: SuggestionRepository
  private companyName: string
  constructor(
    @Inject(REQUEST)
    private readonly request,
  ) {
    this.companyName = this.request.headers[DatabaseMiddleware.COMPANY_NAME]
    this.suggestionRepository = getCustomRepository(SuggestionRepository, this.companyName)
  }

  async createSuggestion(createSuggestionDto: CreateSuggestionDto, user: User): Promise<Suggestion> {
    return this.suggestionRepository.createSuggestion(createSuggestionDto, user)
  }

  async findSuggestionById(suggestionId: number): Promise<Suggestion> {
    const suggestion = await this.suggestionRepository.findOne(suggestionId)

    if (!suggestion) throw new NotFoundException('Sugestão não encontrada')

    return suggestion
  }

  async updateSuggestion(updateSuggestionDto: UpdateSuggestionDto, id: number) {
    const result = await this.suggestionRepository.update({ id }, updateSuggestionDto)
    if (result.affected > 0) {
      const suggestion = await this.findSuggestionById(id)
      return suggestion
    } else {
      throw new NotFoundException('Sugestão não encontrada')
    }
  }

  async deleteSuggestion(suggestionId: number) {
    const result = await this.suggestionRepository.delete({ id: suggestionId })
    if (result.affected === 0) {
      throw new NotFoundException('Não foi encontrada uma sugestão com o ID informado')
    }
  }

  async findSuggestions(queryDto: FindSuggestionsQueryDto): Promise<Pagination<Suggestion>> {
    return await this.suggestionRepository.findSuggestions(queryDto)
  }

}
