import { EntityRepository, Repository } from 'typeorm';
import { Suggestion } from './suggestion.entity';
import { User } from '../users/user.entity';
import { FindSuggestionsQueryDto } from './dto/find-suggestions-query.dto';
import { Pagination, IPaginationOptions, paginate } from 'nestjs-typeorm-paginate';
import { BadRequestException, ConflictException, InternalServerErrorException } from '@nestjs/common';
import { CreateSuggestionDto } from './dto/create-suggestion.dto';

@EntityRepository(Suggestion)
export class SuggestionRepository extends Repository<Suggestion> {

    async findSuggestions(queryDto: FindSuggestionsQueryDto): Promise<Pagination<Suggestion>> {
      const {
        note,
        user_id,
        page,
        limit,
        sort
      } = queryDto
      const query = this.createQueryBuilder('suggestion')
      query.where('suggestion.user_id = :user_id', { user_id })

      const options: IPaginationOptions = {
        page: Math.max(1, page || 1),
        limit: Math.min(100, limit || 10)
      }

      !!note && query.andWhere('suggestion.note ILIKE :note', { note: `%${note}%` })

      try {
        query.orderBy(JSON.parse(sort || "{}"))
      } catch (err) {
        throw new BadRequestException("Filtro de ordenação inválido")
      }

      return paginate<Suggestion>(query, options);
    }

    async createSuggestion(createSuggestionDto: CreateSuggestionDto, user: User): Promise<Suggestion> {
      let suggestion = this.create({
          ...createSuggestionDto,
      })

      suggestion.user_id = user

      try {
        return await this.save(suggestion)
      } catch (error) {
        if (error.code.toString() === '23505') {
          throw new ConflictException('Sugestão já cadastrada')
        } else {
          throw new InternalServerErrorException(error.message, 'Erro ao salvar a sugestão no banco de dados')
        }
      }
    }

}
