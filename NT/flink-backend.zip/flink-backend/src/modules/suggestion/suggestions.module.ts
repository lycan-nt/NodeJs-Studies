import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PassportModule } from '@nestjs/passport';
import { SuggestionRepository } from './suggestion.repository';
import { SuggestionsService } from './suggestions.service';
import { SuggestionsController } from './suggetions.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([SuggestionRepository]),
    PassportModule.register({ defaultStrategy: 'jwt' }),
  ],
  providers: [SuggestionsService],
  controllers: [SuggestionsController],
  exports: [SuggestionsModule]
})
export class SuggestionsModule {}
