import { ApiProperty } from '@nestjs/swagger';
import { IsString, MaxLength, IsNotEmpty } from 'class-validator';
import { User } from '../../users/user.entity';

export class CreateSuggestionDto {

    @ApiProperty()
    @IsString()
    @IsNotEmpty({
        message: 'Informe a nota da reclamação',
      })
    @MaxLength(255, {
      message: 'A nota deve ter no máximo 255 caracteres',
    })
    note: string

    @ApiProperty()
    @IsNotEmpty({
      message: 'Informe o usuário responsável pela reclamação',
    })
    user_id: User

}
