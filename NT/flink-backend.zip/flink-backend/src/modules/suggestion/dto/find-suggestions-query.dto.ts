import { BaseQueryParametersDto } from '../../shared/dto/base-query-paramers.dto';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, MaxLength } from 'class-validator';
import { User } from '../../users/user.entity';

export class FindSuggestionsQueryDto extends BaseQueryParametersDto {

    @ApiPropertyOptional({ description: 'Busca pela nota da sugestão' })
    @IsOptional()
    @MaxLength(255, { message: 'A nota deve ter no máximo 255 caracteres' })
    note: string

    @ApiPropertyOptional({ description: 'Busca pelo id do usuário relacionado à sugestão' })
    @IsOptional()
    user_id: User

}
