import { Suggestion } from '../suggestion.entity';

export class ReturnSuggestionDto {
    suggestion: Suggestion
    message: string
}
