/* eslint-disable @typescript-eslint/ban-types */
import { BaseEntity, Entity, Unique, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, JoinColumn } from 'typeorm'
import { User } from '../users/user.entity'

@Entity()
@Unique(['id'])
export class Suggestion extends BaseEntity {
  @PrimaryGeneratedColumn()
  id: number

  @ManyToOne(() => User, user => user.suggestions, { nullable: false, eager: true })
  @JoinColumn({ name: 'user_id' })
  user_id: User

  @Column({ nullable: false, type: 'varchar', length: 255 })
  note: string

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
