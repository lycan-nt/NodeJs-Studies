import { ApiTags, ApiBearerAuth, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { Controller, UseGuards, Post, Body, ValidationPipe, Param, Get, Patch, Req, ForbiddenException, Delete, Query } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AccessLevelGuard } from '../auth/roles.guard';
import { AccessLevel } from '../auth/role.decorator';
import { UserAccessLevel } from '../users/user.entity';
import { CreateSuggestionDto } from './dto/create-suggestion.dto';
import { ReturnSuggestionDto } from './dto/return-suggestion.dto';
import { UpdateSuggestionDto } from './dto/update-suggestion.dto';
import { FindSuggestionsQueryDto } from './dto/find-suggestions-query.dto';
import { SuggestionsService } from './suggestions.service';

@ApiTags('suggestion')
@ApiBearerAuth('JWT')
@Controller('suggestion')
@UseGuards(AuthGuard(), AccessLevelGuard)
export class SuggestionsController {
    constructor(private suggestionsService: SuggestionsService) {}

    @ApiOperation({
        summary: 'Cadastra sugestão',
        description: 'Cadastrar uma nova sugestão no banco de dados.'
    })
    @ApiResponse({ status: 201, description: 'Cadastro realizado com sucesso' })
    @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
    @ApiResponse({ status: 403, description: 'Sugestão inexistente ou você não tem autorização de acesso' })
    @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
    @Post()
    @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
    async createSuggestion(
        @Body(ValidationPipe) createSuggestionDto: CreateSuggestionDto,
        @Req() req: any): Promise<ReturnSuggestionDto> {
        const { user } = req

        const suggestion = await this.suggestionsService.createSuggestion(createSuggestionDto, user)
        return {
          suggestion,
          message: 'Sugestão cadastrada com sucesso',
        }
    }

    @ApiOperation({
        summary: 'Busca sugestão pelo id',
        description: 'Busca a sugestão no banco de dados de acordo com o id informado.'
    })
    @ApiResponse({ status: 200, description: 'Sugestão encontrada' })
    @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
    @ApiResponse({ status: 403, description: 'Sugestão inexistente ou você não tem autorização de acesso' })
    @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
    @Get(':id')
    @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
    async findSuggestionById(@Param('id') id: string): Promise<ReturnSuggestionDto> {
        const suggestion = await this.suggestionsService.findSuggestionById(Number(id))
        return {
          suggestion,
          message: 'Sugestão encontrada',
        }
    }

    @ApiOperation({
        summary: 'Altera sugestão',
        description: 'Altera dados da sugestão no banco de dados de acordo com o id informado.'
    })
    @ApiResponse({ status: 200, description: 'Sugestão atualizada com sucesso' })
    @ApiResponse({ status: 403, description: 'Sugestão inexistente ou você não tem autorização de acesso' })
    @ApiResponse({ status: 404, description: 'Sugestão não encontrada' })
    @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
    @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
    @Patch(':id')
    @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
    async updateSuggestion(
        @Body() updateSuggestionDto: UpdateSuggestionDto,
        @Param('id') id: string,
        @Req() req: any) {
        const { suggestion } = req

        if ([UserAccessLevel.Manager, UserAccessLevel.Owner].includes(suggestion.access_level)) {
          return this.suggestionsService.updateSuggestion(updateSuggestionDto, Number(id))
        } else if (suggestion.id === Number(id)) {
          return this.suggestionsService.updateSuggestion(updateSuggestionDto, Number(id))
        }
        throw new ForbiddenException('Você não tem autorização para acessar esse recurso')
    }

    @ApiOperation({
        summary: 'Deleta sugestão',
        description: 'Deleta sugestão no banco de dados de acordo com o id informado.'
    })
    @ApiResponse({ status: 200, description: 'Sugestão removida com sucesso' })
    @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
    @ApiResponse({ status: 403, description: 'Usuário não possui permissão para remover esta sugestão' })
    @ApiResponse({ status: 404, description: 'Sugestão não encontrada' })
    @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
    @Delete(':id')
    @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
    async deleteSuggestion(@Param('id') id: string) {
        await this.suggestionsService.deleteSuggestion(Number(id))
        return {
          message: 'Sugestão removida com sucesso',
        }
    }

    @ApiOperation({
        summary: 'Lista todas as sugestões',
        description: 'Lista todas as sugestões cadastradas no banco de dados.'
    })
    @ApiResponse({ status: 200, description: 'Consulta realizada' })
    @ApiResponse({ status: 400, description: 'Erro na validação dos dados recebidos' })
    @ApiResponse({ status: 403, description: 'Usuário não possui permissão para listar sugestões' })
    @ApiResponse({ status: 500, description: 'Erro interno ao consultar o banco de dados' })
    @Get()
    @AccessLevel([UserAccessLevel.Manager, UserAccessLevel.Owner, UserAccessLevel.Customer])
    async findSuggestions(@Query(ValidationPipe) query: FindSuggestionsQueryDto) {
        const found = await this.suggestionsService.findSuggestions(query)
        return found
    }

}
