import { NestFactory } from '@nestjs/core'
import { AppModule } from './app.module'

import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger'
import { Logger, ValidationPipe } from '@nestjs/common'
import { DatabaseMiddleware } from './infrastructure/middleware/database.middleware'

async function bootstrap() {
  const logger = new Logger('bootstrap')

  const app = await NestFactory.create(AppModule)
  app.use(new DatabaseMiddleware().use);
  app.enableCors()
  app.setGlobalPrefix('v1')
  // https://docs.nestjs.com/techniques/validation
  // Adiciona o ValidationPipe em todas as rotas
  // app.useGlobalPipes(
  //   new ValidationPipe({
  //     Ignora campos que não estão definidos no DTO
  //     whitelist: true,
  //   }),
  // );

  const options = new DocumentBuilder()
    .setTitle('FLINK - BACKEND')
    .setDescription('API - flink backend')
    .setVersion('1.0.12')
    .addBearerAuth({ type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }, 'JWT')
    .build()

  const document = SwaggerModule.createDocument(app, options)
  SwaggerModule.setup('v1/swagger', app, document)

  await app.listen(3000)
  logger.log(`Application listening on port ${3000}`)
}
bootstrap()
