import { ProductModule } from './modules/product/product.module'
import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { UsersModule } from './modules/users/users.module'
import { AuthModule } from './modules/auth/auth.module'
import { WinstonModule } from 'nest-winston'
import { winstonConfig } from './configs/winston.config'
import { MailerModule } from '@nestjs-modules/mailer'
import { mailerConfig } from './configs/mailer.config'
import { CompanyModule } from './modules/company/company.module'
import { ReclamationsModule } from './modules/reclamation/reclamations.module'
import { SuggestionsModule } from './modules/suggestion/suggestions.module'
import { ShoppingCartModule } from './modules/shopping-cart/shopping-cart.module'
import { UserShoppingCartModule } from './modules/user-shopping-cart/user-shopping-cart.module'
import { SectionsModule } from './modules/section/sections.module'
import { OrderModule } from './modules/order/order.module'
import { LikesProductModule } from './modules/like-product/likes-product.module'
import { DepartmentModule } from './modules/department/department.module'

@Module({
  imports: [
    TypeOrmModule.forRoot(),
    WinstonModule.forRoot(winstonConfig),
    MailerModule.forRoot(mailerConfig),
    UsersModule,
    AuthModule,
    CompanyModule,
    ProductModule,
    ReclamationsModule,
    SuggestionsModule,
    ShoppingCartModule,
    UserShoppingCartModule,
    SectionsModule,
    OrderModule,
    LikesProductModule,
    DepartmentModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
