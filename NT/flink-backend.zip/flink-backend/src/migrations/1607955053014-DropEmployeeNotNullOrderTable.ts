import { MigrationInterface, QueryRunner } from "typeorm";

export class DropEmployeeNotNullOrderTable1607955053014 implements MigrationInterface {
  name = 'DropEmployeeNotNullOrderTable1607955053014'

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "order" DROP CONSTRAINT "FK_08cafdcbae0d6407effc99cf7aa"`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "employee_id" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "order" ADD CONSTRAINT "FK_08cafdcbae0d6407effc99cf7aa" FOREIGN KEY ("employee_id") REFERENCES "user"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "order" DROP CONSTRAINT "FK_08cafdcbae0d6407effc99cf7aa"`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "employee_id" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "order" ADD CONSTRAINT "FK_08cafdcbae0d6407effc99cf7aa" FOREIGN KEY ("employee_id") REFERENCES "user"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
  }

}
