import {MigrationInterface, QueryRunner} from "typeorm";

export class AddProductDescriptionField1606412966425 implements MigrationInterface {
    name = 'AddProductDescriptionField1606412966425'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product" ADD "description" character varying(255) NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product" DROP COLUMN "description"`);
    }

}
