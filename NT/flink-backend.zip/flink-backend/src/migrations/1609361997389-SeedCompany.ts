import { Company } from "src/modules/company/company.entity";
import { CompanySeed } from "src/seeds/company.seed";
import { getRepository, MigrationInterface, QueryRunner } from "typeorm";

export class SeedCompany1609361997389 implements MigrationInterface {

  public async up(queryRunner: QueryRunner): Promise<void> {
    const company = await getRepository(Company).save(CompanySeed)
  }

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  public async down(queryRunner: QueryRunner): Promise<void> {
  }

}
