import {MigrationInterface, QueryRunner} from "typeorm";

export class FixUserShoppingCartRelation1606244216238 implements MigrationInterface {
    name = 'FixUserShoppingCartRelation1606244216238'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "shopping_cart" DROP CONSTRAINT "FK_4964691e410da35fca683de9991"`);
        await queryRunner.query(`ALTER TABLE "shopping_cart" DROP COLUMN "owner_user_id"`);
        await queryRunner.query(`ALTER TABLE "user_shopping_cart" ADD "is_owner" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "user_shopping_cart" ADD CONSTRAINT "UQ_shopping_cart_user" UNIQUE ("shopping_cart_id", "user_id")`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "user_shopping_cart" DROP CONSTRAINT "UQ_shopping_cart_user"`);
        await queryRunner.query(`ALTER TABLE "user_shopping_cart" DROP COLUMN "is_owner"`);
        await queryRunner.query(`ALTER TABLE "shopping_cart" ADD "owner_user_id" integer NOT NULL`);
        await queryRunner.query(`ALTER TABLE "shopping_cart" ADD CONSTRAINT "FK_4964691e410da35fca683de9991" FOREIGN KEY ("owner_user_id") REFERENCES "user"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

}
