import {MigrationInterface, QueryRunner} from "typeorm";

export class AddFieldShoppingCartProductTable1607187749094 implements MigrationInterface {
    name = 'AddFieldShoppingCartProductTable1607187749094'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "shopping_cart_product" ADD "multiplier_price" numeric(12,2) NOT NULL DEFAULT 1`);
        await queryRunner.query(`ALTER TABLE "shopping_cart_product" ADD "quantity" integer DEFAULT 1`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "shopping_cart_product" DROP COLUMN "quantity"`);
        await queryRunner.query(`ALTER TABLE "shopping_cart_product" DROP COLUMN "multiplier_price"`);
    }

}
