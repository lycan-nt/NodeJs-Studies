import {MigrationInterface, QueryRunner} from "typeorm";

export class DropInvalidsColumnsShoppingCartTable1605882682089 implements MigrationInterface {
    name = 'DropInvalidsColumnsShoppingCartTable1605882682089'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "shopping_cart" DROP COLUMN "observacoes"`);
        await queryRunner.query(`ALTER TABLE "shopping_cart" DROP COLUMN "nova_coluna"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "shopping_cart" ADD "nova_coluna" character varying(255)`);
        await queryRunner.query(`ALTER TABLE "shopping_cart" ADD "observacoes" character varying(255)`);
    }

}
