import {MigrationInterface, QueryRunner} from "typeorm";

export class AdjustsOrderAndOrderProductTable1616627782798 implements MigrationInterface {
    name = 'AdjustsOrderAndOrderProductTable1616627782798'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "order_product" RENAME COLUMN "checkout_confirmed" TO "checkout_status"`);
        await queryRunner.query(`ALTER TABLE "order_product" DROP COLUMN "checkout_status"`);
        await queryRunner.query(`ALTER TABLE "order_product" ADD "checkout_status" integer NOT NULL DEFAULT 0`);
        await queryRunner.query(`ALTER TYPE "public"."order_status_enum" RENAME TO "order_status_enum_old"`);
        await queryRunner.query(`CREATE TYPE "order_status_enum" AS ENUM('paid', 'give_up', 'in_progress', 'waiting_checkout', 'waiting_payment')`);
        await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" TYPE "order_status_enum" USING "status"::"text"::"order_status_enum"`);
        await queryRunner.query(`DROP TYPE "order_status_enum_old"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "order_status_enum_old" AS ENUM('paid', 'give_up', 'in_progress', 'waiting_checkout')`);
        await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" TYPE "order_status_enum_old" USING "status"::"text"::"order_status_enum_old"`);
        await queryRunner.query(`DROP TYPE "order_status_enum"`);
        await queryRunner.query(`ALTER TYPE "order_status_enum_old" RENAME TO  "order_status_enum"`);
        await queryRunner.query(`ALTER TABLE "order_product" DROP COLUMN "checkout_status"`);
        await queryRunner.query(`ALTER TABLE "order_product" ADD "checkout_status" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "order_product" RENAME COLUMN "checkout_status" TO "checkout_confirmed"`);
    }

}
