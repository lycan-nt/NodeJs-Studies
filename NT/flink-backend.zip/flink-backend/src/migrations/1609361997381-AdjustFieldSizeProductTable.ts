import {MigrationInterface, QueryRunner} from "typeorm";

export class AdjustFieldSizeProductTable1609361997381 implements MigrationInterface {
    name = 'AdjustFieldSizeProductTable1609361997381'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE public.product ALTER COLUMN barcode TYPE varchar(50) USING barcode::varchar;`);
        await queryRunner.query(`ALTER TABLE public.product ALTER COLUMN barcode_reference TYPE varchar(50) USING barcode_reference::varchar;`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE public.product ALTER COLUMN barcode TYPE varchar(13) USING barcode::varchar;`);
        await queryRunner.query(`ALTER TABLE public.product ALTER COLUMN barcode_reference TYPE varchar(13) USING barcode_reference::varchar;`);

        // await queryRunner.query(`ALTER TABLE "product" DROP COLUMN "barcode_reference"`);
        // await queryRunner.query(`ALTER TABLE "product" ADD "barcode_reference" character varying(13)`);
        // await queryRunner.query(`ALTER TABLE "product" DROP COLUMN "barcode"`);
        // await queryRunner.query(`ALTER TABLE "product" ADD "barcode" character varying(13) NOT NULL`);
    }

}
