import {MigrationInterface, QueryRunner} from "typeorm";

export class AltersForOrderModules1608212181666 implements MigrationInterface {
    name = 'AltersForOrderModules1608212181666'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "order_product" ADD "checkout_confirmed" boolean NOT NULL DEFAULT false`);
        await queryRunner.query(`ALTER TABLE "order" DROP CONSTRAINT "FK_59cfe37058e33d63bea1e195666"`);
        await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "shopping_cart_id" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "order" ADD CONSTRAINT "FK_59cfe37058e33d63bea1e195666" FOREIGN KEY ("shopping_cart_id") REFERENCES "shopping_cart"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "order" DROP CONSTRAINT "FK_59cfe37058e33d63bea1e195666"`);
        await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "shopping_cart_id" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "order" ADD CONSTRAINT "FK_59cfe37058e33d63bea1e195666" FOREIGN KEY ("shopping_cart_id") REFERENCES "shopping_cart"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
        await queryRunner.query(`ALTER TABLE "order_product" DROP COLUMN "checkout_confirmed"`);
    }

}
