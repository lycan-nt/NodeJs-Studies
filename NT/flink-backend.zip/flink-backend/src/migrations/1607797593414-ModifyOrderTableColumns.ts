import { MigrationInterface, QueryRunner } from "typeorm";

export class ModifyOrderTableColumns1607797593414 implements MigrationInterface {
  name = 'ModifyOrderTableColumns1607797593414'

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "first_total" SET DEFAULT 0`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "payment_type" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "payment_type" DROP DEFAULT`);
    await queryRunner.query(`ALTER TYPE "public"."order_status_enum" RENAME TO "order_status_enum_old"`);
    await queryRunner.query(`CREATE TYPE "order_status_enum" AS ENUM('paid', 'give_up', 'in_progress', 'waiting_checkout')`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" DROP NOT NULL`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" DROP DEFAULT`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" TYPE "order_status_enum" USING "status"::"text"::"order_status_enum"`);
    await queryRunner.query(`DROP TYPE "order_status_enum_old"`);
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" SET NOT NULL`);
    await queryRunner.query(`CREATE TYPE "order_status_enum_old" AS ENUM('paid', 'give_up', 'in_progress')`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" TYPE "order_status_enum_old" USING "status"::"text"::"order_status_enum_old"`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "status" SET DEFAULT 'in_progress'`);
    await queryRunner.query(`DROP TYPE "order_status_enum"`);
    await queryRunner.query(`ALTER TYPE "order_status_enum_old" RENAME TO  "order_status_enum"`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "payment_type" SET DEFAULT 'debit'`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "payment_type" SET NOT NULL`);
    await queryRunner.query(`ALTER TABLE "order" ALTER COLUMN "first_total" DROP DEFAULT`);
  }

}
