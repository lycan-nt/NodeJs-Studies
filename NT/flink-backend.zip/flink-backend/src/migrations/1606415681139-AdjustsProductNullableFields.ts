import {MigrationInterface, QueryRunner} from "typeorm";

export class AdjustsProductNullableFields1606415681139 implements MigrationInterface {
    name = 'AdjustsProductNullableFields1606415681139'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product" ALTER COLUMN "barcode_reference" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "product" ALTER COLUMN "product_id_in_company_database" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "product" ALTER COLUMN "original_price" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "product" ALTER COLUMN "original_price" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "product" ALTER COLUMN "product_id_in_company_database" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "product" ALTER COLUMN "barcode_reference" SET NOT NULL`);
    }

}
