export const CompanySeed = [
  {
    name: "Flink Life",
    cnpj: "12345678901",
    email: "suporte@flink.life",
    phone: "81818182"
  }
]
