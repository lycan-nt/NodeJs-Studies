export interface ISNSEvent {
  Type: SNSEvents
  MessageId: string
  TopicArn: string
  Message: string
  Timestamp: string
  SignatureVersion: string
  Signature: string
  SigningCertURL: string
  Subject?: string
  Token?: string
  UnsubscribeURL?: string
  SubscribeURL?: string
}

export interface PayloadPublishMessage {
  TopicArn: string
  Message: string
  Subject?: string
}

export enum SNSEvents {
  SubscriptionConfirmation = 'SubscriptionConfirmation',
  Notification = 'Notification',
  UnsubscribeConfirmation = 'UnsubscribeConfirmation',
}
