import { Injectable, Logger, HttpException, HttpStatus } from '@nestjs/common'
import * as aws from 'aws-sdk'
import { PromiseResult } from 'aws-sdk/lib/request'

import { PayloadPublishMessage, ISNSEvent, SNSEvents } from './sns.interface'
import * as MessageValidator from 'sns-validator'

@Injectable()
export class SnsService {
  private readonly sns: aws.SNS
  private readonly logger: Logger

  constructor() {
    this.sns = new aws.SNS()
    this.logger = new Logger('Sns')
  }

  async publishMessage(TopicArn: string, Message: string): Promise<aws.SNS.PublishResponse> {
    return this.sns
      .publish({
        TopicArn,
        Message,
      })
      .promise()
  }

  async verifySNSSubscription(message: ISNSEvent): Promise<boolean> {
    try {
      await this.sns
        .confirmSubscription({
          AuthenticateOnUnsubscribe: 'true',
          Token: message.Token,
          TopicArn: message.TopicArn,
        })
        .promise()
      return true
    } catch (e) {
      this.logger.error(e, `Error while confirming sns subcription for arn:${message.TopicArn}`)
      return false
    }
  }

  async isValidSNSMessage(message: ISNSEvent): Promise<boolean> {
    const validator = new MessageValidator()
    return new Promise<boolean>(resolve => {
      validator.validate(message, (err: Error) => {
        if (err) {
          this.logger.error(`
							Error while validating sns message for arn:${message.TopicArn},
							messageId: ${message.MessageId}
						`)
          return resolve(false)
        }
        return resolve(true)
      })
    })
  }

  async validateAndConfirmMessage(notification: ISNSEvent): Promise<string> {
    const isValid = await this.isValidSNSMessage(notification)
    if (!isValid) {
      throw new Error('Message signature is invalid')
    }

    if (notification.Type === SNSEvents.SubscriptionConfirmation) {
      const done = await this.verifySNSSubscription(notification)
      if (done) {
        this.logger.log(`Subscription Confirmed: ${notification.TopicArn}`)
        return 'confirmed'
      }
      throw new Error(`Error on confirmed SNS message`)
    }

    // Do nothing
    if (notification.Type === SNSEvents.UnsubscribeConfirmation) {
      return 'nothing'
    }

    return 'validated'
  }

  isValidPublishSNSMessage(Message: PayloadPublishMessage): Message is PayloadPublishMessage {
    if ((Message as PayloadPublishMessage).Message && (Message as PayloadPublishMessage).TopicArn) {
      return true
    }
    return false
  }

  async sendTopic(
    msg: string,
    topic: string,
    Subject: string = undefined,
  ): Promise<PromiseResult<aws.SNS.PublishResponse, aws.AWSError>> {
    try {
      const params = {
        Message: msg,
        TopicArn: topic,
        Subject,
      }
      return await this.sns.publish(params).promise()
    } catch (error) {
      throw new HttpException('Failed to send a new topic.', HttpStatus.BAD_REQUEST)
    }
  }
}
