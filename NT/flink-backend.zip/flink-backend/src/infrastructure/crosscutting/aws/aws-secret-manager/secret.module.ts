import { Module, Global } from '@nestjs/common'
import { ConfigModule } from '@nestjs/config'

import { SecretController } from './secret.controller'
import { SecretService } from './secret.service'

export const secretProvider = [
  {
    provide: 'SECRET_API',
    global: true,
    useFactory: async (service: SecretService): Promise<void> => {
      return await service.load()
    },
    inject: [SecretService],
  },
]

@Global()
@Module({
  imports: [ConfigModule.forRoot({ isGlobal: true })],
  controllers: [SecretController],
  providers: [SecretService, ...secretProvider],
  exports: [SecretService, ...secretProvider],
})
export class SecretModule {}
