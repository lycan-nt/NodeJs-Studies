import { Inject } from '@nestjs/common'

export const InjectSecretManager: (connection: string) => ParameterDecorator = (connection: string) => Inject(connection)
