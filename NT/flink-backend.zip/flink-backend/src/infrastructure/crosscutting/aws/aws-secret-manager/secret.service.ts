import { Injectable } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import * as aws from 'aws-sdk'
import * as path from 'path'

import { LOCAL_SECRET, AWS_SECRET } from './secret.constants'
import { ISecret } from './secret.interface'

/**
 * Entity manager supposed to work with any Enviromenet, automatically find its repository and call its methods,
 *
 */
@Injectable()
export class SecretService {
  // -------------------------------------------------------------------------
  // Private Properties
  // -------------------------------------------------------------------------

  private connection = { typeSecret: AWS_SECRET }
  private cache: ISecret

  // -------------------------------------------------------------------------
  // Constructor
  // -------------------------------------------------------------------------

  constructor(private configService?: ConfigService) {}

  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------

  private async getSecretAws(): Promise<ISecret> {
    const configAws = { region: this.configService.get<string>('aws.region') || 'us-east-1' }
    aws.config.update(configAws)

    const secretsManager = new aws.SecretsManager()
    /* TODO: */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let objSecret: any = {}

    try {
      const secrets = await secretsManager
        .getSecretValue({
          SecretId: 'onb-secrets',
        })
        .promise()

      if ('SecretString' in secrets) {
        objSecret = JSON.parse(secrets.SecretString)
      } else {
        const buff = Buffer.from(secrets.SecretBinary as string, 'base64')
        objSecret = JSON.parse(buff.toString('ascii'))
      }
      return {
        queryApiUri: objSecret.QUERY_API_URI,
        securityApiIntegrationUsername: objSecret.SECURITY_TOKEN_INTEGRATION_USERNAME,
        securityApiIntegrationPassword: objSecret.SECURITY_TOKEN_INTEGRATION_PASSWORD,
        snsAccomplished: objSecret.SNS_ARN_ACCOMPLISHED,
        integrationLegacyApiUri: objSecret.INTEGRATION_LEGACY_API_URI,
        tableSuitabilityDynamo: objSecret.DB_TABLE_SUITABILITY,
        regionSuitabilityDynamo: objSecret.REGION_SUITABILITY_DYNAMO,
        webfeeder: {
          omsHost: objSecret.OMS_WEBFEEDER_HOST,
          omsLogin: objSecret.OMS_WEBFEEDER_LOGIN,
          omsPassword: objSecret.OMS_WEBFEEDER_PASSWORD,
        },
        sqsSecret: {
          url: '',
        },
        redis: {
          url: objSecret.REDIS_URL,
        },
        sinqia: {
          auth: {
            url: objSecret.SINQIA_CUC_AUTH_URL,
            port: objSecret.SINQIA_CUC_AUTH_PORT,
          },
          cuc: {
            wsUrl: objSecret.SINQIA_CUC_URL,
            wsPort: objSecret.SINQIA_CUC_PORT,
            authPath: objSecret.SINQIA_CUC_AUTH_PATH,
          },
          cco: {
            wsUrl: objSecret.SINQIA_CCO_URL,
            wsPort: objSecret.SINQIA_CCO_PORT,
            authPath: objSecret.SINQIA_CCO_AUTH_PATH,
          },
        },

        securityApiBaseUri: objSecret.SECURITY_API_BASE_URI,
        securityApiLogin: objSecret.SECURITY_API_LOGIN,
        securityApiUserInfo: objSecret.SECURITY_API_USER_INFO,
        mariadbHost: objSecret.MARIADB_HOST,
        mariadbUserName: objSecret.MARIADB_USERNAME,
        mariadbPassword: objSecret.MARIADB_PASSWORD,
        mariadbDatabase: objSecret.MARIADB_DATABASE,
        mariadbLoggin: objSecret.MARIADB_LOGGING,
        mariadbPort: objSecret.MARIADB_PORT,
        mariadbType: objSecret.MARIADB_TYPE,
        mariadbEntities: path.normalize(path.join(__dirname, objSecret.MARIADB_ENTITIES)),
        mariadbSynchronizes: false,
        host: objSecret.WEBFEEDER_HOST,
        accountInformation: objSecret.WEBFEEDER_ACCOUNT_INFORMATION,
        port: objSecret.WEBFEEDER_PORT,
        auth: objSecret.WEBFEEDER_AUTH,
        login: objSecret.WEBFEEDER_LOGIN,
        password: objSecret.WEBFEEDER_PASSWORD,
        token: objSecret.APIGATEWAY_APITOKEN,
        sqsAppraise: objSecret.SQS_URL_APPRAISE,
        sqsAppraiseDLQ: objSecret.SQS_URL_APPRAISE_DLQ,
        sqsDispatch: objSecret.SQS_URL_DISPATCH,
        sqsDispatchDLQ: objSecret.SQS_URL_DISPATCH_DLQ,
        sqsRegistration: objSecret.SQS_URL_REGISTRATION,
        sqsRegistrationDLQ: objSecret.SQS_URL_REGISTRATION_DLQ,
        snsArnAccomplished: objSecret.SNS_ARN_ACCOMPLISHED,
        snsArnAppraiseError: objSecret.SNS_ARN_APPRAISE_ERROR,
        snsArnApproved: objSecret.SNS_ARN_APPROVED,
        snsArnDispatchError: objSecret.SNS_ARN_DISPATCH_ERROR,
        snsArnRegisterError: objSecret.SNS_ARN_REGISTER_ERROR,
        snsArnRegistered: objSecret.SNS_ARN_REGISTERED,
        snsArnRegistration: objSecret.SNS_ARN_REGISTRATION,
        redisUrl: objSecret.REDIS_URL,
        apiUrl: objSecret.API_URL,
      }
    } catch (err) {
      console.log('\nEnvironment dont load, please restart this container!\n\n')
      console.error('getSecretValue Error: ', err)
      throw err
    }
  }

  private async getLocalSecret(): Promise<ISecret> {
    console.debug(`project config file: config/configuration.ts`)
    return {
      queryApiUri: this.configService.get<string>('QUERY_API_URI'),
      securityApiIntegrationUsername: this.configService.get<string>('SECURITY_TOKEN_INTEGRATION_USERNAME'),
      securityApiIntegrationPassword: this.configService.get<string>('SECURITY_TOKEN_INTEGRATION_PASSWORD'),
      snsAccomplished: this.configService.get<string>('SNS_ARN_ACCOMPLISHED'),
      integrationLegacyApiUri: this.configService.get<string>('INTEGRATION_LEGACY_API_URI'),
      tableSuitabilityDynamo: this.configService.get<string>('DB_TABLE_SUITABILITY'),
      regionSuitabilityDynamo: this.configService.get<string>('REGION_SUITABILITY_DYNAMO'),
      webfeeder: {
        omsHost: this.configService.get<string>('OMS_WEBFEEDER_HOST'),
        omsLogin: this.configService.get<string>('OMS_WEBFEEDER_LOGIN'),
        omsPassword: this.configService.get<string>('OMS_WEBFEEDER_PASSWORD'),
      },
      sqsSecret: {
        url: '',
      },
      redis: {
        url: this.configService.get<string>('REDIS_URL'),
      },
      sinqia: {
        auth: {
          url: this.configService.get<string>('SINQIA_CUC_AUTH_URL'),
          port: this.configService.get<number>('SINQIA_CUC_AUTH_PORT'),
        },
        cuc: {
          wsUrl: this.configService.get<string>('SINQIA_CUC_URL'),
          wsPort: this.configService.get<number>('SINQIA_CUC_PORT'),
          authPath: this.configService.get<string>('SINQIA_CUC_AUTH_PATH'),
        },
        cco: {
          wsUrl: this.configService.get<string>('SINQIA_CCO_URL'),
          wsPort: this.configService.get<number>('SINQIA_CCO_PORT'),
          authPath: this.configService.get<string>('SINQIA_CCO_AUTH_PATH'),
        },
      },

      securityApiBaseUri: this.configService.get<string>('SECURITY_API_BASE_URI'),
      securityApiLogin: this.configService.get<string>('SECURITY_API_LOGIN'),
      securityApiUserInfo: this.configService.get<string>('SECURITY_API_USER_INFO'),
      mariadbHost: this.configService.get<string>('MARIADB_HOST'),
      mariadbUserName: this.configService.get<string>('MARIADB_USERNAME'),
      mariadbPassword: this.configService.get<string>('MARIADB_PASSWORD'),
      mariadbDatabase: this.configService.get<string>('MARIADB_DATABASE'),
      mariadbLoggin: this.configService.get<boolean>('MARIADB_LOGGING'),
      mariadbPort: this.configService.get<number>('MARIADB_PORT'),
      mariadbType: this.configService.get<string>('MARIADB_TYPE'),
      mariadbEntities: path.normalize(path.join(__dirname, this.configService.get<string>('MARIADB_ENTITIES'))),
      mariadbSynchronizes: false,
      host: this.configService.get<string>('WEBFEEDER_HOST'),
      accountInformation: this.configService.get<string>('WEBFEEDER_ACCOUNT_INFORMATION'),
      port: this.configService.get<number>('WEBFEEDER_PORT'),
      auth: this.configService.get<string>('WEBFEEDER_AUTH'),
      login: this.configService.get<string>('WEBFEEDER_LOGIN'),
      password: this.configService.get<string>('WEBFEEDER_PASSWORD'),
      token: this.configService.get<string>('APIGATEWAY_APITOKEN'),
      sqsAppraise: this.configService.get<string>('SQS_URL_APPRAISE'),
      sqsAppraiseDLQ: this.configService.get<string>('SQS_URL_APPRAISE_DLQ'),
      sqsDispatch: this.configService.get<string>('SQS_URL_DISPATCH'),
      sqsDispatchDLQ: this.configService.get<string>('SQS_URL_DISPATCH_DLQ'),
      sqsRegistration: this.configService.get<string>('SQS_URL_REGISTRATION'),
      sqsRegistrationDLQ: this.configService.get<string>('SQS_URL_REGISTRATION_DLQ'),
      snsArnAccomplished: this.configService.get<string>('SNS_ARN_ACCOMPLISHED'),
      snsArnAppraiseError: this.configService.get<string>('SNS_ARN_APPRAISE-ERROR'),
      snsArnApproved: this.configService.get<string>('SNS_ARN_APPROVED'),
      snsArnDispatchError: this.configService.get<string>('SNS_ARN_DISPATCH_ERROR'),
      snsArnRegisterError: this.configService.get<string>('SNS_ARN_REGISTER_ERROR'),
      snsArnRegistered: this.configService.get<string>('SNS_ARN_REGISTERED'),
      snsArnRegistration: this.configService.get<string>('SNS_ARN_REGISTRATION'),
      redisUrl: this.configService.get<string>('REDIS_URL'),
      apiUrl: this.configService.get<string>('API_URL'),
    }
  }

  // -------------------------------------------------------------------------
  // Private Methods
  // -------------------------------------------------------------------------
  private async getSecretInternal(): Promise<ISecret> {
    const isLocal = this.configService.get<string>('isLocal')
    if (isLocal) {
      this.connection.typeSecret = LOCAL_SECRET
      console.debug(`config: LOCAL ENVIROMENT ENABLE ================= `)
    }

    switch (this.connection.typeSecret) {
      case AWS_SECRET:
        return await this.getSecretAws()
      case LOCAL_SECRET:
        return await this.getLocalSecret()
      default:
        throw new Error(`ONB-ERROR-[register] - typeSecret not set`)
    }
  }

  // -------------------------------------------------------------------------
  // Public Methods
  // -------------------------------------------------------------------------
  public async getSecret(): Promise<ISecret> {
    return this.cache
  }

  public async load(): Promise<void> {
    this.cache = await this.getSecretInternal()
  }

  public async reload(): Promise<void> {
    this.cache = await this.getSecretInternal()
  }
}
