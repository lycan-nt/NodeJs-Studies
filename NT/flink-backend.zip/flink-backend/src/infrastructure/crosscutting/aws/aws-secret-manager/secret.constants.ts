export const AWS_SECRET = 'awssecret'
export const LOCAL_SECRET = 'localsecret'
