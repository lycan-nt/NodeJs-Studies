import { Controller, Get, Logger } from '@nestjs/common'
import { ApiTags } from '@nestjs/swagger'

import { ISecretResponse } from './secret.interface'
import { SecretService } from './secret.service'

@ApiTags('Secret Manager')
@Controller('secrets')
export class SecretController {
  constructor(private readonly secretService: SecretService) {}

  private logger = new Logger(SecretService.name)

  @Get('reload')
  async reload(): Promise<ISecretResponse> {
    await this.secretService.reload()

    return { message: 'secrets reload' }
  }
}
