export interface ISecret {
  queryApiUri: string
  securityApiBaseUri: string
  securityApiIntegrationUsername: string
  securityApiIntegrationPassword: string
  securityApiLogin: string
  securityApiUserInfo: string
  mariadbType: string
  mariadbUserName: string
  mariadbPassword: string
  mariadbHost: string
  mariadbPort: number
  mariadbDatabase: string
  mariadbEntities: string
  mariadbSynchronizes: boolean
  mariadbLoggin: boolean
  host: string
  accountInformation: string
  port: number
  auth: string
  login: string
  password: string
  token: string
  sqsAppraise: string
  sqsAppraiseDLQ: string
  sqsDispatch: string
  sqsDispatchDLQ: string
  sqsRegistration: string
  sqsRegistrationDLQ: string
  snsArnAccomplished: string
  snsArnAppraiseError: string
  snsArnApproved: string
  snsArnDispatchError: string
  snsArnRegisterError: string
  snsArnRegistered: string
  snsArnRegistration: string
  redisUrl: string
  snsAccomplished: string
  apiUrl: string
  integrationLegacyApiUri: string
  tableSuitabilityDynamo: string
  regionSuitabilityDynamo: string
  webfeeder: {
    omsHost: string
    omsLogin: string
    omsPassword: string
  }
  sqsSecret: {
    url: string
  }
  redis: {
    url: string
  }
  sinqia: {
    auth: {
      url: string
      port: number
    }
    cuc: {
      wsUrl: string
      wsPort: number
      authPath: string
    }
    cco: {
      wsUrl: string
      wsPort: number
      authPath: string
    }
  }
}

export interface ISecretResponse {
  message: string
}
