import { Injectable } from '@nestjs/common'
import * as aws from 'aws-sdk'
import { Consumer } from 'sqs-consumer'

import { ISecret } from '../aws-secret-manager/secret.interface'
import { SecretService } from '../aws-secret-manager/secret.service'

@Injectable()
export class SqsService {
  private sqs: aws.SQS
  private sqsSecret: ISecret

  static queue: string

  constructor(private readonly secretService: SecretService) {
    this.sqs = new aws.SQS()
  }

  async createConsumer(callback: (a, b) => Promise<void>): Promise<void> {
    this.sqsSecret = await this.secretService.getSecret()

    const consumer = Consumer.create({
      queueUrl: this.sqsSecret.sqsDispatch,
      handleMessage: async message => {
        await callback(message, this)
      },
      // sqs: new aws.SQS(),
    })
    consumer.on('error', err => console.log(err))
    consumer.start()
  }

  async sendSqs(key: string, value: string, sqsArn: string): Promise<void> {
    const params = {
      DelaySeconds: 10,

      MessageAttributes: {
        [key]: {
          DataType: 'String',
          StringValue: `${value}`,
        },
      },
      MessageBody: `{"${key}": "${value}"}`,
      QueueUrl: sqsArn,
    }

    this.sqs.sendMessage(params, function (err, data) {
      if (err) {
        console.log('Error', err)
      } else {
        console.log('Success', data)
      }
    })
  }

  async sqsDeleteMessage(receiptHandle: string): Promise<void> {
    const params = {
      QueueUrl: this.sqsSecret.sqsDispatch,
      ReceiptHandle: receiptHandle,
    }

    this.sqs.deleteMessage(params, (err, data) => {
      if (err) console.log('error ao deletar messagem', err, err.stack)
      else console.log('messagem deletada da queue', data)
    })
  }
}
