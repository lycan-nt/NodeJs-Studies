interface ResponseMetadata {
  RequestId: string
}

export interface ISqsMessage {
  Message: string
}

export interface IAWSSNSPublishResponse {
  ResponseMetadata: ResponseMetadata
  MessageId: string
}
