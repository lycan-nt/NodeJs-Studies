import { Inject } from '@nestjs/common'

import { SqsService } from './sqs.service'

export const getManagerSQS = (name: string) => {
  SqsService.queue = name
  return SqsService
}
export const InjectQueue: (name: string) => ParameterDecorator = (name: string) => Inject(getManagerSQS(name))
