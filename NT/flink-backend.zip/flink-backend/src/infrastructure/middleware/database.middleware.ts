import { Injectable, NestMiddleware, Inject } from '@nestjs/common';
import { getConnection, createConnection, ConnectionOptions } from "typeorm";
const dotenv = require('dotenv')

dotenv.config();

@Injectable()
export class DatabaseMiddleware implements NestMiddleware {
  public static COMPANY_NAME = 'company_name';

  async use(req: any, res: any, next: () => void) {
    const databaseName = req.headers[DatabaseMiddleware.COMPANY_NAME];

    const connection: ConnectionOptions = {
      host: process.env.DATABASE_HOST,
      port: Number(process.env.DATABASE_PORT),
      username: process.env.DATABASE_USER,
      password: process.env.DATABASE_PASSWORD,

      type: "postgres",
      database: databaseName,
      name: databaseName,
      entities: ["dist/**/*.entity{.ts,.js}"],
      migrations: ["dist/src/migrations/*{.ts,.js}"],
      migrationsTableName: "migrations_typeorm",
      migrationsRun: true,
      cli: {
        migrationsDir: 'src/migrations'
      },
      synchronize: false
    };

    try {
      getConnection(connection.name);
      next();
    } catch (error) {
      createConnection(connection)
        .then(() => { next() })
        .catch((e) => { res.status(503).send({ message: 'Requisição incorreta' }).end() })
    }

  }
}
